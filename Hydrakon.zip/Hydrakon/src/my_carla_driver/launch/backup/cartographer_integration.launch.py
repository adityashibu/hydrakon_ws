# improved_cartographer.launch.py
from launch import LaunchDescription
from launch_ros.actions import Node
import os

def generate_launch_description():
    # Create output directory
    mapping_output_dir = os.path.expanduser('~/mapping_output')
    os.makedirs(mapping_output_dir, exist_ok=True)
    
    return LaunchDescription([
        # CartographerIntegration node
        Node(
            package='my_carla_driver',
            executable='cartographer_integration',
            name='cartographer_integration_node',
            output='screen',
            parameters=[{
                'use_cartographer': True,
                'cartographer_resolution': 0.1,
                'map_width': 1000,
                'map_height': 1000,
                'output_dir': mapping_output_dir,
                'map_publish_rate': 1.0
            }]
        ),
        
        # Launch RViz with minimalist configuration
        Node(
            package='rviz2',
            executable='rviz2',
            name='cartographer_rviz',
            output='screen'
        ),
        
        # TF frames
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='carto_tf_publisher',
            arguments=['0', '0', '0', '0', '0', '0', 'map', 'base_link'],
            output='screen'
        )
    ])

