#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
import numpy as np
import os
import struct
import tf2_ros
from sensor_msgs.msg import PointCloud2, PointField
import sensor_msgs_py.point_cloud2 as pc2
from nav_msgs.msg import OccupancyGrid, Path
from visualization_msgs.msg import MarkerArray, Marker
from geometry_msgs.msg import TransformStamped, PoseStamped
import matplotlib.pyplot as plt
from sklearn.cluster import DBSCAN
from scipy.spatial import distance

class LIOSAMIntegration(Node):
    def __init__(self):
        super().__init__('lio_sam_integration_node')

        # Parameters
        self.declare_parameter('map_resolution', 0.1)
        self.declare_parameter('map_width', 2000)
        self.declare_parameter('map_height', 2000)
        self.declare_parameter('output_dir', os.path.expanduser('~/lio_sam_output'))
        self.declare_parameter('cone_fusion_distance', 1.0)  # Distance to fuse nearby cones
        
        # Get parameters
        self.resolution = self.get_parameter('map_resolution').value
        self.width = self.get_parameter('map_width').value
        self.height = self.get_parameter('map_height').value
        self.output_dir = self.get_parameter('output_dir').value
        self.cone_fusion_distance = self.get_parameter('cone_fusion_distance').value

        # Create output directories
        os.makedirs(self.output_dir, exist_ok=True)
        os.makedirs(os.path.join(self.output_dir, 'maps'), exist_ok=True)

        # Publishers
        self.cone_marker_pub = self.create_publisher(MarkerArray, '/lio_sam/cone_markers', 10)
        self.occupancy_grid_pub = self.create_publisher(OccupancyGrid, '/lio_sam/occupancy_grid', 10)

        # Subscribers
        self.lidar_sub = self.create_subscription(
            PointCloud2, 
            '/carla/lidar_points', 
            self.lidar_callback, 
            10
        )
        
        self.lio_sam_path_sub = self.create_subscription(
            Path, 
            '/lio_sam/path', 
            self.path_callback, 
            10
        )

        # TF Listener
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        # Map and cone storage
        self.grid_map = np.zeros((self.height, self.width), dtype=np.int8)
        self.cone_map = []  # Persistent list of detected cones
        self.vehicle_path = []

        # Logging
        self.get_logger().info("LIO-SAM Integration Node Initialized")

        # Create a timer to periodically publish markers and update map
        self.create_timer(1.0, self.periodic_update)

    def extract_points_from_raw_data(self, msg):
        """
        Manually extract points from raw PointCloud2 message data
        """
        points = []
        point_step = msg.point_step
        offset_x = msg.fields[0].offset
        offset_y = msg.fields[1].offset
        offset_z = msg.fields[2].offset

        for i in range(0, len(msg.data), point_step):
            # Extract x, y, z coordinates using struct
            x = struct.unpack('f', msg.data[i+offset_x:i+offset_x+4])[0]
            y = struct.unpack('f', msg.data[i+offset_y:i+offset_y+4])[0]
            z = struct.unpack('f', msg.data[i+offset_z:i+offset_z+4])[0]
            
            points.append([x, y, z])
        
        return np.array(points)

    def lidar_callback(self, msg):
        try:
            # Extract points manually
            points = self.extract_points_from_raw_data(msg)
            
            self.get_logger().info(f"Received {len(points)} points")
            
            # Cone detection 
            cones = self.detect_cones(points)
            
            # Fuse new cones with existing cones
            self.fuse_cones(cones)
            
            # Update map with cones
            self.update_occupancy_grid()
            
            # Publish cone markers
            self.publish_cone_markers()

        except Exception as e:
            self.get_logger().error(f"Error in LiDAR callback: {str(e)}")
            import traceback
            traceback.print_exc()

    def detect_cones(self, points):
        """Detect cones using advanced filtering and clustering"""
        # Avoid errors with empty points
        if len(points) == 0:
            return []

        try:
            # Extensive logging of point cloud characteristics
            self.get_logger().info(f"Total points: {len(points)}")
            self.get_logger().info(f"Z range: {np.min(points[:, 2])} to {np.max(points[:, 2])}")
            self.get_logger().info(f"XY distance range: {np.min(np.linalg.norm(points[:, :2], axis=1))} to {np.max(np.linalg.norm(points[:, :2], axis=1))}")

            # More sophisticated ground height estimation
            # Use median and percentile to reduce noise
            z_values = points[:, 2]
            ground_percentile = np.percentile(z_values, 10)  # 10th percentile as ground level
            
            # Flexible cone height filtering
            cone_points = points[
                (z_values > ground_percentile + 0.1) &  # Above ground
                (z_values < ground_percentile + 1.5) &  # Extended max cone height
                (np.linalg.norm(points[:, :2], axis=1) < 50)  # Increased detection range
            ]

            self.get_logger().info(f"Cone filtering results:")
            self.get_logger().info(f"Ground percentile: {ground_percentile}")
            self.get_logger().info(f"Filtered cone points: {len(cone_points)}")

            # If not enough points, return empty list
            if len(cone_points) < 3:
                self.get_logger().warn(f"Not enough cone points. Current points: {len(cone_points)}")
                return []

            # More flexible DBSCAN parameters
            clustering = DBSCAN(
                eps=0.3,     # Smaller distance threshold
                min_samples=2  # Reduced minimum samples
            ).fit(cone_points[:, :2])
            
            # Get cluster centers with more robust method
            cones = []
            unique_labels = np.unique(clustering.labels_)
            for label in unique_labels:
                if label == -1:  # Skip noise points
                    continue
                
                cluster = cone_points[clustering.labels_ == label]
                
                # Weighted center calculation (considering point density)
                if len(cluster) > 0:
                    cone_center = np.average(cluster[:, :2], axis=0)
                    cones.append(cone_center)

            self.get_logger().info(f"Detected {len(cones)} cones")
            
            # Debug: print cone locations
            for i, cone in enumerate(cones):
                self.get_logger().info(f"Cone {i}: {cone}")
            
            return cones

        except Exception as e:
            self.get_logger().error(f"Cone detection error: {str(e)}")
            import traceback
            traceback.print_exc()
            return []

    def fuse_cones(self, new_cones):
        """
        Fuse new cone detections with existing cone map
        Merge cones that are close together
        """
        if not new_cones:
            return

        # If no existing cones, add all new cones
        if not self.cone_map:
            self.cone_map.extend(new_cones)
            return

        # Convert to numpy for easier computation
        existing_cones = np.array(self.cone_map)
        new_cones = np.array(new_cones)

        # Compute pairwise distances
        for new_cone in new_cones:
            # Check if this cone is close to any existing cone
            distances = distance.cdist([new_cone], existing_cones)
            min_dist = np.min(distances)

            if min_dist > self.cone_fusion_distance:
                # If no close existing cone, add as new
                self.cone_map.append(new_cone.tolist())
            else:
                # If close to an existing cone, update the existing cone's position
                closest_idx = np.argmin(distances)
                # Weighted average - give more weight to existing cone
                self.cone_map[closest_idx] = [
                    (self.cone_map[closest_idx][0] * 0.7 + new_cone[0] * 0.3),
                    (self.cone_map[closest_idx][1] * 0.7 + new_cone[1] * 0.3)
                ]

        # Log total number of cones
        self.get_logger().info(f"Total unique cones: {len(self.cone_map)}")

    def update_occupancy_grid(self):
        """Update occupancy grid with cone positions"""
        # Reset grid
        self.grid_map = np.zeros((self.height, self.width), dtype=np.int8)

        for x, y in self.cone_map:
            # Convert to grid coordinates
            gx = int(self.width/2 + x / self.resolution)
            gy = int(self.height/2 + y / self.resolution)
            
            # Check grid bounds
            if 0 <= gx < self.width and 0 <= gy < self.height:
                # Mark as occupied
                self.grid_map[gy, gx] = 100

        # Publish occupancy grid
        self.publish_occupancy_grid()

    def publish_cone_markers(self):
        """Publish cone markers for visualization"""
        marker_array = MarkerArray()
        
        for i, (x, y) in enumerate(self.cone_map):
            marker = Marker()
            marker.header.frame_id = 'map'
            marker.header.stamp = self.get_clock().now().to_msg()
            marker.id = i
            marker.type = Marker.CYLINDER
            marker.action = Marker.ADD
            
            # Marker positioning
            marker.pose.position.x = float(x)
            marker.pose.position.y = float(y)
            marker.pose.position.z = 0.25  # Half cone height
            
            # Marker size
            marker.scale.x = 0.3  # Diameter
            marker.scale.y = 0.3
            marker.scale.z = 0.5  # Height
            
            # Marker color (yellow)
            marker.color.r = 1.0
            marker.color.g = 1.0
            marker.color.b = 0.0
            marker.color.a = 0.8
            
            marker_array.markers.append(marker)
        
        self.cone_marker_pub.publish(marker_array)

    def publish_occupancy_grid(self):
        """Publish the current occupancy grid"""
        grid_msg = OccupancyGrid()
        grid_msg.header.frame_id = 'map'
        grid_msg.header.stamp = self.get_clock().now().to_msg()
        
        grid_msg.info.resolution = self.resolution
        grid_msg.info.width = self.width
        grid_msg.info.height = self.height
        
        # Set origin at grid center
        grid_msg.info.origin.position.x = -self.width * self.resolution / 2
        grid_msg.info.origin.position.y = -self.height * self.resolution / 2
        
        # Flatten grid map to list
        grid_msg.data = self.grid_map.flatten().tolist()
        
        self.occupancy_grid_pub.publish(grid_msg)

    def periodic_update(self):
        """Periodically update and save markers"""
        if self.cone_map:
            # Publish markers to keep them visible
            self.publish_cone_markers()
            
            # Periodically save map
            self.save_map()

    def path_callback(self, msg):
        """Store vehicle path from LIO-SAM"""
        # Store path for potential future use
        self.vehicle_path = [(pose.pose.position.x, pose.pose.position.y) for pose in msg.poses]

    def save_map(self):
        """Save map visualization and data"""
        try:
            # Create visualization
            plt.figure(figsize=(10, 10))
            plt.imshow(self.grid_map, cmap='gray', interpolation='nearest')
            plt.title('LIO-SAM Occupancy Grid')
            plt.colorbar(label='Occupancy Probability')
            
            # Save figure
            map_path = os.path.join(self.output_dir, 'maps', 'occupancy_grid.png')
            plt.savefig(map_path)
            plt.close()

            # Save cone data
            cone_path = os.path.join(self.output_dir, 'maps', 'cones.csv')
            with open(cone_path, 'w') as f:
                f.write("x,y\n")
                for x, y in self.cone_map:
                    f.write(f"{x},{y}\n")
            
            self.get_logger().info(f"Map and {len(self.cone_map)} cones saved")

        except Exception as e:
            self.get_logger().error(f"Error saving map: {str(e)}")

def main(args=None):
    rclpy.init(args=args)
    node = LIOSAMIntegration()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.save_map()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()