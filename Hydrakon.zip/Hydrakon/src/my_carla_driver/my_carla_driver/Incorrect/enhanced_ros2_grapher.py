#!/usr/bin/env python3
# enhanced_ros2_grapher.py

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from sensor_msgs.msg import PointCloud2
from std_msgs.msg import Float32
from visualization_msgs.msg import MarkerArray
from geometry_msgs.msg import Twist
import matplotlib.pyplot as plt
import numpy as np
import os
import time
from datetime import datetime
import threading
import signal
import sys

class EnhancedDataCollector(Node):
    def __init__(self):
        super().__init__('enhanced_data_collector')
        
        # Create output directory
        self.output_dir = "./thesis_results"
        os.makedirs(self.output_dir, exist_ok=True)
        
        # Data storage
        self.data = {
            'timestamps': [],
            'speed': [],
            'steering': [],
            'yellow_cones': [],
            'blue_cones': [],
            'total_cones': [],
            'lidar_points': [],
            'start_time': time.time()
        }
        
        # Current values (updated by callbacks)
        self.current = {
            'speed': 0.0,
            'steering': 0.0,
            'yellow_cones': 0,
            'blue_cones': 0,
            'lidar_points': 0
        }
        
        # Create QoS profile for sensor data
        sensor_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )
        
        # List all topics and subscribe to relevant ones
        self.discover_and_subscribe()
        
        # Timer for data collection
        self.data_timer = self.create_timer(0.1, self.record_datapoint)
        
        # Timer for graphing
        self.graph_timer = self.create_timer(5.0, self.generate_graphs)
        
        self.get_logger().info(f"Enhanced data collector started. Saving to: {self.output_dir}")
        
        # Setup signal handling
        signal.signal(signal.SIGINT, self.signal_handler)
    
    def discover_and_subscribe(self):
        """List all topics and subscribe to relevant ones."""
        topics = self.get_topic_names_and_types()
        self.get_logger().info(f"Found {len(topics)} topics")
        
        # Track subscribed topics
        subscribed = []
        
        for topic_name, types in topics:
            # Skip if no types available
            if not types:
                continue
                
            # Get the first type
            topic_type = types[0]
            
            # Check for PointCloud2 topics
            if ('lidar' in topic_name.lower() or 'point' in topic_name.lower()) and 'PointCloud2' in topic_type:
                self.create_subscription(PointCloud2, topic_name, self.lidar_callback, 10)
                subscribed.append(f"LiDAR: {topic_name}")
            
            # Check for marker array topics (cones)
            elif ('cone' in topic_name.lower() or 'marker' in topic_name.lower()) and 'MarkerArray' in topic_type:
                self.create_subscription(MarkerArray, topic_name, self.cones_callback, 10)
                subscribed.append(f"Cones: {topic_name}")
            
            # Check for speed/velocity topics
            elif ('speed' in topic_name.lower() or 'vel' in topic_name.lower()) and 'Float32' in topic_type:
                self.create_subscription(Float32, topic_name, self.speed_callback, 10)
                subscribed.append(f"Speed: {topic_name}")
            
            # Check for steering topics
            elif 'steer' in topic_name.lower() and 'Float32' in topic_type:
                self.create_subscription(Float32, topic_name, self.steering_callback, 10)
                subscribed.append(f"Steering: {topic_name}")
            
            # Check for Twist message topics (may contain speed)
            elif ('cmd_vel' in topic_name or 'velocity' in topic_name.lower()) and 'Twist' in topic_type:
                try:
                    self.create_subscription(Twist, topic_name, self.twist_callback, 10)
                    subscribed.append(f"Twist (velocity): {topic_name}")
                except Exception as e:
                    self.get_logger().error(f"Error subscribing to {topic_name}: {e}")
        
        # Log subscribed topics
        if subscribed:
            self.get_logger().info("Subscribed to these topics:")
            for topic in subscribed:
                self.get_logger().info(f"  {topic}")
        else:
            self.get_logger().warning("No relevant topics found to subscribe to!")
            
        # Add manual subscriptions for common topics that might not show up in discovery
        try:
            # Add additional subscribers for common topic names
            self.create_subscription(PointCloud2, '/carla/lidar_points', self.lidar_callback, 10)
            self.create_subscription(MarkerArray, '/carla/lidar_cones', self.cones_callback, 10)
            self.create_subscription(Float32, '/carla/speed', self.speed_callback, 10)
            self.create_subscription(Float32, '/carla/steering', self.steering_callback, 10)
            self.get_logger().info("Added manual subscriptions for common topics")
        except Exception as e:
            self.get_logger().warning(f"Error adding manual subscriptions: {e}")
    
    def lidar_callback(self, msg):
        """Process LiDAR point cloud data."""
        # Estimate number of points from message size
        # Each point is typically 16 bytes (4 floats, 4 bytes each)
        points_estimate = len(msg.data) // 16
        self.current['lidar_points'] = points_estimate
    
    def cones_callback(self, msg):
        """Process cone marker data."""
        yellow_count = 0
        blue_count = 0
        
        for marker in msg.markers:
            # Check color to determine cone type
            # Yellow cone
            if (marker.color.r > 0.5 and marker.color.g > 0.5 and marker.color.b < 0.3):
                yellow_count += 1
            # Blue cone
            elif (marker.color.r < 0.3 and marker.color.g < 0.3 and marker.color.b > 0.5):
                blue_count += 1
        
        self.current['yellow_cones'] = yellow_count
        self.current['blue_cones'] = blue_count
    
    def speed_callback(self, msg):
        """Process speed data."""
        self.current['speed'] = msg.data
    
    def steering_callback(self, msg):
        """Process steering data."""
        self.current['steering'] = msg.data
    
    def twist_callback(self, msg):
        """Process Twist messages for velocity."""
        # Calculate speed as magnitude of linear velocity
        speed = np.sqrt(msg.linear.x**2 + msg.linear.y**2 + msg.linear.z**2)
        self.current['speed'] = speed
    
    def record_datapoint(self):
        """Record the current values to the time series data."""
        now = time.time()
        self.data['timestamps'].append(now - self.data['start_time'])
        
        # Copy current values to time series
        self.data['speed'].append(self.current['speed'])
        self.data['steering'].append(self.current['steering'])
        self.data['yellow_cones'].append(self.current['yellow_cones'])
        self.data['blue_cones'].append(self.current['blue_cones'])
        self.data['total_cones'].append(self.current['yellow_cones'] + self.current['blue_cones'])
        self.data['lidar_points'].append(self.current['lidar_points'])
    
    def signal_handler(self, sig, frame):
        """Handle Ctrl+C properly."""
        self.get_logger().info("Received shutdown signal, generating final graphs...")
        self.generate_graphs()
        self.get_logger().info(f"Graphs saved to {self.output_dir}")
        sys.exit(0)
    
    def generate_graphs(self):
        """Generate all thesis graphs from collected data."""
        if len(self.data['timestamps']) < 10:
            self.get_logger().info("Not enough data points yet for graphing...")
            return
            
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Generate individual graphs
        self.generate_speed_graph(timestamp)
        self.generate_cone_detection_graph(timestamp)
        self.generate_lidar_graph(timestamp)
        
        # Generate dashboard
        self.generate_dashboard(timestamp)
        
        self.get_logger().info(f"Generated graphs with timestamp {timestamp}")
    
    def generate_speed_graph(self, timestamp):
        """Generate a graph of vehicle speed over time."""
        try:
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.plot(self.data['timestamps'], self.data['speed'], 'b-', linewidth=2)
            
            # Add moving average if we have enough points
            if len(self.data['speed']) > 10:
                window_size = 10
                avg = np.convolve(self.data['speed'], np.ones(window_size)/window_size, mode='valid')
                avg_time = self.data['timestamps'][window_size-1:]
                ax.plot(avg_time, avg, 'r-', linewidth=2, alpha=0.7, label='10-point Moving Avg')
                ax.legend()
            
            ax.set_xlabel('Time (seconds)', fontsize=12)
            ax.set_ylabel('Speed (m/s)', fontsize=12)
            ax.set_title('Vehicle Speed', fontsize=14)
            ax.grid(True)
            
            # Add mph scale on right y-axis
            ax_mph = ax.twinx()
            ax_mph.set_ylabel('Speed (mph)', fontsize=12, color='g')
            ax_mph.spines['right'].set_color('g')
            ax_mph.tick_params(axis='y', colors='g')
            
            # Convert m/s to mph
            try:
                min_speed = min(self.data['speed']) * 2.237
                max_speed = max(self.data['speed']) * 2.237
                ax_mph.set_ylim(min_speed, max_speed)
            except:
                pass  # Skip if no valid data

            # Add statistics
            avg_speed = np.mean(self.data['speed'])
            max_speed = np.max(self.data['speed'])
            stats_text = f"Average: {avg_speed:.2f} m/s ({avg_speed*2.237:.2f} mph)\n"
            stats_text += f"Maximum: {max_speed:.2f} m/s ({max_speed*2.237:.2f} mph)"
                
            plt.figtext(0.15, 0.02, stats_text, fontsize=10, 
                       bbox=dict(facecolor='white', alpha=0.8, boxstyle='round'))
            
            output_file = os.path.join(self.output_dir, 'thesis_speed_graph.png')
            plt.savefig(output_file, dpi=300, bbox_inches='tight')
            plt.close(fig)
            
            self.get_logger().info(f"Speed graph saved to {output_file}")
            
        except Exception as e:
            self.get_logger().error(f"Error generating speed graph: {e}")
    
    def generate_cone_detection_graph(self, timestamp):
        """Generate graph of cone detections over time."""
        try:
            fig, ax = plt.subplots(figsize=(10, 6))
            
            ax.plot(self.data['timestamps'], self.data['yellow_cones'], 'y-', linewidth=2, label='Yellow Cones')
            ax.plot(self.data['timestamps'], self.data['blue_cones'], 'b-', linewidth=2, label='Blue Cones')
            ax.plot(self.data['timestamps'], self.data['total_cones'], 'g-', linewidth=2, label='Total Cones')
            
            ax.set_xlabel('Time (seconds)', fontsize=12)
            ax.set_ylabel('Cone Count', fontsize=12)
            ax.set_title('Cone Detection Counts', fontsize=14)
            ax.grid(True)
            ax.legend()
            
            # Add statistics
            avg_yellow = np.mean(self.data['yellow_cones'])
            avg_blue = np.mean(self.data['blue_cones'])
            avg_total = np.mean(self.data['total_cones'])
            stats_text = f"Avg Yellow: {avg_yellow:.1f}\n"
            stats_text += f"Avg Blue: {avg_blue:.1f}\n"
            stats_text += f"Avg Total: {avg_total:.1f}"
                
            plt.figtext(0.15, 0.02, stats_text, fontsize=10,
                       bbox=dict(facecolor='white', alpha=0.8, boxstyle='round'))
            
            output_file = os.path.join(self.output_dir, 'thesis_cone_detection.png')
            plt.savefig(output_file, dpi=300, bbox_inches='tight')
            plt.close(fig)
            
            self.get_logger().info(f"Cone detection graph saved to {output_file}")
            
        except Exception as e:
            self.get_logger().error(f"Error generating cone detection graph: {e}")
    
    def generate_lidar_graph(self, timestamp):
        """Generate a graph of LiDAR point counts over time."""
        try:
            if not self.data['lidar_points']:
                self.get_logger().warn("No LiDAR point data available")
                return
                
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.plot(self.data['timestamps'], self.data['lidar_points'], 'm-', linewidth=2)
            
            ax.set_xlabel('Time (seconds)', fontsize=12)
            ax.set_ylabel('Point Count', fontsize=12)
            ax.set_title('LiDAR Point Count', fontsize=14)
            ax.grid(True)
            
            # Add statistics
            if self.data['lidar_points']:
                avg_points = np.mean(self.data['lidar_points'])
                max_points = np.max(self.data['lidar_points'])
                min_points = np.min(self.data['lidar_points'])
                stats_text = f"Average: {avg_points:.0f} points\n"
                stats_text += f"Maximum: {max_points:.0f} points\n"
                stats_text += f"Minimum: {min_points:.0f} points"
                
                plt.figtext(0.15, 0.02, stats_text, fontsize=10, 
                           bbox=dict(facecolor='white', alpha=0.8, boxstyle='round'))
            
            output_file = os.path.join(self.output_dir, 'thesis_lidar_graph.png')
            plt.savefig(output_file, dpi=300, bbox_inches='tight')
            plt.close(fig)
            
            self.get_logger().info(f"LiDAR graph saved to {output_file}")
            
        except Exception as e:
            self.get_logger().error(f"Error generating LiDAR graph: {e}")
    
    def generate_dashboard(self, timestamp):
        """Generate comprehensive dashboard of all metrics."""
        try:
            fig = plt.figure(figsize=(15, 10))
            fig.suptitle('Cone Detection & Navigation Performance Dashboard', fontsize=18)
            
            # Create 2x2 grid for plots
            gs = fig.add_gridspec(2, 2)
            
            # 1. Speed plot (top left)
            ax1 = fig.add_subplot(gs[0, 0])
            ax1.plot(self.data['timestamps'], self.data['speed'], 'b-', linewidth=2)
            if len(self.data['speed']) > 10:
                window_size = 10
                avg = np.convolve(self.data['speed'], np.ones(window_size)/window_size, mode='valid')
                avg_time = self.data['timestamps'][window_size-1:]
                ax1.plot(avg_time, avg, 'r-', linewidth=2, alpha=0.7)
            ax1.set_xlabel('Time (s)')
            ax1.set_ylabel('Speed (m/s)')
            ax1.set_title('Vehicle Speed')
            ax1.grid(True)
            
            # 2. Cone counts (top right)
            ax2 = fig.add_subplot(gs[0, 1])
            ax2.plot(self.data['timestamps'], self.data['yellow_cones'], 'y-', linewidth=2, label='Yellow')
            ax2.plot(self.data['timestamps'], self.data['blue_cones'], 'b-', linewidth=2, label='Blue')
            ax2.plot(self.data['timestamps'], self.data['total_cones'], 'g-', linewidth=2, label='Total')
            ax2.set_xlabel('Time (s)')
            ax2.set_ylabel('Count')
            ax2.set_title('Cone Detections')
            ax2.grid(True)
            ax2.legend()
            
            # 3. LiDAR points (bottom left)
            ax3 = fig.add_subplot(gs[1, 0])
            ax3.plot(self.data['timestamps'], self.data['lidar_points'], 'm-', linewidth=2)
            ax3.set_xlabel('Time (s)')
            ax3.set_ylabel('Point Count')
            ax3.set_title('LiDAR Point Count')
            ax3.grid(True)
            
            # 4. Steering (bottom right)
            ax4 = fig.add_subplot(gs[1, 1])
            ax4.plot(self.data['timestamps'], self.data['steering'], 'r-', linewidth=2)
            ax4.set_xlabel('Time (s)')
            ax4.set_ylabel('Steering Angle')
            ax4.set_title('Steering Control')
            ax4.set_ylim(-1.1, 1.1)  # Normalized steering range
            ax4.grid(True)
            
            # Add timestamp and statistics
            timestamp_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            plt.figtext(0.01, 0.01, f"Generated: {timestamp_str}", ha='left', fontsize=8)
            
            # Add some overall statistics
            stats = []
            stats.append(f"Avg Speed: {np.mean(self.data['speed']):.2f} m/s")
            stats.append(f"Avg Cones: {np.mean(self.data['total_cones']):.1f}")
            stats.append(f"Avg LiDAR Points: {int(np.mean(self.data['lidar_points']))}")
            
            stats_text = "\n".join(stats)
            plt.figtext(0.5, 0.01, stats_text, ha='center', fontsize=10,
                       bbox=dict(facecolor='white', alpha=0.8, boxstyle='round'))
            
            plt.tight_layout(rect=[0, 0.03, 1, 0.95])
            
            output_file = os.path.join(self.output_dir, 'thesis_dashboard.png')
            plt.savefig(output_file, dpi=300, bbox_inches='tight')
            plt.close(fig)
            
            self.get_logger().info(f"Dashboard saved to {output_file}")
            
        except Exception as e:
            self.get_logger().error(f"Error generating dashboard: {e}")

def main(args=None):
    rclpy.init(args=args)
    
    node = EnhancedDataCollector()
    
    try:
        spin_thread = threading.Thread(target=rclpy.spin, args=(node,))
        spin_thread.start()
        spin_thread.join()
    except KeyboardInterrupt:
        print("User interrupted execution. Generating final graphs...")
        node.generate_graphs()
        print(f"Graphs saved to {node.output_dir}")
    except Exception as e:
        print(f"Error in main: {e}")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main() 