import numpy as np
from sklearn.cluster import DBSCAN
from scipy.spatial import KDTree
import matplotlib.pyplot as plt
import os
from datetime import datetime
import cv2

class CartographerMapper:
    """
    Cartographer-style mapping system that creates a global map from LiDAR data
    and tracks cone positions for Formula Student racing.
    """
    def __init__(self, resolution=0.1, width=1000, height=1000, output_dir="./mapping_results"):
        """
        Initialize the Cartographer mapper.
        
        Args:
            resolution: Map resolution in meters per cell
            width: Map width in cells
            height: Map height in cells
            output_dir: Directory for visualization outputs
        """
        # Map grid configuration
        self.resolution = resolution
        self.width = width
        self.height = height
        self.output_dir = output_dir
        
        # Create grid map initialized as unknown (0)
        # 0 = unknown, 1 = free, 2 = occupied
        self.grid_map = np.zeros((height, width), dtype=np.uint8)
        
        # Map origin (grid center corresponds to global origin)
        self.origin_x = width // 2
        self.origin_y = height // 2
        
        # Cone map storage
        self.cone_map = []  # list of (x, y, class) tuples
        # Class: 0 = yellow, 1 = blue, 2 = unknown
        
        # History of vehicle poses for path optimization
        self.vehicle_poses = []  # List of (x, y, yaw) in world frame
        self.pose_times = []     # Timestamps for poses
        
        # Track statistics
        self.update_count = 0
        self.total_cone_updates = 0
        self.total_new_cones = 0
        
        # KDTree for efficient cone lookups (rebuilt on updates)
        self.cone_tree = None
        
        # Clustering parameters
        self.cluster_eps = 0.5     # Clustering distance threshold
        self.cluster_min_samples = 2  # Minimum samples in a cluster
        
        # Fusion settings
        self.fusion_threshold = 1.0  # Distance threshold for fusing cone detections
        
        # Visualization settings
        self.visualize = True
        
        # Probability settings
        self.prob_hit = 0.65      # Probability of hit given obstacle
        self.prob_miss = 0.35     # Probability of miss given no obstacle
        self.prob_prior = 0.5     # Prior probability of occupancy
        
        # Log odds representation of probabilities
        self.log_odds_hit = np.log(self.prob_hit / (1 - self.prob_hit))
        self.log_odds_miss = np.log(self.prob_miss / (1 - self.prob_miss))
        self.log_odds_prior = np.log(self.prob_prior / (1 - self.prob_prior))
        
        # Log odds grid (used for probabilistic mapping)
        self.log_odds_grid = np.zeros((height, width), dtype=np.float32)
        
        # Create output directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)
        
        # Create a subfolder for maps
        self.maps_dir = os.path.join(output_dir, "maps")
        os.makedirs(self.maps_dir, exist_ok=True)
        
        # Store timestamp of last map update
        self.last_update_time = datetime.now()
        
        print(f"Cartographer mapper initialized with {width}x{height} grid at {resolution}m resolution")
    
    def update_vehicle_pose(self, x, y, yaw):
        """
        Update the current vehicle pose.
        
        Args:
            x, y: Position in world coordinates
            yaw: Orientation in radians
        
        Returns:
            None
        """
        # Check if this is significantly different from previous pose
        if len(self.vehicle_poses) > 0:
            prev_x, prev_y, prev_yaw = self.vehicle_poses[-1]
            dist = np.sqrt((x - prev_x)**2 + (y - prev_y)**2)
            angle_diff = abs(np.arctan2(np.sin(yaw - prev_yaw), np.cos(yaw - prev_yaw)))
            
            # Only add if moved at least 0.1m or 0.1 rad
            if dist < 0.1 and angle_diff < 0.1:
                return
        
        self.vehicle_poses.append((x, y, yaw))
        self.pose_times.append(datetime.now())
        
        # Keep only the last 1000 poses to limit memory usage
        if len(self.vehicle_poses) > 1000:
            self.vehicle_poses = self.vehicle_poses[-1000:]
            self.pose_times = self.pose_times[-1000:]
    
    def world_to_grid(self, wx, wy):
        """
        Convert world coordinates to grid coordinates.
        
        Args:
            wx, wy: World coordinates
        
        Returns:
            gx, gy: Grid coordinates
        """
        gx = int(self.origin_x + wx / self.resolution)
        gy = int(self.origin_y + wy / self.resolution)
        return gx, gy
    
    def grid_to_world(self, gx, gy):
        """
        Convert grid coordinates to world coordinates.
        
        Args:
            gx, gy: Grid coordinates
        
        Returns:
            wx, wy: World coordinates
        """
        wx = (gx - self.origin_x) * self.resolution
        wy = (gy - self.origin_y) * self.resolution
        return wx, wy
    
    def is_in_grid(self, gx, gy):
        """Check if grid coordinates are within the map bounds."""
        return (0 <= gx < self.width) and (0 <= gy < self.height)
    
    def update_map(self, cone_positions, cone_classes, vehicle_pose):
        """
        Update the map with new cone detections.
        
        Args:
            cone_positions: List of (x, y) cone positions in world coordinates
            cone_classes: List of cone classes (0=yellow, 1=blue, 2=unknown)
            vehicle_pose: (x, y, yaw) vehicle pose in world frame
        
        Returns:
            Number of new cones added
        """
        if not cone_positions:
            return 0
        
        # Update vehicle pose
        self.update_vehicle_pose(*vehicle_pose)
        
        # Update occupancy grid map
        self.update_grid_map(cone_positions, vehicle_pose)
        
        # Update cone map
        new_cones = self.update_cone_map(cone_positions, cone_classes)
        
        # Cluster map to remove duplicates
        num_clusters = self.cluster_map()
        
        # Increment update counter
        self.update_count += 1
        
        # Periodically save map visualization
        if self.update_count % 100 == 0:
            self.save_visualization()
        
        return new_cones
    
    def update_grid_map(self, cone_positions, vehicle_pose):
        """
        Update the grid map using ray casting from vehicle to cones.
        
        Args:
            cone_positions: List of (x, y) cone positions
            vehicle_pose: (x, y, yaw) vehicle pose
        
        Returns:
            None
        """
        veh_x, veh_y, _ = vehicle_pose
        
        # Convert vehicle position to grid coordinates
        veh_gx, veh_gy = self.world_to_grid(veh_x, veh_y)
        
        # Skip if vehicle is outside the grid
        if not self.is_in_grid(veh_gx, veh_gy):
            return
        
        # Mark cells along vehicle trajectory as free
        if len(self.vehicle_poses) >= 2:
            prev_x, prev_y, _ = self.vehicle_poses[-2]
            prev_gx, prev_gy = self.world_to_grid(prev_x, prev_y)
            
            if self.is_in_grid(prev_gx, prev_gy):
                # Use Bresenham's line algorithm to mark cells between poses
                self.mark_line_as_free(prev_gx, prev_gy, veh_gx, veh_gy)
        
        # Process each cone detection
        for x, y in cone_positions:
            # Convert to grid coordinates
            gx, gy = self.world_to_grid(x, y)
            
            # Skip if outside grid
            if not self.is_in_grid(gx, gy):
                continue
            
            # Mark the cone cell as occupied
            self.mark_cell_as_occupied(gx, gy)
            
            # Mark cells along the ray as free (except near the cone)
            self.mark_ray_as_free(veh_gx, veh_gy, gx, gy)
    
    def mark_cell_as_occupied(self, gx, gy):
        """Mark a cell as occupied using log-odds."""
        # Update log-odds
        self.log_odds_grid[gy, gx] += self.log_odds_hit
        
        # Clamp to avoid overflow
        self.log_odds_grid[gy, gx] = min(20.0, self.log_odds_grid[gy, gx])
        
        # Convert to probability and update grid map
        if self.log_odds_grid[gy, gx] > 0:
            self.grid_map[gy, gx] = 2  # Occupied
    
    def mark_cell_as_free(self, gx, gy):
        """Mark a cell as free using log-odds."""
        # Update log-odds
        self.log_odds_grid[gy, gx] -= self.log_odds_miss
        
        # Clamp to avoid underflow
        self.log_odds_grid[gy, gx] = max(-20.0, self.log_odds_grid[gy, gx])
        
        # Convert to probability and update grid map
        if self.log_odds_grid[gy, gx] < 0:
            self.grid_map[gy, gx] = 1  # Free
    
    def mark_ray_as_free(self, start_x, start_y, end_x, end_y):
        """
        Mark cells along a ray as free, except near the endpoint.
        
        Args:
            start_x, start_y: Start point in grid coordinates
            end_x, end_y: End point in grid coordinates
        
        Returns:
            None
        """
        # Calculate distance
        dx = end_x - start_x
        dy = end_y - start_y
        distance = np.sqrt(dx*dx + dy*dy)
        
        if distance < 1:
            return
        
        # Number of steps
        steps = int(distance)
        
        # Only mark up to 95% of the ray as free (to avoid marking the obstacle)
        for i in range(1, int(steps * 0.95)):
            # Interpolate point
            ratio = i / steps
            gx = int(start_x + dx * ratio)
            gy = int(start_y + dy * ratio)
            
            # Skip if outside grid
            if not self.is_in_grid(gx, gy):
                continue
            
            # Mark as free
            self.mark_cell_as_free(gx, gy)
    
    def mark_line_as_free(self, start_x, start_y, end_x, end_y):
        """
        Mark cells along a line as free using Bresenham's algorithm.
        
        Args:
            start_x, start_y: Start point in grid coordinates
            end_x, end_y: End point in grid coordinates
        
        Returns:
            None
        """
        # Bresenham's line algorithm
        dx = abs(end_x - start_x)
        dy = abs(end_y - start_y)
        sx = 1 if start_x < end_x else -1
        sy = 1 if start_y < end_y else -1
        err = dx - dy
        
        x, y = start_x, start_y
        
        while True:
            # Mark current cell as free
            if self.is_in_grid(x, y):
                self.mark_cell_as_free(x, y)
            
            # Break if reached end point
            if x == end_x and y == end_y:
                break
            
            # Update coordinates
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x += sx
            if e2 < dx:
                err += dx
                y += sy
    
    def update_cone_map(self, cone_positions, cone_classes):
        """
        Update the cone map with new detections.
        
        Args:
            cone_positions: List of (x, y) cone positions
            cone_classes: List of cone classes
        
        Returns:
            Number of new cones added
        """
        if not cone_positions:
            return 0
        
        new_cones = 0
        
        # Initialize KDTree if needed
        if not self.cone_tree and self.cone_map:
            cone_positions_array = np.array([[x, y] for x, y, _ in self.cone_map])
            self.cone_tree = KDTree(cone_positions_array)
        
        # Process each cone
        for (x, y), cls in zip(cone_positions, cone_classes):
            # If we have a KDTree, check for nearby cones
            if self.cone_tree and len(self.cone_map) > 0:
                # Query KDTree for nearest cone
                dist, idx = self.cone_tree.query([x, y])
                
                # If close enough, update existing cone
                if dist < self.fusion_threshold:
                    existing_x, existing_y, existing_cls = self.cone_map[idx]
                    
                    # Update position (weighted average)
                    weight = 0.3  # Weight for new detection
                    updated_x = (1 - weight) * existing_x + weight * x
                    updated_y = (1 - weight) * existing_y + weight * y
                    
                    # Keep class if it's known, otherwise update
                    updated_cls = existing_cls if existing_cls != 2 else cls
                    
                    # Update cone
                    self.cone_map[idx] = (updated_x, updated_y, updated_cls)
                    self.total_cone_updates += 1
                    continue
            
            # Add new cone
            self.cone_map.append((x, y, cls))
            new_cones += 1
            self.total_new_cones += 1
        
        # Rebuild KDTree
        if self.cone_map:
            cone_positions_array = np.array([[x, y] for x, y, _ in self.cone_map])
            self.cone_tree = KDTree(cone_positions_array)
        
        return new_cones
    
    def cluster_map(self, eps=None, min_samples=None):
        """
        Cluster the map to remove duplicate cones and reduce noise.
        
        Args:
            eps: Maximum distance between cones to be considered the same
            min_samples: Minimum number of samples in a cluster
            
        Returns:
            Number of clusters (unique cones)
        """
        if len(self.cone_map) < 2:
            return len(self.cone_map)
        
        # Use instance parameters if not specified
        if eps is None:
            eps = self.cluster_eps
        if min_samples is None:
            min_samples = self.cluster_min_samples
        
        # Extract cone positions
        positions = np.array([[x, y] for x, y, _ in self.cone_map])
        
        # Perform DBSCAN clustering
        clustering = DBSCAN(eps=eps, min_samples=min_samples).fit(positions)
        labels = clustering.labels_
        
        # Group cones by cluster
        clusters = {}
        for i, label in enumerate(labels):
            if label not in clusters:
                clusters[label] = []
            clusters[label].append(i)
        
        # Create a new map with one cone per cluster
        new_map = []
        
        for label, indices in clusters.items():
            if label == -1:  # Noise points
                for idx in indices:
                    new_map.append(self.cone_map[idx])
                continue
            
            # Merge cones in the same cluster
            cluster_cones = [self.cone_map[idx] for idx in indices]
            
            # Count classes in cluster
            cls_counts = {}
            for x, y, cls in cluster_cones:
                if cls not in cls_counts:
                    cls_counts[cls] = 0
                cls_counts[cls] += 1
            
            # Use most common class
            most_common_cls = max(cls_counts.items(), key=lambda x: x[1])[0] if cls_counts else 2
            
            # Calculate average position
            avg_x = sum(x for x, y, _ in cluster_cones) / len(cluster_cones)
            avg_y = sum(y for x, y, _ in cluster_cones) / len(cluster_cones)
            
            new_map.append((avg_x, avg_y, most_common_cls))
        
        # Update the map
        self.cone_map = new_map
        
        # Rebuild KDTree
        if self.cone_map:
            cone_positions_array = np.array([[x, y] for x, y, _ in self.cone_map])
            self.cone_tree = KDTree(cone_positions_array)
        
        return len(new_map)
    
    def get_cones_by_class(self):
        """
        Get cones grouped by class.
        
        Returns:
            Dictionary with keys 0, 1, 2 (yellow, blue, unknown) and values as lists of [x, y] positions
        """
        result = {0: [], 1: [], 2: []}
        
        for x, y, cls in self.cone_map:
            cls = int(cls)
            result[cls].append([x, y])
        
        return result
    
    def get_cone_map_with_confidence(self):
        """
        Get the full cone map with confidence values.
        
        Returns:
            Dictionary with keys 0, 1, 2 (yellow, blue, unknown) and values as lists of [x, y, confidence] positions
        """
        result = {0: [], 1: [], 2: []}
        
        for x, y, cls in self.cone_map:
            cls = int(cls)
            # We don't have confidence values in this implementation, so use 1.0
            result[cls].append([x, y, 1.0])
        
        return result
    
    def get_cones_in_view(self, vehicle_pose, max_distance=20.0, fov_degrees=90):
        """
        Get cones that are currently in the vehicle's field of view.
        
        Args:
            vehicle_pose: (x, y, yaw) in world frame
            max_distance: Maximum distance to consider
            fov_degrees: Field of view in degrees
            
        Returns:
            Dictionary with keys 0, 1, 2 (yellow, blue, unknown) and values as lists of [x, y] positions
            in vehicle frame
        """
        if not self.cone_map:
            return {0: [], 1: [], 2: []}
        
        veh_x, veh_y, veh_yaw = vehicle_pose
        
        # Half FOV in radians
        half_fov = np.radians(fov_degrees / 2)
        
        # Rotation matrix for world to vehicle transform
        cos_yaw = np.cos(-veh_yaw)
        sin_yaw = np.sin(-veh_yaw)
        
        result = {0: [], 1: [], 2: []}
        
        for x, y, cls in self.cone_map:
            # Calculate cone position relative to vehicle
            rel_x = x - veh_x
            rel_y = y - veh_y
            
            # Calculate distance and angle
            distance = np.sqrt(rel_x**2 + rel_y**2)
            angle = np.arctan2(rel_y, rel_x) - veh_yaw
            
            # Normalize angle to [-pi, pi]
            while angle > np.pi:
                angle -= 2 * np.pi
            while angle < -np.pi:
                angle += 2 * np.pi
            
            # Check if cone is in view
            if distance <= max_distance and abs(angle) <= half_fov:
                # Transform cone to vehicle frame
                veh_frame_x = rel_x * cos_yaw - rel_y * sin_yaw
                veh_frame_y = rel_x * sin_yaw + rel_y * cos_yaw
                
                cls = int(cls)
                result[cls].append([veh_frame_x, veh_frame_y])
        
        return result
    
    def plan_path_using_map(self, vehicle_pose, lookahead_distance=20.0, point_spacing=0.5):
        """
        Plan a path through the mapped cones.
        
        Args:
            vehicle_pose: (x, y, yaw) in world frame
            lookahead_distance: How far ahead to look for target point (in meters)
            point_spacing: Spacing between path points
            
        Returns:
            List of (x, y) waypoints in vehicle frame
        """
        if not self.cone_map:
            return []
        
        # Get cones by class
        cones_by_class = self.get_cones_by_class()
        yellow_cones = cones_by_class[0]
        blue_cones = cones_by_class[1]
        
        if not yellow_cones or not blue_cones:
            return []
        
        veh_x, veh_y, veh_yaw = vehicle_pose
        
        # Determine track segment we're currently on by finding closest cones
        closest_yellow = None
        closest_blue = None
        min_yellow_dist = float('inf')
        min_blue_dist = float('inf')
        
        for cone in yellow_cones:
            dist = np.sqrt((cone[0] - veh_x)**2 + (cone[1] - veh_y)**2)
            if dist < min_yellow_dist:
                min_yellow_dist = dist
                closest_yellow = cone
        
        for cone in blue_cones:
            dist = np.sqrt((cone[0] - veh_x)**2 + (cone[1] - veh_y)**2)
            if dist < min_blue_dist:
                min_blue_dist = dist
                closest_blue = cone
        
        # Calculate forward direction vector
        forward_x = np.cos(veh_yaw)
        forward_y = np.sin(veh_yaw)
        
        # Find cones ahead of vehicle
        ahead_yellow = []
        ahead_blue = []
        
        for cone in yellow_cones:
            # Calculate vector from vehicle to cone
            vec_x = cone[0] - veh_x
            vec_y = cone[1] - veh_y
            
            # Project onto forward direction
            projection = vec_x * forward_x + vec_y * forward_y
            
            # Keep cones ahead of vehicle and within lookahead distance
            if projection > 0 and projection < lookahead_distance:
                ahead_yellow.append(cone + [projection])  # Add projection distance
        
        for cone in blue_cones:
            # Calculate vector from vehicle to cone
            vec_x = cone[0] - veh_x
            vec_y = cone[1] - veh_y
            
            # Project onto forward direction
            projection = vec_x * forward_x + vec_y * forward_y
            
            # Keep cones ahead of vehicle and within lookahead distance
            if projection > 0 and projection < lookahead_distance:
                ahead_blue.append(cone + [projection])  # Add projection distance
        
        # Sort by projection distance
        ahead_yellow.sort(key=lambda c: c[2])
        ahead_blue.sort(key=lambda c: c[2])
        
        if not ahead_yellow or not ahead_blue:
            return []
        
        # Generate waypoints by finding midpoints between cone pairs
        waypoints = []
        
        # First, find cone pairs at similar distances
        max_dist_diff = 3.0  # Maximum distance difference for pairing
        track_width = 3.5  # Default track width
        
        # Determine actual track width from nearby cones
        if closest_yellow and closest_blue:
            track_width = np.sqrt((closest_yellow[0] - closest_blue[0])**2 + 
                                  (closest_yellow[1] - closest_blue[1])**2)
        
        # Generate sample points along the track
        current_dist = 0
        while current_dist < lookahead_distance:
            # Find closest yellow and blue cones
            closest_yellow_idx = None
            closest_blue_idx = None
            min_yellow_diff = float('inf')
            min_blue_diff = float('inf')
            
            for i, cone in enumerate(ahead_yellow):
                diff = abs(cone[2] - current_dist)
                if diff < min_yellow_diff:
                    min_yellow_diff = diff
                    closest_yellow_idx = i
            
            for i, cone in enumerate(ahead_blue):
                diff = abs(cone[2] - current_dist)
                if diff < min_blue_diff:
                    min_blue_diff = diff
                    closest_blue_idx = i
            
            # Generate waypoint if we have both cones
            if closest_yellow_idx is not None and closest_blue_idx is not None:
                yellow_cone = ahead_yellow[closest_yellow_idx]
                blue_cone = ahead_blue[closest_blue_idx]
                
                # Only use pair if they're at similar distances
                if abs(yellow_cone[2] - blue_cone[2]) < max_dist_diff:
                    # Calculate midpoint
                    mid_x = (yellow_cone[0] + blue_cone[0]) / 2
                    mid_y = (yellow_cone[1] + blue_cone[1]) / 2
                    
                    # Transform to vehicle frame
                    rel_x = mid_x - veh_x
                    rel_y = mid_y - veh_y
                    
                    veh_frame_x = rel_x * np.cos(-veh_yaw) - rel_y * np.sin(-veh_yaw)
                    veh_frame_y = rel_x * np.sin(-veh_yaw) + rel_y * np.cos(-veh_yaw)
                    
                    waypoints.append((veh_frame_x, veh_frame_y))
            
            # Move to next distance
            current_dist += point_spacing
        
        return waypoints
    
    def generate_visualization(self):
        """
        Generate a visualization of the grid map and vehicle path.
        
        Returns:
            Visualization image
        """
        # Create RGB visualization image
        rgb_map = np.zeros((self.height, self.width, 3), dtype=np.uint8)
        
        # Colorize grid map
        for y in range(self.height):
            for x in range(self.width):
                if self.grid_map[y, x] == 0:  # Unknown
                    rgb_map[y, x] = [128, 128, 128]  # Gray
                elif self.grid_map[y, x] == 1:  # Free
                    rgb_map[y, x] = [255, 255, 255]  # White
                elif self.grid_map[y, x] == 2:  # Occupied
                    rgb_map[y, x] = [0, 0, 0]       # Black
        
        # Add coordinate system
        # Draw axes at the origin
        origin_x, origin_y = self.origin_x, self.origin_y
        
        # X-axis (red)
        cv2.line(rgb_map, (origin_x, origin_y), (origin_x + 50, origin_y), [0, 0, 255], 1)
        # Y-axis (green)
        cv2.line(rgb_map, (origin_x, origin_y), (origin_x, origin_y - 50), [0, 255, 0], 1)
        
        # Add grid lines every 5 meters
        grid_spacing = int(5.0 / self.resolution)
        for i in range(-10, 11):
            x = origin_x + i * grid_spacing
            if 0 <= x < self.width:
                cv2.line(rgb_map, (x, 0), (x, self.height-1), [80, 80, 80], 1)
        
        for i in range(-10, 11):
            y = origin_y + i * grid_spacing
            if 0 <= y < self.height:
                cv2.line(rgb_map, (0, y), (self.width-1, y), [80, 80, 80], 1)
        
        # Add vehicle path
        if len(self.vehicle_poses) > 1:
            path_points = []
            for x, y, _ in self.vehicle_poses:
                gx, gy = self.world_to_grid(x, y)
                if self.is_in_grid(gx, gy):
                    path_points.append((gx, gy))
            
            if len(path_points) > 1:
                for i in range(len(path_points) - 1):
                    cv2.line(rgb_map, path_points[i], path_points[i+1], [0, 255, 0], 2)
        
        # Add cones
        for x, y, cls in self.cone_map:
            gx, gy = self.world_to_grid(x, y)
            if self.is_in_grid(gx, gy):
                if cls == 0:  # Yellow
                    color = [0, 255, 255]  # Yellow in BGR
                elif cls == 1:  # Blue
                    color = [255, 0, 0]    # Blue in BGR
                else:  # Unknown
                    color = [192, 192, 192]  # Light gray
                
                cv2.circle(rgb_map, (gx, gy), 4, color, -1)
                cv2.circle(rgb_map, (gx, gy), 5, [0, 0, 0], 1)
        
        # Add current vehicle position and orientation
        if self.vehicle_poses:
            x, y, yaw = self.vehicle_poses[-1]
            gx, gy = self.world_to_grid(x, y)
            
            if self.is_in_grid(gx, gy):
                # Draw vehicle as triangle
                radius = 8
                tip_x = int(gx + radius * np.cos(yaw))
                tip_y = int(gy - radius * np.sin(yaw))  # Subtract because y-axis is flipped in images
                
                left_x = int(gx + radius * np.cos(yaw + 2.5))
                left_y = int(gy - radius * np.sin(yaw + 2.5))
                
                right_x = int(gx + radius * np.cos(yaw - 2.5))
                right_y = int(gy - radius * np.sin(yaw - 2.5))
                
                vehicle_pts = np.array([
                    [tip_x, tip_y],
                    [left_x, left_y],
                    [right_x, right_y]
                ], dtype=np.int32)
                
                cv2.fillPoly(rgb_map, [vehicle_pts], [0, 0, 255])
        
        # Add text with map information
        info_text = f"Resolution: {self.resolution:.3f}m/cell, Size: {self.width}x{self.height}"
        cv2.putText(rgb_map, info_text, (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, [255, 255, 255], 1)
        
        stats_text = f"Updates: {self.update_count}, Cones: {len(self.cone_map)}"
        cv2.putText(rgb_map, stats_text, (10, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.5, [255, 255, 255], 1)
        
        # Add scale bar
        scale_bar_length = int(5.0 / self.resolution)  # 5 meters
        cv2.line(rgb_map, (10, self.height - 20), (10 + scale_bar_length, self.height - 20), [255, 255, 255], 2)
        cv2.putText(rgb_map, "5m", (10, self.height - 30), cv2.FONT_HERSHEY_SIMPLEX, 0.5, [255, 255, 255], 1)
        
        return rgb_map
    
    def save_visualization(self):
        """Save the map visualization to a file."""
        timestamp = self.last_update_time.strftime("%Y%m%d_%H%M%S")
        img_path = os.path.join(self.maps_dir, f"map_{timestamp}.png")
        
        # Generate visualization
        vis_img = self.generate_visualization()
        
        # Save image
        cv2.imwrite(img_path, vis_img)
        print(f"Map visualization saved to {img_path}")
    
    def save_map_data(self):
        """Save map data to files for later use."""
        timestamp = self.last_update_time.strftime("%Y%m%d_%H%M%S")
        
        # Save cone map
        cone_path = os.path.join(self.maps_dir, f"cones_{timestamp}.csv")
        with open(cone_path, 'w') as f:
            f.write("x,y,class\n")
            for x, y, cls in self.cone_map:
                f.write(f"{x:.6f},{y:.6f},{cls}\n")
        
        # Save vehicle trajectory
        path_path = os.path.join(self.maps_dir, f"path_{timestamp}.csv")
        with open(path_path, 'w') as f:
            f.write("x,y,yaw\n")
            for x, y, yaw in self.vehicle_poses:
                f.write(f"{x:.6f},{y:.6f},{yaw:.6f}\n")
        
        # Save grid map as compressed numpy array
        grid_path = os.path.join(self.maps_dir, f"grid_{timestamp}.npz")
        np.savez_compressed(grid_path, grid=self.grid_map, log_odds=self.log_odds_grid)
        
        print(f"Map data saved to {self.maps_dir}")
    
    def load_map_data(self, map_file):
        """Load map data from file."""
        # Check file extension
        if map_file.endswith('.npz'):
            # Load grid map
            data = np.load(map_file)
            self.grid_map = data['grid']
            self.log_odds_grid = data['log_odds']
            print(f"Loaded grid map from {map_file}")
            
        elif map_file.endswith('.csv') and 'cones' in map_file:
            # Load cone map
            self.cone_map = []
            with open(map_file, 'r') as f:
                lines = f.readlines()
                # Skip header
                for line in lines[1:]:
                    parts = line.strip().split(',')
                    if len(parts) >= 3:
                        x = float(parts[0])
                        y = float(parts[1])
                        cls = int(parts[2])
                        self.cone_map.append((x, y, cls))
            
            # Rebuild KDTree
            if self.cone_map:
                cone_positions_array = np.array([[x, y] for x, y, _ in self.cone_map])
                self.cone_tree = KDTree(cone_positions_array)
            
            print(f"Loaded {len(self.cone_map)} cones from {map_file}")
            
        elif map_file.endswith('.csv') and 'path' in map_file:
            # Load vehicle trajectory
            self.vehicle_poses = []
            with open(map_file, 'r') as f:
                lines = f.readlines()
                # Skip header
                for line in lines[1:]:
                    parts = line.strip().split(',')
                    if len(parts) >= 3:
                        x = float(parts[0])
                        y = float(parts[1])
                        yaw = float(parts[2])
                        self.vehicle_poses.append((x, y, yaw))
            
            print(f"Loaded {len(self.vehicle_poses)} vehicle poses from {map_file}")
        
        else:
            print(f"Unknown file format: {map_file}")
            return False
        
        return True
    
    def generate_analysis_report(self):
        """Generate a comprehensive analysis report for thesis purposes."""
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
        
        analysis_dir = os.path.join(self.output_dir, "analysis")
        os.makedirs(analysis_dir, exist_ok=True)
        
        # Create a multi-page PDF report
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = os.path.join(analysis_dir, f"mapping_report_{timestamp}.pdf")
        
        # Generate visualizations and analyses
        
        # 1. Generate full map visualization
        map_img = self.generate_visualization()
        map_img_path = os.path.join(analysis_dir, f"full_map_{timestamp}.png")
        cv2.imwrite(map_img_path, map_img)
        
        # 2. Generate cone distribution visualization
        plt.figure(figsize=(10, 8))
        # Plot cone positions
        plt.subplot(2, 1, 1)
        for x, y, cls in self.cone_map:
            if cls == 0:  # Yellow
                plt.plot(x, y, 'yo', markersize=6)
            elif cls == 1:  # Blue
                plt.plot(x, y, 'bo', markersize=6)
            else:  # Unknown
                plt.plot(x, y, 'go', markersize=6)
        
        # Plot vehicle trajectory
        if self.vehicle_poses:
            vehicle_x = [x for x, _, _ in self.vehicle_poses]
            vehicle_y = [y for _, y, _ in self.vehicle_poses]
            plt.plot(vehicle_x, vehicle_y, 'r-', linewidth=2, alpha=0.7)
        
        plt.title('Cone Distribution and Vehicle Trajectory')
        plt.xlabel('X (meters)')
        plt.ylabel('Y (meters)')
        plt.axis('equal')
        plt.grid(True)
        
        # Plot cone class distribution
        plt.subplot(2, 1, 2)
        classes = [cls for _, _, cls in self.cone_map]
        class_counts = {0: 0, 1: 0, 2: 0}
        for cls in classes:
            class_counts[cls] += 1
        
        plt.bar(['Yellow (0)', 'Blue (1)', 'Unknown (2)'], 
               [class_counts[0], class_counts[1], class_counts[2]],
               color=['yellow', 'blue', 'gray'])
        plt.title('Cone Class Distribution')
        plt.xlabel('Class')
        plt.ylabel('Count')
        
        # Save figure
        plt.tight_layout()
        cone_dist_path = os.path.join(analysis_dir, f"cone_distribution_{timestamp}.png")
        plt.savefig(cone_dist_path, dpi=300)
        plt.close()
        
        # 3. Generate text report
        report_text = f"""
        Cartographer Mapping System Analysis Report
        ==========================================
        Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        
        Map Statistics:
        - Total mapped cones: {len(self.cone_map)}
        - Yellow cones: {class_counts[0]}
        - Blue cones: {class_counts[1]}
        - Unknown cones: {class_counts[2]}
        
        Mapping Performance:
        - Total updates: {self.update_count}
        - New cones added: {self.total_new_cones}
        - Cone updates: {self.total_cone_updates}
        
        Map Parameters:
        - Resolution: {self.resolution} meters/cell
        - Map dimensions: {self.width}x{self.height} cells
        - Map size: {self.width * self.resolution}x{self.height * self.resolution} meters
        
        Vehicle Trajectory:
        - Total path length: {self._calculate_path_length()} meters
        - Average speed: {self._calculate_average_speed()} m/s
        
        Analysis figures saved to: {analysis_dir}
        """
        
        # Save text report
        report_text_path = os.path.join(analysis_dir, f"mapping_report_{timestamp}.txt")
        with open(report_text_path, 'w') as f:
            f.write(report_text)
        
        print(f"Analysis report generated and saved to {analysis_dir}")
        return report_text_path
    
    def _calculate_path_length(self):
        """Calculate the total path length from vehicle poses."""
        if len(self.vehicle_poses) < 2:
            return 0.0
        
        total_length = 0.0
        for i in range(1, len(self.vehicle_poses)):
            prev_x, prev_y, _ = self.vehicle_poses[i-1]
            curr_x, curr_y, _ = self.vehicle_poses[i]
            
            segment_length = np.sqrt((curr_x - prev_x)**2 + (curr_y - prev_y)**2)
            total_length += segment_length
        
        return total_length
    
    def _calculate_average_speed(self):
        """Estimate average speed from trajectory if timestamps available."""
        if len(self.vehicle_poses) < 2 or len(self.pose_times) < 2:
            return 0.0
        
        path_length = self._calculate_path_length()
        time_delta = (self.pose_times[-1] - self.pose_times[0]).total_seconds()
        
        if time_delta > 0:
            return path_length / time_delta
        return 0.0
