#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
import numpy as np
import os
import time
import threading
from threading import Lock
from sensor_msgs.msg import PointCloud2
import sensor_msgs_py.point_cloud2 as pc2
from nav_msgs.msg import OccupancyGrid, Path
from std_msgs.msg import Header
from geometry_msgs.msg import TransformStamped, PoseStamped, Quaternion
from visualization_msgs.msg import MarkerArray, Marker
from tf2_ros import TransformBroadcaster
import tf2_ros
import cv2
import carla

# Import cartographer_mapper from your code
from .cartographer_mapper import CartographerMapper

class CartographerIntegration(Node):
    def __init__(self):
        super().__init__('cartographer_integration_node')

        # Declare parameters 
        self.declare_parameter('use_cartographer', True)
        self.declare_parameter('cartographer_resolution', 0.1)
        self.declare_parameter('map_width', 1000)
        self.declare_parameter('map_height', 1000)
        self.declare_parameter('output_dir', '/home/dalek/mapping_output')
        self.declare_parameter('map_publish_rate', 1.0)  # Hz
        self.declare_parameter('use_carla', True)
        
        # Get parameters
        self.use_cartographer = self.get_parameter('use_cartographer').value
        resolution = self.get_parameter('cartographer_resolution').value
        map_width = self.get_parameter('map_width').value
        map_height = self.get_parameter('map_height').value
        self.output_dir = self.get_parameter('output_dir').value
        self.map_publish_rate = self.get_parameter('map_publish_rate').value
        self.use_carla = self.get_parameter('use_carla').value
        
        # Create output directory if it doesn't exist
        os.makedirs(self.output_dir, exist_ok=True)
        
        # Initialize Cartographer mapper
        if self.use_cartographer:
            self.mapper = CartographerMapper(
                resolution=resolution,
                width=map_width,
                height=map_height,
                output_dir=self.output_dir
            )
            self.get_logger().info("Cartographer mapper initialized")
        else:
            self.mapper = None
            self.get_logger().info("Cartographer is disabled")
        
        # Create publishers
        self.map_pub = self.create_publisher(OccupancyGrid, '/cartographer/map', 10)
        self.cone_marker_pub = self.create_publisher(MarkerArray, '/cartographer/cone_markers', 10)
        self.path_pub = self.create_publisher(Path, '/cartographer/path', 10)
        
        # Create subscribers
        self.lidar_sub = self.create_subscription(
            PointCloud2,
            '/carla/lidar_points',
            self.lidar_callback,
            10
        )
        
        # TF broadcaster and listener
        self.tf_broadcaster = TransformBroadcaster(self)
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)
        
        # State variables
        self.vehicle_pose = (0.0, 0.0, 0.0)  # (x, y, yaw) in world coordinates
        self.latest_lidar_points = None
        self.lidar_lock = Lock()
        
        # Create timer for map publishing
        self.map_timer = self.create_timer(1.0 / self.map_publish_rate, self.publish_map)
        
        # Create timer for saving map data
        self.save_timer = self.create_timer(60.0, self.save_map_data)
        
        self.get_logger().info("Cartographer integration node initialized")
    
    def lidar_callback(self, msg):
        """Process incoming LiDAR data"""
        try:
            self.get_logger().info(f"=== LIDAR CALLBACK START ===")
            self.get_logger().info(f"Received LiDAR message: width={msg.width}, height={msg.height}")
            self.get_logger().info(f"Frame ID: {msg.header.frame_id}")
            
            if not self.use_cartographer:
                return
                
            # Get current transform from tf if available
            try:
                transform = self.tf_buffer.lookup_transform(
                    'map',                  # Target frame
                    msg.header.frame_id,    # Source frame
                    rclpy.time.Time()       # Time (0 = latest)
                )
                
                # Extract position and orientation
                position = transform.transform.translation
                orientation = transform.transform.rotation
                
                # Calculate yaw from quaternion
                yaw = self.quaternion_to_yaw(orientation)
                
                # Update vehicle pose
                self.vehicle_pose = (position.x, position.y, yaw)
                
                self.get_logger().info(f"Updated vehicle pose: x={self.vehicle_pose[0]:.2f}, y={self.vehicle_pose[1]:.2f}, yaw={self.vehicle_pose[2]:.2f}")
                
            except (tf2_ros.LookupException, tf2_ros.ConnectivityException, 
                    tf2_ros.ExtrapolationException) as e:
                self.get_logger().warn(f"TF lookup failed: {e}")
                # If TF lookup fails, use previous pose (if available)
                if not hasattr(self, 'vehicle_pose') or self.vehicle_pose is None:
                    self.vehicle_pose = (0.0, 0.0, 0.0)
                self.get_logger().info(f"Using fallback vehicle pose: {self.vehicle_pose}")
            
            # Extract points from PointCloud2 message - FIXED VERSION
            self.get_logger().info("Extracting points from PointCloud2 message...")
            
            # Use the correct method to extract structured points
            points_list = []
            for point in pc2.read_points(msg, field_names=('x', 'y', 'z'), skip_nans=True):
                points_list.append([point[0], point[1], point[2]])
            
            if not points_list:
                self.get_logger().warn("No points in LiDAR data")
                return
                
            # Convert to numpy array with proper shape
            points = np.array(points_list)
            
            self.get_logger().info(f"Successfully extracted {len(points)} points with shape {points.shape}")
            
            # Debug: Log a few sample points
            if len(points) > 0:
                self.get_logger().info(f"Sample points: {points[:3]}")
            
            with self.lidar_lock:
                self.latest_lidar_points = points
            
            self.get_logger().info("Calling update_cartographer_map...")
            # Use Cartographer to map the points
            self.update_cartographer_map(points)
            
            self.get_logger().info("=== LIDAR CALLBACK END ===")
            
        except Exception as e:
            self.get_logger().error(f"Error in LiDAR callback: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
    
    def update_cartographer_map(self, points):
        """Update the Cartographer map with new LiDAR points"""
        if not self.mapper:
            return
            
        try:
            # Filter for points that might be cones
            # Simple cone filtering - points between 0.1m and 0.6m off ground
            # and not too far away
            ground_height = np.min(points[:, 2]) + 0.05  # Slightly above ground level
            max_height = ground_height + 0.6  # Maximum expected cone height
            max_distance = 30.0  # Maximum distance to consider
            
            # Calculate distances
            distances = np.sqrt(np.sum(points[:, :2] ** 2, axis=1))
            
            # Filter points
            mask = (
                (points[:, 2] >= ground_height) &
                (points[:, 2] <= max_height) &
                (distances <= max_distance)
            )
            
            filtered_points = points[mask]
            
            if len(filtered_points) < 10:
                self.get_logger().warn("Not enough points for cone detection after filtering")
                return
                
            # Simple clustering for cone detection (DBSCAN)
            from sklearn.cluster import DBSCAN
            
            # Only use x, y coordinates for clustering
            coords = filtered_points[:, :2]
            clustering = DBSCAN(eps=0.5, min_samples=5).fit(coords)
            labels = clustering.labels_
            
            # Extract cluster centers as potential cones
            cone_positions = []
            cone_classes = []  # 0 = yellow, 1 = blue, 2 = unknown
            
            unique_labels = set(labels)
            for label in unique_labels:
                if label != -1:  # Skip noise points
                    cluster_points = coords[labels == label]
                    cluster_center = np.mean(cluster_points, axis=0)
                    
                    # Use cluster properties to determine cone class
                    # For now, all detected cones are "unknown" class (2)
                    # In a real system, you'd use camera data or cone color information
                    cone_positions.append(cluster_center)
                    cone_classes.append(2)  # Unknown class
            
            # Update the map with detected cones
            if cone_positions:
                self.mapper.update_map(cone_positions, cone_classes, self.vehicle_pose)
                self.get_logger().info(f"Updated map with {len(cone_positions)} cones")
            
        except Exception as e:
            self.get_logger().error(f"Error updating Cartographer map: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
    
    def publish_map(self):
        """Publish the Cartographer map as an OccupancyGrid message"""
        if not self.mapper:
            return
            
        try:
            # Create OccupancyGrid message
            grid_msg = OccupancyGrid()
            grid_msg.header.stamp = self.get_clock().now().to_msg()
            grid_msg.header.frame_id = "map"
            
            # Set metadata
            grid_msg.info.resolution = self.mapper.resolution
            grid_msg.info.width = self.mapper.width
            grid_msg.info.height = self.mapper.height
            
            # Origin is at the center of the grid
            grid_msg.info.origin.position.x = -self.mapper.resolution * self.mapper.origin_x
            grid_msg.info.origin.position.y = -self.mapper.resolution * self.mapper.origin_y
            grid_msg.info.origin.position.z = 0.0
            
            # Convert grid map to occupancy values (0-100)
            # 0: unknown, 1: free, 2: occupied
            # Convert to -1: unknown, 0-100: probability of occupancy
            grid_data = np.zeros(self.mapper.grid_map.shape, dtype=np.int8)
            grid_data[self.mapper.grid_map == 0] = -1  # Unknown
            grid_data[self.mapper.grid_map == 1] = 0   # Free
            grid_data[self.mapper.grid_map == 2] = 100 # Occupied
            
            # Flatten row-major order (how OccupancyGrid expects it)
            grid_msg.data = grid_data.flatten().tolist()
            
            # Publish map
            self.map_pub.publish(grid_msg)
            
            # Publish cone markers
            self.publish_cone_markers()
            
            # Publish vehicle path
            self.publish_vehicle_path()
            
        except Exception as e:
            self.get_logger().error(f"Error publishing map: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
    
    def publish_cone_markers(self):
        """Publish cone markers for visualization in RViz"""
        if not self.mapper:
            return
            
        try:
            marker_array = MarkerArray()
            
            # Get cones by class
            cones_by_class = self.mapper.get_cones_by_class()
            
            # Colors for different cone classes
            colors = {
                0: (1.0, 1.0, 0.0, 1.0),  # Yellow
                1: (0.0, 0.0, 1.0, 1.0),  # Blue
                2: (0.5, 0.5, 0.5, 1.0)   # Gray (unknown)
            }
            
            marker_id = 0
            
            # Create markers for each cone class
            for cls, cone_list in cones_by_class.items():
                for i, pos in enumerate(cone_list):
                    marker = Marker()
                    marker.header.frame_id = "map"
                    marker.header.stamp = self.get_clock().now().to_msg()
                    marker.ns = f"cone_class_{cls}"
                    marker.id = marker_id
                    marker_id += 1
                    
                    marker.type = Marker.CYLINDER
                    marker.action = Marker.ADD
                    
                    # Set position - FIXED: explicit float conversion
                    marker.pose.position.x = float(pos[0])
                    marker.pose.position.y = float(pos[1])
                    marker.pose.position.z = 0.2  # Half height of cone
                    
                    # Set orientation (identity)
                    marker.pose.orientation.w = 1.0
                    marker.pose.orientation.x = 0.0
                    marker.pose.orientation.y = 0.0
                    marker.pose.orientation.z = 0.0
                    
                    # Set scale (size)
                    marker.scale.x = 0.3  # Diameter
                    marker.scale.y = 0.3
                    marker.scale.z = 0.4  # Height
                    
                    # Set color
                    r, g, b, a = colors.get(cls, (1.0, 1.0, 1.0, 1.0))
                    marker.color.r = float(r)
                    marker.color.g = float(g)
                    marker.color.b = float(b)
                    marker.color.a = float(a)
                    
                    # Set lifetime (0 = forever)
                    marker.lifetime.sec = 0
                    marker.lifetime.nanosec = 0
                    
                    marker_array.markers.append(marker)
            
            # Create a path marker for vehicle trajectory
            if len(self.mapper.vehicle_poses) > 1:
                path_marker = Marker()
                path_marker.header.frame_id = "map"
                path_marker.header.stamp = self.get_clock().now().to_msg()
                path_marker.ns = "vehicle_path"
                path_marker.id = marker_id
                marker_id += 1
                
                path_marker.type = Marker.LINE_STRIP
                path_marker.action = Marker.ADD
                
                # Set line properties
                path_marker.scale.x = 0.1  # Line width
                path_marker.color.r = 0.0
                path_marker.color.g = 1.0
                path_marker.color.b = 0.0
                path_marker.color.a = 0.8
                
                # Add points
                for x, y, _ in self.mapper.vehicle_poses:
                    p = self.point(float(x), float(y), 0.05)  # FIXED: explicit float conversion
                    path_marker.points.append(p)
                
                marker_array.markers.append(path_marker)
            
            # Publish marker array
            self.cone_marker_pub.publish(marker_array)
            
        except Exception as e:
            self.get_logger().error(f"Error publishing cone markers: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
    
    def publish_vehicle_path(self):
        """Publish vehicle path for visualization in RViz"""
        if not self.mapper or len(self.mapper.vehicle_poses) < 2:
            return
            
        try:
            # Create path message
            path_msg = Path()
            path_msg.header.stamp = self.get_clock().now().to_msg()
            path_msg.header.frame_id = "map"
            
            # Add poses to path
            for x, y, yaw in self.mapper.vehicle_poses:
                pose = PoseStamped()
                pose.header = path_msg.header
                
                # Set position
                pose.pose.position.x = x
                pose.pose.position.y = y
                pose.pose.position.z = 0.0
                
                # Set orientation from yaw
                q = self.yaw_to_quaternion(yaw)
                pose.pose.orientation = q
                
                path_msg.poses.append(pose)
            
            # Publish path
            self.path_pub.publish(path_msg)
            
        except Exception as e:
            self.get_logger().error(f"Error publishing vehicle path: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
    
    def save_map_data(self):
        """Save map data periodically"""
        if not self.mapper:
            return
            
        try:
            self.mapper.save_map_data()
            self.mapper.save_visualization()
            self.get_logger().info("Map data saved successfully")
            
        except Exception as e:
            self.get_logger().error(f"Error saving map data: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
    
    def point(self, x, y, z):
        """Helper function to create a Point message"""
        from geometry_msgs.msg import Point
        p = Point()
        p.x = x
        p.y = y
        p.z = z
        return p
    
    def quaternion_to_yaw(self, q):
        """Convert quaternion to yaw angle (rad)"""
        # yaw (z-axis rotation)
        siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        yaw = np.arctan2(siny_cosp, cosy_cosp)
        return yaw
    
    def yaw_to_quaternion(self, yaw):
        """Convert yaw angle (rad) to quaternion"""
        q = Quaternion()
        q.x = 0.0
        q.y = 0.0
        q.z = np.sin(yaw / 2.0)
        q.w = np.cos(yaw / 2.0)
        return q
    
    def destroy_node(self):
        """Clean up resources on node shutdown"""
        if self.mapper:
            self.mapper.save_map_data()
            self.mapper.save_visualization()
            self.get_logger().info("Final map data saved")
        
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    
    try:
        node = CartographerIntegration()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(f"Error in main: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # Clean up
        if 'node' in locals():
            node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
