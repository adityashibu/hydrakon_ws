import numpy as np
from visualization_msgs.msg import Marker
from std_msgs.msg import ColorRGBA
from geometry_msgs.msg import Point, Vector3
from cone_mapping.point_cloud_utils import PointCloudProcessor
from typing import List

def create_cone_marker(position: np.ndarray, cone_class: int, marker_id: int, frame_id: str = "map") -> Marker:
    """Create a visualization marker for a cone."""
    marker = Marker()
    marker.header.frame_id = frame_id
    marker.ns = "cones"
    marker.id = marker_id
    marker.type = Marker.CYLINDER
    marker.action = Marker.ADD
    
    # Set position
    marker.pose.position.x = position[0]
    marker.pose.position.y = position[1]
    marker.pose.position.z = position[2] if len(position) > 2 else 0.0
    
    # Set orientation (upright)
    marker.pose.orientation.w = 1.0
    
    # Set scale (height, radius)
    marker.scale = Vector3(x=0.5, y=0.5, z=1.0)
    
    # Set color based on cone class
    marker.color = ColorRGBA()
    if cone_class == 0:  # Yellow cone
        marker.color.r = 1.0
        marker.color.g = 1.0
        marker.color.b = 0.0
    elif cone_class == 1:  # Blue cone
        marker.color.r = 0.0
        marker.color.g = 0.0
        marker.color.b = 1.0
    else:  # Unknown/other
        marker.color.r = 0.5
        marker.color.g = 0.5
        marker.color.b = 0.5
    marker.color.a = 1.0
    
    return marker

def create_path_marker(points: List[np.ndarray], color: ColorRGBA, marker_id: int, frame_id: str = "map") -> Marker:
    """Create a visualization marker for a path."""
    marker = Marker()
    marker.header.frame_id = frame_id
    marker.ns = "paths"
    marker.id = marker_id
    marker.type = Marker.LINE_STRIP
    marker.action = Marker.ADD
    
    # Set points
    for point in points:
        p = Point()
        p.x = point[0]
        p.y = point[1]
        p.z = point[2] if len(point) > 2 else 0.0
        marker.points.append(p)
    
    # Set scale (line width)
    marker.scale.x = 0.1
    
    # Set color
    marker.color = color
    
    return marker

def create_text_marker(text: str, position: np.ndarray, color: ColorRGBA, marker_id: int, frame_id: str = "map") -> Marker:
    """Create a text visualization marker."""
    marker = Marker()
    marker.header.frame_id = frame_id
    marker.ns = "text"
    marker.id = marker_id
    marker.type = Marker.TEXT_VIEW_FACING
    marker.action = Marker.ADD
    
    # Set position
    marker.pose.position.x = position[0]
    marker.pose.position.y = position[1]
    marker.pose.position.z = position[2] if len(position) > 2 else 0.0
    
    # Set orientation
    marker.pose.orientation.w = 1.0
    
    # Set text and scale
    marker.text = text
    marker.scale.z = 0.3  # Text height
    
    # Set color
    marker.color = color
    
    return marker 