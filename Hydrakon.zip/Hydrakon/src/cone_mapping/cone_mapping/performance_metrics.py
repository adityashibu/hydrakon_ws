import numpy as np
import time
from typing import Dict, List, Optional
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
from visualization_msgs.msg import Marker, MarkerArray
from geometry_msgs.msg import Point
from cone_mapping.visualization_utils import create_cone_marker
from cone_mapping.point_cloud_utils import PointCloudProcessor

class PerformanceMetrics:
    def __init__(self, node: Node):
        self.node = node
        self.point_cloud_processor = PointCloudProcessor()
        
        # Performance metrics
        self.processing_times: List[float] = []
        self.cone_counts: List[int] = []
        self.memory_usage: List[float] = []
        self.timestamp = time.time()
        
        # Publishers
        self.processing_time_pub = self.node.create_publisher(Float32, '/performance/processing_time', 10)
        self.cone_count_pub = self.node.create_publisher(Float32, '/performance/cone_count', 10)
        self.memory_usage_pub = self.node.create_publisher(Float32, '/performance/memory_usage', 10)
        
        # Visualization publishers
        self.metrics_marker_pub = self.node.create_publisher(MarkerArray, '/performance/metrics_visualization', 10)
        
        # Performance thresholds
        self.processing_time_threshold = 0.1  # 100ms
        self.memory_usage_threshold = 1000.0  # 1000MB
        self.cone_count_threshold = 1000
        
        # Performance status
        self.is_performing_well = True
        self.performance_issues: List[str] = []
        
        # Log performance metrics every 5 seconds
        self.metrics_timer = self.node.create_timer(5.0, self.log_performance_metrics)
        
    def update_metrics(self, processing_time: float, cone_count: int, memory_usage: float):
        """Update performance metrics with new measurements."""
        self.processing_times.append(processing_time)
        self.cone_counts.append(cone_count)
        self.memory_usage.append(memory_usage)
        
        # Keep only the last 100 measurements
        if len(self.processing_times) > 100:
            self.processing_times.pop(0)
            self.cone_counts.pop(0)
            self.memory_usage.pop(0)
            
        # Check performance
        self.check_performance()
        
        # Publish metrics
        self.publish_metrics()
        
    def check_performance(self):
        """Check if the system is performing within acceptable thresholds."""
        self.performance_issues = []
        
        # Check processing time
        avg_processing_time = np.mean(self.processing_times[-10:])  # Last 10 measurements
        if avg_processing_time > self.processing_time_threshold:
            self.performance_issues.append(f"High processing time: {avg_processing_time:.3f}s")
            
        # Check memory usage
        avg_memory_usage = np.mean(self.memory_usage[-10:])
        if avg_memory_usage > self.memory_usage_threshold:
            self.performance_issues.append(f"High memory usage: {avg_memory_usage:.1f}MB")
            
        # Check cone count
        avg_cone_count = np.mean(self.cone_counts[-10:])
        if avg_cone_count > self.cone_count_threshold:
            self.performance_issues.append(f"High cone count: {avg_cone_count:.0f}")
            
        self.is_performing_well = len(self.performance_issues) == 0
        
    def publish_metrics(self):
        """Publish current performance metrics."""
        # Publish raw metrics
        self.processing_time_pub.publish(Float32(data=np.mean(self.processing_times[-10:])))
        self.cone_count_pub.publish(Float32(data=float(np.mean(self.cone_counts[-10:]))))
        self.memory_usage_pub.publish(Float32(data=np.mean(self.memory_usage[-10:])))
        
        # Create visualization markers
        self.publish_metrics_visualization()
        
    def publish_metrics_visualization(self):
        """Create and publish visualization markers for performance metrics."""
        marker_array = MarkerArray()
        
        # Create text markers for each metric
        metrics = [
            ("Processing Time", np.mean(self.processing_times[-10:]), "s"),
            ("Cone Count", np.mean(self.cone_counts[-10:]), ""),
            ("Memory Usage", np.mean(self.memory_usage[-10:]), "MB")
        ]
        
        for i, (name, value, unit) in enumerate(metrics):
            marker = Marker()
            marker.header.frame_id = "map"
            marker.header.stamp = self.node.get_clock().now().to_msg()
            marker.ns = "performance_metrics"
            marker.id = i
            marker.type = Marker.TEXT_VIEW_FACING
            marker.action = Marker.ADD
            marker.pose.position.x = 0.0
            marker.pose.position.y = 2.0 - i * 0.5
            marker.pose.position.z = 0.0
            marker.pose.orientation.w = 1.0
            marker.scale.z = 0.3
            marker.color.a = 1.0
            marker.color.r = 1.0
            marker.color.g = 1.0
            marker.color.b = 1.0
            marker.text = f"{name}: {value:.2f}{unit}"
            marker_array.markers.append(marker)
            
        # Add status indicator
        status_marker = Marker()
        status_marker.header.frame_id = "map"
        status_marker.header.stamp = self.node.get_clock().now().to_msg()
        status_marker.ns = "performance_status"
        status_marker.id = 0
        status_marker.type = Marker.TEXT_VIEW_FACING
        status_marker.action = Marker.ADD
        status_marker.pose.position.x = 0.0
        status_marker.pose.position.y = 3.0
        status_marker.pose.position.z = 0.0
        status_marker.pose.orientation.w = 1.0
        status_marker.scale.z = 0.4
        status_marker.color.a = 1.0
        
        if self.is_performing_well:
            status_marker.color.g = 1.0
            status_marker.text = "System Status: GOOD"
        else:
            status_marker.color.r = 1.0
            status_marker.text = "System Status: ISSUES DETECTED"
            
        marker_array.markers.append(status_marker)
        
        self.metrics_marker_pub.publish(marker_array)
        
    def log_performance_metrics(self):
        """Log performance metrics to the console."""
        if not self.is_performing_well:
            self.node.get_logger().warning("Performance issues detected:")
            for issue in self.performance_issues:
                self.node.get_logger().warning(f"- {issue}")
                
        # Log current metrics
        self.node.get_logger().info(
            f"Performance Metrics - "
            f"Processing Time: {np.mean(self.processing_times[-10:]):.3f}s, "
            f"Cone Count: {np.mean(self.cone_counts[-10:]):.0f}, "
            f"Memory Usage: {np.mean(self.memory_usage[-10:]):.1f}MB"
        ) 