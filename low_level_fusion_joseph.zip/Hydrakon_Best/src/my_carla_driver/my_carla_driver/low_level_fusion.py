import numpy as np
import cv2
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Dict, Tuple, Optional
import math
import types
from std_msgs.msg import Header
import sensor_msgs_py.point_cloud2 as pc2

class LowLevelFusionDetector:
    def __init__(self, camera_resolution=(1280, 720), fov_horizontal=90.0):
        """Initialize the low-level fusion detector."""
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.feature_maps = None
        self.last_detections = []
        self.camera_resolution = camera_resolution
        self.fov_horizontal = fov_horizontal
        
        # Default camera matrix based on resolution and FOV
        self.camera_matrix = self._compute_camera_matrix()
        
    def _compute_camera_matrix(self):
        """Compute camera matrix from resolution and FOV."""
        width, height = self.camera_resolution
        # Compute focal length from FOV
        # Use a slightly higher adjustment factor for CARLA
        fx = (width / (2 * np.tan(np.radians(self.fov_horizontal / 2)))) * 1.1
        fy = fx  # Assume square pixels
        cx = width / 2
        cy = height / 2
        
        return np.array([
            [fx, 0, cx],
            [0, fy, cy],
            [0, 0, 1]
        ])
        
    def create_feature_maps(self, rgb_image: np.ndarray, lidar_points: np.ndarray, 
                          lidar_to_camera_transform: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Create fused feature maps from RGB image and LiDAR points.
        """
        height, width = rgb_image.shape[:2]
        
        # Initialize feature maps
        depth_map = np.zeros((height, width), dtype=np.float32)
        point_count_map = np.zeros((height, width), dtype=np.int32)
        height_map = np.zeros((height, width), dtype=np.float32)
        
        # DEBUG: Print input info
        print(f"DEBUG create_feature_maps: Image size: {width}x{height}")
        print(f"DEBUG: Input LiDAR points shape: {lidar_points.shape}")
        print(f"DEBUG: LiDAR points sample (first 3):")
        for i in range(min(3, len(lidar_points))):
            print(f"  Point {i}: {lidar_points[i]}")
        
        # Transform LiDAR points to camera frame
        if lidar_to_camera_transform is not None and lidar_to_camera_transform.shape == (4, 4):
            print(f"DEBUG: Using transform matrix:")
            print(lidar_to_camera_transform)
            # Add homogeneous coordinate
            points_hom = np.hstack([lidar_points, np.ones((len(lidar_points), 1))])
            # Transform to camera frame
            points_cam = (lidar_to_camera_transform @ points_hom.T).T[:, :3]
        else:
            print("DEBUG: No transform, applying CARLA LiDAR to camera conversion")
            
            # Based on coordinate system analysis:
            # CARLA LiDAR outputs in world coordinates relative to the sensor
            # LiDAR data: X=lateral, Y=height, Z=forward_distance
            # Camera expects: X=lateral, Y=down, Z=forward
            
            points_cam = np.zeros_like(lidar_points)
            
            # Correct coordinate mapping:
            points_cam[:, 0] = lidar_points[:, 0]                    # X (lateral) unchanged
            points_cam[:, 1] = 2.2 - lidar_points[:, 1]            # Y = sensor_height - lidar_height (down is positive)
            points_cam[:, 2] = lidar_points[:, 2]                   # Z (forward) unchanged
            
            # Debug transformation
            print(f"DEBUG: Coordinate transformation examples:")
            for i in range(min(3, len(lidar_points))):
                print(f"  LiDAR [{i}]: X={lidar_points[i,0]:6.2f}, Y={lidar_points[i,1]:6.2f}, Z={lidar_points[i,2]:6.2f}")
                print(f"  Camera[{i}]: X={points_cam[i,0]:6.2f}, Y={points_cam[i,1]:6.2f}, Z={points_cam[i,2]:6.2f}")
                
            # Additional debug: check if points are reasonable
            print(f"DEBUG: Camera frame statistics:")
            print(f"  X range: [{np.min(points_cam[:,0]):.2f}, {np.max(points_cam[:,0]):.2f}]")
            print(f"  Y range: [{np.min(points_cam[:,1]):.2f}, {np.max(points_cam[:,1]):.2f}]") 
            print(f"  Z range: [{np.min(points_cam[:,2]):.2f}, {np.max(points_cam[:,2]):.2f}]")
        
        # DEBUG: Show camera frame points
        print(f"DEBUG: Camera frame points sample (first 3):")
        for i in range(min(3, len(points_cam))):
            print(f"  Point {i}: {points_cam[i]}")
            
        # Filter points in front of camera with tuned constraints for perfect projection
        depth_mask = (points_cam[:, 2] > 2.0) & (points_cam[:, 2] < 50.0)  # Stricter depth range
        lateral_mask = np.abs(points_cam[:, 0] / points_cam[:, 2]) < 0.9  # Tighter lateral/depth ratio
        valid_mask = depth_mask & lateral_mask
        points_cam = points_cam[valid_mask]
        print(f"DEBUG: Points in reasonable range: {len(points_cam)}/{len(lidar_points)}")
        
        if len(points_cam) > 0:
            print(f"DEBUG: Camera matrix:")
            print(self.camera_matrix)
            points_2d = (self.camera_matrix @ points_cam.T).T
            valid_z = points_2d[:, 2] > 1e-6
            points_cam = points_cam[valid_z]
            points_2d = points_2d[valid_z]
            if len(points_2d) > 0:
                points_2d = points_2d[:, :2] / points_2d[:, 2:3]
                print(f"DEBUG: Projected 2D points sample (first 5):")
                for i in range(min(5, len(points_2d))):
                    print(f"  Point {i}: 2D=({points_2d[i,0]:.1f}, {points_2d[i,1]:.1f}), depth={points_cam[i,2]:.2f}m")
                margin = 100
                valid_x = (points_2d[:, 0] >= -margin) & (points_2d[:, 0] < width + margin)
                valid_y = (points_2d[:, 1] >= -margin) & (points_2d[:, 1] < height + margin)
                valid_points = valid_x & valid_y
                valid_count = np.sum(valid_points)
                total_count = len(points_cam)
                percentage = (valid_count / total_count * 100) if total_count > 0 else 0
                print(f"DEBUG: Projected {valid_count}/{total_count} points ({percentage:.1f}%) to image bounds")
                if total_count > 0:
                    print(f"DEBUG: 2D projection ranges:")
                    print(f"  X range: [{np.min(points_2d[:,0]):.1f}, {np.max(points_2d[:,0]):.1f}]")
                    print(f"  Y range: [{np.min(points_2d[:,1]):.1f}, {np.max(points_2d[:,1]):.1f}]")
                    rejected_x = np.sum(~valid_x)
                    rejected_y = np.sum(~valid_y)
                    print(f"DEBUG: Rejected points - X out of bounds: {rejected_x}, Y out of bounds: {rejected_y}")
                if valid_count > 0 and valid_count < 10:
                    print("DEBUG: All valid projected points:")
                    valid_indices = np.where(valid_points)[0]
                    for idx in valid_indices:
                        print(f"  2D: ({points_2d[idx,0]:.1f}, {points_2d[idx,1]:.1f}), depth={points_cam[idx,2]:.2f}m")
                if np.any(valid_points):
                    points_2d = points_2d[valid_points]
                    points_cam = points_cam[valid_points]
                    points_2d[:, 0] = np.clip(points_2d[:, 0], 0, width - 1)
                    points_2d[:, 1] = np.clip(points_2d[:, 1], 0, height - 1)
                    points_2d_int = points_2d.astype(np.int32)
                    for i, (x, y) in enumerate(points_2d_int):
                        depth = points_cam[i, 2]
                        height_val = points_cam[i, 1]
                        if depth_map[y, x] == 0 or depth < depth_map[y, x]:
                            depth_map[y, x] = depth
                            height_map[y, x] = height_val
                        point_count_map[y, x] += 1
                        for dy in [-1, 0, 1]:
                            for dx in [-1, 0, 1]:
                                ny, nx = y + dy, x + dx
                                if 0 <= ny < height and 0 <= nx < width:
                                    if depth_map[ny, nx] == 0 or depth < depth_map[ny, nx]:
                                        interp_depth = depth * (1.0 + 0.01 * (abs(dx) + abs(dy)))
                                        depth_map[ny, nx] = interp_depth
                                        height_map[ny, nx] = height_val
        depth_map_normalized = np.clip(depth_map / 20.0, 0, 1)
        gradient_map = self._compute_gradient_map(depth_map)
        fused_features = np.dstack([
            rgb_image.astype(np.float32) / 255.0,
            depth_map_normalized,
            point_count_map.astype(np.float32) / 10.0,
            gradient_map
        ])
        fusion_coverage = np.sum(depth_map > 0) / (height * width) * 100
        print(f"DEBUG: Final fusion coverage: {fusion_coverage:.2f}% of image pixels have LiDAR depth")
        if fusion_coverage > 0.01:
            print(f"INFO: Fusion coverage is healthy: {fusion_coverage:.2f}% of image pixels have LiDAR depth")
        return fused_features
    
    def _project_points(self, points_cam: np.ndarray) -> np.ndarray:
        """Project 3D points to 2D image plane."""
        # Project using camera matrix
        points_2d = self.camera_matrix @ points_cam.T
        points_2d = points_2d[:2] / points_2d[2]
        return points_2d.T.astype(int)
    
    def _compute_gradient_map(self, depth_map: np.ndarray) -> np.ndarray:
        """Compute gradient magnitude for edge detection."""
        # Compute gradients
        sobelx = cv2.Sobel(depth_map, cv2.CV_32F, 1, 0, ksize=3)
        sobely = cv2.Sobel(depth_map, cv2.CV_32F, 0, 1, ksize=3)
        
        # Compute magnitude
        gradient_mag = np.sqrt(sobelx**2 + sobely**2)
        
        # Normalize
        return np.clip(gradient_mag / 5.0, 0, 1)
    
    def detect_cones_multimodal(self, rgb_image: np.ndarray, lidar_points: np.ndarray,
                               yolo_model=None, cone_detections=None) -> List[Dict]:
        """
        Detect cones using low-level fusion of camera and LiDAR data.
        
        Args:
            rgb_image: RGB image
            lidar_points: LiDAR point cloud
            yolo_model: YOLO model (optional)
            cone_detections: Existing cone detections to refine (optional)
            
        Returns:
            List of detected cones with enhanced attributes
        """
        # Create fused features
        fused_features = self.create_feature_maps(rgb_image, lidar_points)
        
        # DEBUG: Check if LiDAR data is in the features
        depth_channel = fused_features[:, :, 3]
        valid_depth_count = np.sum(depth_channel > 0)
        print(f"DEBUG: Valid depth pixels: {valid_depth_count} / {depth_channel.size} = {valid_depth_count/depth_channel.size*100:.1f}%")
        
        # (Removed outdated warning about LiDAR transform; fusion is now robust)
        
        self.feature_maps = fused_features
        
        # Get initial detections
        if cone_detections is not None:
            # Use provided detections
            initial_detections = cone_detections
        elif yolo_model is not None:
            # Run YOLO on RGB image
            results = yolo_model(rgb_image, conf=0.15)
            initial_detections = self._extract_yolo_detections(results)
            
            # If no YOLO detections, generate from fusion features
            if not initial_detections:
                self.get_logger().warn("No YOLO detections, generating from fusion features")
                initial_detections = self._generate_detections_from_fusion(fused_features)
        else:
            # Generate detections from fused features
            initial_detections = self._generate_detections_from_fusion(fused_features)
        
        # Refine detections using fused features
        refined_detections = []
        
        for det in initial_detections:
            # Extract ROI from fused features
            x1, y1, x2, y2 = map(int, det['box'])
            
            # Ensure ROI is within bounds
            x1 = max(0, x1)
            y1 = max(0, y1)
            x2 = min(fused_features.shape[1], x2)
            y2 = min(fused_features.shape[0], y2)
            
            if x2 <= x1 or y2 <= y1:
                continue
                
            roi = fused_features[y1:y2, x1:x2]
            
            # Validate using multimodal features
            if self._validate_cone_multimodal(roi):
                # Compute enhanced attributes
                depth = self._estimate_depth_from_roi(roi, det)
                confidence = self._compute_multimodal_confidence(roi, det)
                
                # Create refined detection
                refined_det = {
                    'box': (x1, y1, x2, y2),
                    'cls': det.get('cls', 0),
                    'depth': depth,
                    'confidence': confidence,
                    'multimodal_score': confidence,
                    'visual_conf': det.get('confidence', 0.5),
                    'lidar_conf': self._compute_lidar_confidence(roi)
                }
                
                refined_detections.append(refined_det)
        
        self.last_detections = refined_detections
        return refined_detections
    
    def _extract_yolo_detections(self, results):
        """Extract cone detections from YOLO results."""
        detections = []
        for result in results:
            if result.boxes is not None:
                for box in result.boxes:
                    cls = int(box.cls.item())
                    if cls in [0, 1]:  # Cone classes
                        x1, y1, x2, y2 = map(int, box.xyxy[0])
                        detections.append({
                            'box': (x1, y1, x2, y2),
                            'cls': cls,
                            'confidence': box.conf.item()
                        })
        return detections
    
    def _generate_detections_from_fusion(self, fused_features):
        """Generate cone proposals from fused features."""
        # Extract depth channel
        depth_channel = fused_features[:, :, 3]
        
        # Find regions with valid depth
        depth_mask = (depth_channel > 0.1) & (depth_channel < 0.5)  # 2-10m range
        
        # Find regions with high gradient (edges)
        gradient_channel = fused_features[:, :, 5]
        edge_mask = gradient_channel > 0.3
        
        # Combine masks
        combined_mask = depth_mask & edge_mask
        
        # Find connected components
        num_labels, labels = cv2.connectedComponents(combined_mask.astype(np.uint8))
        
        detections = []
        for label in range(1, num_labels):
            mask = (labels == label).astype(np.uint8)
            
            # Find bounding box
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            if contours:
                x, y, w, h = cv2.boundingRect(contours[0])
                
                # Filter by size
                if 10 < w < 100 and 10 < h < 150:
                    detections.append({
                        'box': (x, y, x + w, y + h),
                        'cls': 0,  # Default class
                        'confidence': 0.5  # Default confidence
                    })
        
        return detections
    
    def _validate_cone_multimodal(self, roi):
        """Validate if ROI contains a cone using multimodal features - FIXED VERSION."""
        if roi.size == 0:
            return False
            
        # Check depth consistency
        if len(roi.shape) >= 3 and roi.shape[2] > 3:
            depth_channel = roi[:, :, 3]
            
            # Create boolean mask for valid depths to avoid array comparison errors
            valid_depth_mask = depth_channel > 0
            valid_depth_count = np.sum(valid_depth_mask)
            
            # More lenient validation - if we have any LiDAR points, that's good
            if valid_depth_count < 2:
                # If we don't have enough LiDAR points, trust the vision detection
                return True
                
            # Extract valid depths safely
            valid_depths = depth_channel[valid_depth_mask]
            
            # Check depth consistency - allow for some variation
            if len(valid_depths) > 1:
                depth_std = np.std(valid_depths)
                if depth_std > 1.0:  # Increased tolerance
                    # Still might be a cone, just with more depth variation
                    pass
            
            # Check for edge presence
            if len(roi.shape) >= 3 and roi.shape[2] > 5:
                gradient_channel = roi[:, :, 5]
                mean_gradient = np.mean(gradient_channel)
                if mean_gradient < 0.05:  # Reduced threshold
                    # Low gradient doesn't necessarily disqualify
                    pass
        
        return True  # Default to accepting the detection with more lenient criteria
    
    def _estimate_depth_from_roi(self, roi, detection):
        """Estimate depth from ROI using multimodal cues."""
        # Extract depth channel
        depth_channel = roi[:, :, 3] * 20.0  # Denormalize
        valid_depths = depth_channel[depth_channel > 0]
        
        if len(valid_depths) > 0:
            # Use median for robustness
            lidar_depth = np.median(valid_depths)
            
            # If we have the original depth from detection, blend it
            if 'depth' in detection:
                return 0.7 * lidar_depth + 0.3 * detection['depth']
            else:
                return lidar_depth
        else:
            # Fallback to detection depth or estimate
            return detection.get('depth', 5.0)
    
    def _compute_multimodal_confidence(self, roi, detection):
        """Compute confidence combining visual and LiDAR cues."""
        visual_conf = detection.get('confidence', 0.5)
        lidar_conf = self._compute_lidar_confidence(roi)
        
        # Weighted combination
        return 0.6 * visual_conf + 0.4 * lidar_conf
    
    def _compute_lidar_confidence(self, roi):
        """Compute confidence from LiDAR features."""
        if roi.size == 0:
            return 0.0
            
        # Depth consistency
        depth_channel = roi[:, :, 3]
        valid_depth_ratio = np.sum(depth_channel > 0) / depth_channel.size
        
        # Point density
        intensity_channel = roi[:, :, 4]
        density_score = np.mean(intensity_channel)
        
        # Edge strength
        gradient_channel = roi[:, :, 5]
        edge_score = np.mean(gradient_channel)
        
        # Combine scores
        lidar_conf = (valid_depth_ratio + density_score + edge_score) / 3.0
        
        return np.clip(lidar_conf, 0, 1)

def integrate_low_level_fusion(node):
    """
    Integrate low-level fusion into the existing node.
    """
    try:
        node.get_logger().info("Starting low-level fusion integration...")
        
        # Store original methods
        node._original_process_lidar_data = node.process_lidar_data
        node._original_process_frame = node.zed_camera.process_frame
        
        # Apply the validation fix to the detector
        if hasattr(node, 'low_level_detector'):
            node.low_level_detector = patch_fusion_validation(node.low_level_detector)
            node.get_logger().info("Applied fusion validation fix")
        
        def process_frame_with_fusion(self):
            """Modified process_frame that works with fusion."""
            try:
                rgb_available = False
                depth_available = False
                
                if not self.rgb_queue.empty():
                    with self.lock:
                        self.rgb_image = self.rgb_queue.get()
                    rgb_available = True
                
                if not self.depth_queue.empty():
                    with self.lock:
                        self.depth_image = self.depth_queue.get()
                    depth_available = True
                
                # IMPORTANT: Still run YOLO detection here!
                if rgb_available and depth_available and self.yolo_model:
                    # Run YOLO but DON'T draw detections yet
                    results = self.yolo_model(self.rgb_image, conf=0.2)
                    
                    # Store raw YOLO results for fusion
                    self._yolo_results = results
                    
                    # Extract detections for fusion
                    self.cone_detections = []
                    for result in results:
                        if result.boxes is not None:
                            for box in result.boxes:
                                x1, y1, x2, y2 = map(int, box.xyxy[0])
                                conf = box.conf.item()
                                cls = int(box.cls.item())
                                
                                if cls in [0, 1] and conf > 0.2:  # Cone classes
                                    # Get depth from depth map
                                    depth_array, _ = self.depth_image
                                    center_x = (x1 + x2) // 2
                                    center_y = (y1 + y2) // 2
                                    
                                    if 0 <= center_y < depth_array.shape[0] and 0 <= center_x < depth_array.shape[1]:
                                        depth = float(depth_array[center_y, center_x])
                                    else:
                                        depth = 5.0  # Default
                                    
                                    self.cone_detections.append({
                                        'box': (x1, y1, x2, y2),
                                        'cls': cls,
                                        'confidence': conf,
                                        'depth': depth
                                    })
                    
                    # DON'T draw detections here - let fusion handle it
                    node.get_logger().info(f"YOLO detected {len(self.cone_detections)} cones for fusion")
                    
            except Exception as e:
                print(f"Error in process frame with fusion: {e}")
        
        def process_lidar_data_with_fusion(self):
            """Enhanced process_lidar_data using low-level fusion."""
            if self.lidar is None or not hasattr(self, 'lidar_data') or self.lidar_data is None:
                self.get_logger().warn("LiDAR data not available")
                return
            
            # Check for camera data
            if not hasattr(self.zed_camera, 'rgb_image') or self.zed_camera.rgb_image is None:
                self.get_logger().warn("No camera data for fusion, using LiDAR only")
                return self._original_process_lidar_data()
            
            try:
                self.get_logger().info("*** PROCESSING WITH LOW-LEVEL FUSION ***")
                
                # Get LiDAR data in sensor coordinates
                with self.lidar_lock:
                    lidar_data = self.lidar_data.copy()
                
                # Debug: Print LiDAR coordinate analysis
                self.get_logger().info(f"\nDEBUG: Raw LiDAR data analysis:")
                self.get_logger().info(f"  Shape: {lidar_data.shape}")
                self.get_logger().info(f"  X range: [{np.min(lidar_data[:,0]):.2f}, {np.max(lidar_data[:,0]):.2f}]")
                self.get_logger().info(f"  Y range: [{np.min(lidar_data[:,1]):.2f}, {np.max(lidar_data[:,1]):.2f}]")
                self.get_logger().info(f"  Z range: [{np.min(lidar_data[:,2]):.2f}, {np.max(lidar_data[:,2]):.2f}]")
                
                # Filter points for reasonable range
                # Remove points that are too close, too far, or have unreasonable heights
                valid_mask = (
                    (lidar_data[:, 2] > 0.5) &  # Forward distance > 0.5m
                    (lidar_data[:, 2] < 50.0) &  # Forward distance < 50m
                    (np.abs(lidar_data[:, 0]) < 25.0) &  # Lateral distance < 25m
                    (lidar_data[:, 1] > 0.5) &  # Height > 0.5m (above ground)
                    (lidar_data[:, 1] < 5.0)   # Height < 5m (below reasonable ceiling)
                )
                
                filtered_lidar = lidar_data[valid_mask]
                self.get_logger().info(f"Filtered LiDAR: {len(filtered_lidar)}/{len(lidar_data)} points")
                
                # Accumulate points for better detection
                with self.lidar_history_lock:
                    self.lidar_history.append(filtered_lidar)
                    if len(self.lidar_history) > self.accumulate_frames:
                        self.lidar_history.pop(0)
                    
                    all_points = np.vstack(self.lidar_history) if self.lidar_history else filtered_lidar
                
                # Transform for world coordinates (for visualization)
                if hasattr(self, 'lidar') and self.lidar:
                    sensor_transform = np.array(self.lidar.get_transform().get_matrix())
                    from .lidar_camera_fusion import transform_points
                    points_world = transform_points(filtered_lidar, sensor_transform)
                    self.latest_lidar_points = points_world
                else:
                    self.latest_lidar_points = filtered_lidar
                
                # Get RGB image
                rgb_image = self.zed_camera.rgb_image.copy()
                
                # Get existing camera detections
                existing_detections = []
                if hasattr(self.zed_camera, 'cone_detections') and self.zed_camera.cone_detections:
                    existing_detections = self.zed_camera.cone_detections
                    self.get_logger().info(f"Using {len(existing_detections)} camera detections for fusion")
                
                # Perform LOW-LEVEL FUSION detection
                self.get_logger().info(f"Performing LOW-LEVEL FUSION with {len(all_points)} LiDAR points and {len(existing_detections)} camera detections")
                
                # Use identity transform since we handle coordinate conversion in create_feature_maps
                fused_detections = self.low_level_detector.detect_cones_multimodal(
                    rgb_image,
                    all_points,  # Use sensor-local coordinates
                    yolo_model=self.zed_camera.yolo_model if hasattr(self.zed_camera, 'yolo_model') else None,
                    cone_detections=existing_detections
                )
                
                # Update camera detections with fused results
                if fused_detections:
                    self.zed_camera.cone_detections = fused_detections
                    
                    # Draw the fused detections on the image
                    for det in fused_detections:
                        x1, y1, x2, y2 = det['box']
                        cls = det['cls']
                        depth = det['depth']
                        conf = det['confidence']
                        
                        # Draw on image
                        color = (0, 255, 0) if cls == 0 else (255, 0, 0)  # Green for yellow, Blue for blue
                        cv2.rectangle(self.zed_camera.rgb_image, (x1, y1), (x2, y2), color, 2)
                        label = f"Cone: {depth:.2f}m ({conf:.2f})"
                        cv2.putText(self.zed_camera.rgb_image, label, (x1, y1-10), 
                                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
                
                self.get_logger().info(f"LOW-LEVEL FUSION detected {len(fused_detections)} cones")
                
                # Log detection details
                for i, det in enumerate(fused_detections):
                    self.get_logger().info(
                        f"  Cone {i+1}: Depth={det['depth']:.2f}m, "
                        f"Visual={det.get('visual_conf', det['confidence']):.2f}, "
                        f"Fused={det['confidence']:.2f}"
                    )
                
                # Convert to 3D positions for turn analysis
                detected_cones_3d = []
                for det in fused_detections:
                    x1, y1, x2, y2 = det['box']
                    center_x = (x1 + x2) / 2
                    center_y = (y1 + y2) / 2
                    
                    # Simple 3D position estimation using camera model
                    angle = ((center_x - 640) / 640) * (np.radians(45))  # Assuming 90-degree FOV
                    x_3d = det['depth'] * np.tan(angle)
                    
                    detected_cones_3d.append({
                        'position': np.array([x_3d, det['depth'], 0]),
                        'confidence': det['confidence'],
                        'size': [0.3, 0.3, 0.4]
                    })
                
                # Visualize detected cones in 3D
                if hasattr(self, 'visualize_3d_cones'):
                    self.visualize_3d_cones(detected_cones_3d)
                
                # Continue with rest of processing
                self.analyze_lidar_for_turns(self.latest_lidar_points, detected_cones_3d)
                
                # Publish point cloud
                self._publish_lidar_pointcloud(self.latest_lidar_points)
                
            except Exception as e:
                self.get_logger().error(f"Error in low-level fusion: {str(e)}")
                import traceback
                self.get_logger().error(traceback.format_exc())
                # Fallback to original method
                return self._original_process_lidar_data()
        
        def _publish_lidar_pointcloud(self, points):
            """Helper to publish LiDAR point cloud."""
            try:
                header = Header()
                header.stamp = self.get_clock().now().to_msg()
                header.frame_id = "map"
                
                fields = [
                    pc2.PointField(name='x', offset=0, datatype=pc2.PointField.FLOAT32, count=1),
                    pc2.PointField(name='y', offset=4, datatype=pc2.PointField.FLOAT32, count=1),
                    pc2.PointField(name='z', offset=8, datatype=pc2.PointField.FLOAT32, count=1),
                    pc2.PointField(name='intensity', offset=12, datatype=pc2.PointField.FLOAT32, count=1)
                ]
                
                # Create structured array
                structured_points = np.zeros(len(points), 
                                            dtype=[
                                                ('x', np.float32),
                                                ('y', np.float32),
                                                ('z', np.float32),
                                                ('intensity', np.float32)
                                            ])
                
                structured_points['x'] = points[:, 0]
                structured_points['y'] = points[:, 1]
                structured_points['z'] = points[:, 2]
                
                # Simple intensity based on height
                min_z = np.min(points[:, 2])
                max_z = np.max(points[:, 2])
                z_range = max_z - min_z if max_z > min_z else 1.0
                intensity = (points[:, 2] - min_z) / z_range
                structured_points['intensity'] = intensity
                
                pc_msg = pc2.create_cloud(header, fields, structured_points)
                self.lidar_pub.publish(pc_msg)
                
            except Exception as e:
                self.get_logger().error(f"Error publishing point cloud: {str(e)}")
        
        # Bind new methods
        node.zed_camera.process_frame = types.MethodType(process_frame_with_fusion, node.zed_camera)
        node.process_lidar_data = types.MethodType(process_lidar_data_with_fusion, node)
        node._publish_lidar_pointcloud = types.MethodType(_publish_lidar_pointcloud, node)
        
        # Add missing imports
        import cv2
        import numpy as np
        from std_msgs.msg import Header
        import sensor_msgs_py.point_cloud2 as pc2
        
        node.get_logger().info("Low-level fusion integration complete!")
        
    except Exception as e:
        node.get_logger().error(f"Error integrating low-level fusion: {str(e)}")
        import traceback
        node.get_logger().error(traceback.format_exc())
        
        # Restore original methods on failure
        if hasattr(node, '_original_process_lidar_data'):
            node.process_lidar_data = node._original_process_lidar_data
        if hasattr(node, '_original_process_frame'):
            node.zed_camera.process_frame = node._original_process_frame 