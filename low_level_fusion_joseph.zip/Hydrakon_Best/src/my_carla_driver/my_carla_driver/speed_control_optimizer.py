import numpy as np
import time
from collections import deque
from typing import Dict, Tuple, Optional

class OptimizedSpeedController:
    """
    Optimized speed controller for Formula Student autonomous racing.
    Implements predictive control with track-aware speed optimization.
    """
    
    def __init__(self):
        # Speed limits and parameters
        self.max_speed = 20.0  # m/s (72 km/h) - Formula Student typical max
        self.straight_speed = 15.0  # m/s (54 km/h) - speed on straights
        self.corner_speed = 8.0  # m/s (29 km/h) - speed in corners
        self.uturn_speed = 5.0  # m/s (18 km/h) - speed in U-turns
        
        # Vehicle dynamics
        self.max_acceleration = 4.0  # m/s² - typical for FS car
        self.max_deceleration = 8.0  # m/s² - with good brakes
        self.max_lateral_g = 1.5  # g - lateral acceleration limit
        
        # Control parameters
        self.lookahead_time = 2.0  # seconds to look ahead
        self.speed_smoothing = 0.3  # smoothing factor
        
        # State tracking
        self.speed_history = deque(maxlen=20)
        self.steering_history = deque(maxlen=20)
        self.current_speed = 0.0
        self.target_speed = 0.0
        
    def calculate_optimal_speed(self, path_curvature: float, cone_distances: list,
                              steering_angle: float, track_width: float) -> float:
        """
        Calculate optimal speed based on track conditions.
        
        Args:
            path_curvature: Curvature of the upcoming path
            cone_distances: List of distances to detected cones
            steering_angle: Current steering angle [-1, 1]
            track_width: Current track width estimate
            
        Returns:
            Optimal target speed in m/s
        """
        # Base speed from track curvature
        if abs(path_curvature) < 0.1:  # Straight section
            base_speed = self.straight_speed
        elif abs(path_curvature) < 0.3:  # Gentle curve
            base_speed = self.corner_speed + (self.straight_speed - self.corner_speed) * (1 - abs(path_curvature) / 0.3)
        else:  # Sharp turn or U-turn
            base_speed = self.uturn_speed
        
        # Adjust for track width
        width_factor = min(1.0, track_width / 4.0)  # Normalize to 4m standard width
        base_speed *= (0.7 + 0.3 * width_factor)  # Reduce speed on narrow tracks
        
        # Adjust for proximity to cones
        if cone_distances:
            min_cone_dist = min(cone_distances)
            if min_cone_dist < 2.0:  # Very close to cone
                proximity_factor = min_cone_dist / 2.0
                base_speed *= (0.3 + 0.7 * proximity_factor)
        
        # Limit by maximum lateral acceleration
        if abs(steering_angle) > 0.1:
            # v = sqrt(a_lateral * R), where R is turn radius
            turn_radius = self._estimate_turn_radius(steering_angle)
            max_cornering_speed = np.sqrt(self.max_lateral_g * 9.81 * turn_radius)
            base_speed = min(base_speed, max_cornering_speed)
        
        return base_speed
    
    def get_control_command(self, current_speed: float, target_speed: float,
                          dt: float = 0.05) -> Dict[str, float]:
        """
        Get throttle and brake commands for speed control.
        
        Args:
            current_speed: Current vehicle speed in m/s
            target_speed: Target speed in m/s
            dt: Time step in seconds
            
        Returns:
            Dict with 'throttle' and 'brake' values [0, 1]
        """
        self.current_speed = current_speed
        self.target_speed = target_speed
        
        # Calculate required acceleration
        speed_error = target_speed - current_speed
        required_accel = speed_error / dt
        
        # Apply limits
        required_accel = np.clip(required_accel, -self.max_deceleration, self.max_acceleration)
        
        # Convert to throttle/brake commands
        if required_accel > 0:
            # Accelerating - use throttle
            # Map acceleration to throttle (non-linear for realism)
            throttle = self._accel_to_throttle(required_accel, current_speed)
            brake = 0.0
        else:
            # Decelerating - use brake
            throttle = 0.0
            brake = self._decel_to_brake(-required_accel, current_speed)
        
        # Add speed history for analysis
        self.speed_history.append(current_speed)
        
        return {
            'throttle': throttle,
            'brake': brake,
            'target_speed': target_speed,
            'required_accel': required_accel
        }
    
    def _accel_to_throttle(self, accel: float, current_speed: float) -> float:
        """Convert desired acceleration to throttle command."""
        # Higher throttle needed at higher speeds due to drag
        base_throttle = accel / self.max_acceleration
        
        # Speed-dependent correction
        speed_factor = 1.0 + (current_speed / self.max_speed) * 0.5
        
        throttle = base_throttle * speed_factor
        
        # Minimum throttle to overcome resistance
        if throttle > 0 and throttle < 0.2:
            throttle = 0.2
            
        return np.clip(throttle, 0.0, 1.0)
    
    def _decel_to_brake(self, decel: float, current_speed: float) -> float:
        """Convert desired deceleration to brake command."""
        # Simple linear mapping with safety margin
        brake = decel / self.max_deceleration
        
        # More aggressive braking at high speeds
        if current_speed > 10.0:
            brake *= 1.2
            
        return np.clip(brake, 0.0, 1.0)
    
    def _estimate_turn_radius(self, steering_angle: float) -> float:
        """Estimate turn radius from steering angle."""
        # Simplified Ackermann steering model
        wheelbase = 2.7  # meters
        max_steer_angle = np.radians(30)  # max steering angle in radians
        
        if abs(steering_angle) < 0.01:
            return 1000.0  # Very large radius for straight
            
        steer_rad = steering_angle * max_steer_angle
        turn_radius = wheelbase / np.tan(abs(steer_rad))
        
        return max(2.0, turn_radius)  # Minimum radius of 2m


def integrate_speed_optimization(node):
    """
    Integrate optimized speed control into the main node.
    """
    # Create speed controller
    node.speed_controller = OptimizedSpeedController()
    
    # Store original control method
    node._original_control_car = node.control_car
    
    def control_car_optimized(self):
        """Optimized car control with better speed management."""
        if not hasattr(self, 'path_planner') or self.path_planner is None:
            self.set_car_controls(0.0, 3.0)
            return
        
        try:
            # Get current vehicle state
            current_speed = 0.0
            if hasattr(self, 'vehicle') and self.vehicle:
                velocity = self.vehicle.get_velocity()
                current_speed = np.sqrt(velocity.x**2 + velocity.y**2 + velocity.z**2)
            
            # Get path information
            if not self.path_planner.path or len(self.path_planner.path) < 2:
                self.set_car_controls(0.0, 3.0)
                return
            
            # Calculate path curvature
            path_curvature = self._calculate_path_curvature()
            
            # Get cone distances
            cone_distances = []
            if hasattr(self.zed_camera, 'cone_detections'):
                cone_distances = [det['depth'] for det in self.zed_camera.cone_detections if 'depth' in det]
            
            # Get steering angle
            lookahead = max(3.0, min(8.0, current_speed * 0.8))
            steering = self.path_planner.calculate_steering(lookahead_distance=lookahead)
            
            # Calculate optimal speed
            track_width = getattr(self.path_planner, 'current_track_width', 3.5)
            target_speed = self.speed_controller.calculate_optimal_speed(
                path_curvature, cone_distances, steering, track_width
            )
            
            # Check for special conditions
            if hasattr(self, 'in_uturn') and self.in_uturn:
                target_speed = min(target_speed, self.speed_controller.uturn_speed)
            
            # Get control commands
            control = self.speed_controller.get_control_command(current_speed, target_speed)
            
            # Apply controls with Carla
            self._apply_optimized_controls(steering, control['throttle'], control['brake'])
            
            # Log performance
            if hasattr(self, 'get_logger'):
                self.get_logger().info(
                    f"Speed: {current_speed:.1f}/{target_speed:.1f} m/s, "
                    f"Throttle: {control['throttle']:.2f}, Brake: {control['brake']:.2f}, "
                    f"Steer: {steering:.2f}"
                )
                
        except Exception as e:
            self.get_logger().error(f"Error in optimized control: {str(e)}")
            self.set_car_controls(0.0, 2.0)
    
    def _calculate_path_curvature(self):
        """Calculate curvature of the planned path."""
        if not self.path_planner.path or len(self.path_planner.path) < 3:
            return 0.0
        
        # Sample 3 points from the path
        p1 = np.array(self.path_planner.path[0])
        p2 = np.array(self.path_planner.path[len(self.path_planner.path)//2])
        p3 = np.array(self.path_planner.path[-1])
        
        # Calculate curvature using 3-point method
        v1 = p2 - p1
        v2 = p3 - p2
        
        # Cross product gives curvature indication
        cross = np.cross(v1, v2)
        denom = np.linalg.norm(v1) * np.linalg.norm(v2)
        
        if denom > 0:
            curvature = cross / denom
        else:
            curvature = 0.0
            
        return curvature
    
    def _apply_optimized_controls(self, steering, throttle, brake):
        """Apply optimized controls to vehicle."""
        try:
            import carla
            
            control = carla.VehicleControl()
            control.steer = float(steering)
            control.throttle = float(throttle)
            control.brake = float(brake)
            control.reverse = False
            control.hand_brake = False
            control.manual_gear_shift = False
            
            self.vehicle.apply_control(control)
            
            # Force physics update for immediate response
            self.world.tick()
            
        except Exception as e:
            self.get_logger().error(f"Error applying controls: {str(e)}")
    
    # Bind methods
    import types
    node.control_car = types.MethodType(control_car_optimized, node)
    node._calculate_path_curvature = types.MethodType(_calculate_path_curvature, node)
    node._apply_optimized_controls = types.MethodType(_apply_optimized_controls, node)
    
    node.get_logger().info("Speed optimization integrated!")


# Performance monitoring utilities
class PerformanceMonitor:
    """Monitor and log system performance."""
    
    def __init__(self):
        self.timing_history = deque(maxlen=100)
        self.module_timings = {}
        
    def time_module(self, module_name: str):
        """Decorator to time module execution."""
        def decorator(func):
            def wrapper(*args, **kwargs):
                start = time.time()
                result = func(*args, **kwargs)
                elapsed = (time.time() - start) * 1000  # ms
                
                if module_name not in self.module_timings:
                    self.module_timings[module_name] = deque(maxlen=100)
                self.module_timings[module_name].append(elapsed)
                
                return result
            return wrapper
        return decorator
    
    def get_stats(self) -> Dict[str, float]:
        """Get performance statistics."""
        stats = {}
        for module, timings in self.module_timings.items():
            if timings:
                stats[f"{module}_avg_ms"] = np.mean(timings)
                stats[f"{module}_max_ms"] = np.max(timings)
        return stats 