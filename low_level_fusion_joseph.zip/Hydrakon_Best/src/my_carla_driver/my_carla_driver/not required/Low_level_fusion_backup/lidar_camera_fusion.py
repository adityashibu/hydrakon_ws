#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import numpy as np
import time
import cv2
import os
import open3d as o3d
from threading import Lock
from sensor_msgs.msg import Image, PointCloud2, CameraInfo
from std_msgs.msg import Header
import sensor_msgs_py.point_cloud2 as pc2
from cv_bridge import CvBridge
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped, Transform, Vector3, Quaternion, PoseStamped
from visualization_msgs.msg import Marker, MarkerArray
from geometry_msgs.msg import Point
from std_msgs.msg import ColorRGBA
from nav_msgs.msg import Path
import carla
import sys
import threading
import torch
from sklearn.cluster import DBSCAN
import types

# Import your existing modules
from .zed_2i import Zed2iCamera
from .path_planning import PathPlanner
from .low_level_fusion import LowLevelFusionDetector, integrate_low_level_fusion


def transform_points(points, transform):
    """
    Transform an array of points (N x 3) using a 4x4 transformation matrix.
    """
    ones = np.ones((points.shape[0], 1))
    points_hom = np.hstack((points, ones))
    points_world = (transform @ points_hom.T).T[:, :3]
    return points_world


class LidarCameraFusionNode(Node):
    def __init__(self):
        super().__init__('lidar_camera_fusion_node')
        
        # Declare parameters
        self.declare_parameter('model_path', '/home/dalek/Desktop/runs/detect/train8/weights/best.pt')
        self.declare_parameter('use_carla', True)
        self.declare_parameter('carla.host', 'localhost')
        self.declare_parameter('carla.port', 2000)
        self.declare_parameter('carla.timeout', 10.0)
        self.declare_parameter('output_dir', '/home/dalek/attempt_1/Lidar_test/dataset')
        self.declare_parameter('show_opencv_windows', True)
        self.declare_parameter('lidar_point_size', 0.4)
        self.declare_parameter('pointnet_model_path', '/home/dalek/attempt_1/pointnet_detector.pth')
        self.declare_parameter('accumulate_lidar_frames', 3)
        self.declare_parameter('use_low_level_fusion', True)  # New parameter for low-level fusion
        
        # Get parameters
        self.model_path = self.get_parameter('model_path').value
        self.use_carla = self.get_parameter('use_carla').value
        self.carla_host = self.get_parameter('carla.host').value
        self.carla_port = self.get_parameter('carla.port').value
        self.carla_timeout = self.get_parameter('carla.timeout').value
        self.output_dir = self.get_parameter('output_dir').value
        self.show_opencv_windows = self.get_parameter('show_opencv_windows').value
        self.lidar_point_size = self.get_parameter('lidar_point_size').value
        self.pointnet_model_path = self.get_parameter('pointnet_model_path').value
        self.accumulate_frames = self.get_parameter('accumulate_lidar_frames').value
        self.use_low_level_fusion = self.get_parameter('use_low_level_fusion').value
        
        # Initialize cone_mapper
        self.cone_mapper = None
        
        # Initialize low-level fusion detector if enabled
        if self.use_low_level_fusion:
            try:
                self.low_level_detector = LowLevelFusionDetector(
                    camera_resolution=(1280, 720),  # Match ZED camera resolution
                    fov_horizontal=90.0  # Match ZED camera FOV
                )
                self.get_logger().info("Low-level fusion detector initialized successfully")
            except Exception as e:
                self.get_logger().error(f"Failed to initialize low-level fusion detector: {str(e)}")
                self.use_low_level_fusion = False
        
        # Bridge for converting between ROS and OpenCV images
        self.bridge = CvBridge()
        
        # Create publishers
        self.rgb_pub = self.create_publisher(Image, '/carla/rgb_image', 10)
        self.depth_pub = self.create_publisher(Image, '/carla/depth_image', 10)
        self.path_pub = self.create_publisher(Image, '/carla/path_image', 10)
        self.lidar_pub = self.create_publisher(PointCloud2, '/carla/lidar_points', 10)
        self.fused_pub = self.create_publisher(PointCloud2, '/carla/fused_points', 10)
        self.cone_marker_pub = self.create_publisher(MarkerArray, '/carla/lidar_cones', 10)
        self.path_vis_pub = self.create_publisher(Path, '/carla/path', 10)
        
        # Transform broadcaster for tf tree
        self.tf_broadcaster = TransformBroadcaster(self)
        
        # Initialize state variables
        self.world = None
        self.vehicle = None
        self.zed_camera = None
        self.path_planner = None
        self.lidar = None
        self.lidar_data = None
        self.lidar_lock = Lock()
        self.vis_thread = None
        
        # Initialize LiDAR history for point accumulation
        self.lidar_history = []
        self.lidar_history_lock = Lock()
        
        # Vehicle tracking
        self.vehicle_poses = []
        self.cone_map = []
        
        # Initialize speed and steering control variables
        self.prev_target_speed = 0.0
        self.prev_steering = 0.0
        
        # Turn detection state
        self.lidar_right_turn_detected = False
        self.lidar_left_turn_detected = False
        self.lidar_turn_distance = float('inf')
        self.lidar_turn_confidence = 0.0
        self.uturn_state = {'detected': False, 'distance': float('inf'), 'score': 0.0, 'direction': 'right'}
        
        # Timer for main processing
        self.timer = self.create_timer(0.05, self.timer_callback)  # 20 Hz
        
        # Setup Carla and sensors
        self.setup()
    
    def setup(self):
        """Initialize Carla, vehicle, camera, and LiDAR."""
        if not self.use_carla:
            self.get_logger().info("Carla integration disabled")
            return False
            
        try:
            client = carla.Client(self.carla_host, self.carla_port)
            client.set_timeout(self.carla_timeout)
            self.get_logger().info("Connecting to CARLA server...")
            
            self.world = client.get_world()
            self.get_logger().info("Connected to CARLA world successfully")
            
            self.vehicle = self.spawn_vehicle()
            if not self.vehicle:
                self.get_logger().error("Failed to spawn vehicle")
                return False
                
            # Initialize ZED camera
            self.zed_camera = Zed2iCamera(self.world, self.vehicle, 
                                         resolution=(1280, 720), 
                                         fps=30, 
                                         model_path=self.model_path)
            
            if not self.zed_camera.setup():
                self.get_logger().error("Failed to setup ZED camera")
                return False
                
            # Initialize path planner
            self.path_planner = PathPlanner(self.zed_camera, 
                                           depth_min=1.0, 
                                           depth_max=20.0, 
                                           cone_spacing=1.5, 
                                           visualize=True)
            
            # Setup LiDAR
            if not self.setup_lidar():
                self.get_logger().error("Failed to setup LiDAR")
                return False
                
            # Enable OpenCV windows if configured
            if self.show_opencv_windows:
                self.vis_thread = threading.Thread(target=self.visualization_thread)
                self.vis_thread.daemon = True
                self.vis_thread.start()
                self.get_logger().info("OpenCV visualization enabled")
            else:
                self.get_logger().info("OpenCV visualization disabled (use RViz)")
                
            # Integrate low-level fusion if enabled
            if self.use_low_level_fusion:
                self.get_logger().info("Enabling low-level sensor fusion")
                integrate_low_level_fusion(self)
                self.get_logger().info("Low-level fusion integration complete")
                
            self.get_logger().info("Carla setup completed successfully")
            return True
                
        except Exception as e:
            self.get_logger().error(f"Error setting up Carla: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
            return False
    
    def spawn_vehicle(self):
        """Spawn a vehicle in the CARLA world."""
        try:
            blueprint_library = self.world.get_blueprint_library()
            vehicle_bp = blueprint_library.filter('vehicle.*')[2]
            if not vehicle_bp:
                self.get_logger().error("No vehicle blueprints found")
                return None
                
            self.get_logger().info(f"Using vehicle blueprint: {vehicle_bp.id}")
            
            spawn_transform = carla.Transform(
                carla.Location(x=-35.0, y=0.0, z=5.0),
                carla.Rotation(pitch=0.0, yaw=0.0, roll=0.0)
            )
            vehicle = self.world.spawn_actor(vehicle_bp, spawn_transform)
            self.get_logger().info(f"Vehicle spawned at {spawn_transform.location}")
            
            time.sleep(2.0)
            if not vehicle.is_alive:
                self.get_logger().error("Vehicle failed to spawn or is not alive")
                return None
            return vehicle
        except Exception as e:
            self.get_logger().error(f"Error spawning vehicle: {str(e)}")
            return None
    
    def setup_lidar(self):
        """Setup LiDAR sensor."""
        try:
            # Setup LiDAR sensor
            lidar_bp = self.world.get_blueprint_library().find('sensor.lidar.ray_cast')
            if not lidar_bp:
                self.get_logger().error("LiDAR blueprint not found")
                return False
                
            # Configure LiDAR attributes
            lidar_bp.set_attribute('channels', '128')
            lidar_bp.set_attribute('points_per_second', '1000000')
            lidar_bp.set_attribute('rotation_frequency', '20')
            lidar_bp.set_attribute('range', '100')
            lidar_bp.set_attribute('upper_fov', '30')
            lidar_bp.set_attribute('lower_fov', '-30')
            
            # Position LiDAR above the vehicle
            lidar_transform = carla.Transform(carla.Location(x=1.5, z=2.2))
            self.get_logger().info(f"Spawning LiDAR at {lidar_transform.location}")
            
            self.lidar = self.world.spawn_actor(lidar_bp, lidar_transform, attach_to=self.vehicle)
            
            # Listen to LiDAR data
            self.lidar.listen(lambda data: self._lidar_callback(data))
            self.get_logger().info("LiDAR sensor spawned successfully")
            
            return True
        except Exception as e:
            self.get_logger().error(f"Error setting up LiDAR sensor: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
            return False
    
    def _lidar_callback(self, data):
        """Callback to process LiDAR data (runs in sensor thread)."""
        try:
            # Process raw LiDAR data into an (N, 4) array and keep only x, y, z
            points = np.frombuffer(data.raw_data, dtype=np.dtype('f4'))
            points = np.reshape(points, (-1, 4))
            
            with self.lidar_lock:
                self.lidar_data = points[:, :3]
                self.lidar_frame = data.frame
                self.lidar_timestamp = data.timestamp
            
            self.get_logger().debug(f"Captured {len(self.lidar_data)} LiDAR points")
            
            # Save PCD file every 10 frames
            if hasattr(self, 'output_dir') and data.frame % 10 == 0:
                pcd_temp = o3d.geometry.PointCloud()
                pcd_temp.points = o3d.utility.Vector3dVector(points[:, :3])
                pcd_path = os.path.join(self.output_dir, f"lidar_{data.frame:04d}.pcd")
                o3d.io.write_point_cloud(pcd_path, pcd_temp)
                self.get_logger().info(f"Saved PCD to {pcd_path}")
        except Exception as e:
            self.get_logger().error(f"Error in LiDAR callback: {str(e)}")
    
    def timer_callback(self):
        """Main control loop callback."""
        if not self.use_carla or not self.vehicle or not self.zed_camera:
            return
            
        try:
            # Debug fusion mode
            self.get_logger().info(f"Fusion mode: {'LOW-LEVEL' if hasattr(self, 'low_level_detector') else 'MID-LEVEL'}")
            
            # Process camera frame
            self.zed_camera.process_frame()
            
            # Process LiDAR data
            self.process_lidar_data()
            
            # Visualize current PCD data
            self.visualize_pcd_data()
            
            # Update PCD browser
            self.update_pcd_file_list()
            
            # Handle keyboard input
            self.handle_keyboard_input()
            
            # Plan path
            self.path_planner.plan_path()
            
            # Control the car and measure latency
            start_time = time.time()
            self.control_car()
            control_latency = (time.time() - start_time) * 1000  # in milliseconds
            
            # Get current speed
            current_speed = 0
            if hasattr(self, 'vehicle') and self.vehicle:
                velocity = self.vehicle.get_velocity()
                current_speed = np.sqrt(velocity.x**2 + velocity.y**2 + velocity.z**2)
            
            # Update and publish metrics
            self.update_and_publish_metrics(control_latency, current_speed, self.prev_target_speed)
            
            # Visualize detected cones
            self.visualize_detected_cones()
            
            # Publish camera and path data for RViz
            self.publish_data()
            
            # Publish path for RViz
            self.publish_path_for_rviz()
            
            # Broadcast transforms
            self.broadcast_tf()

            # Publish visualization data
            if self.cone_mapper is not None:
                self.publish_cone_map(self.cone_mapper)
            self.publish_path(self.path_planner)
            if hasattr(self, 'latest_point_cloud'):
                self.publish_lidar_points(self.latest_point_cloud)

            # Save map and path periodically (e.g., every 100 updates)
            if hasattr(self, 'cone_mapper') and self.cone_mapper is not None and self.cone_mapper.total_updates % 100 == 0:
                self.save_map_and_path()
            
        except Exception as e:
            self.get_logger().error(f"Error in timer callback: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
    
    def detect_cones_from_lidar(self, lidar_points):
        """
        Use PointNet model to detect cones from LiDAR point cloud
        
        Args:
            lidar_points: Numpy array of shape (N, 3) containing LiDAR points
            
        Returns:
            list of detected cones with position and confidence
        """
        try:
            if not hasattr(self, 'pointnet_model'):
                # Check if model path is set
                if not hasattr(self, 'pointnet_model_path'):
                    self.pointnet_model_path = "/home/dalek/attempt_1/pointnet_detector.pth"
                    self.get_logger().info(f"Using default PointNet model path: {self.pointnet_model_path}")
                
                # Load PointNet model
                if os.path.exists(self.pointnet_model_path):
                    self.get_logger().info(f"Loading PointNet model from {self.pointnet_model_path}")
                    self.pointnet_model = torch.load(self.pointnet_model_path, map_location=torch.device('cpu'))
                    self.pointnet_model.eval()  # Set to evaluation mode
                else:
                    self.get_logger().error(f"PointNet model not found at {self.pointnet_model_path}")
                    return []
            
            # Need to preprocess point cloud for PointNet
            if len(lidar_points) < 10:  # Need minimum number of points
                return []
                
            # Here we would normally preprocess the points for PointNet
            # For demonstration, we'll simulate detections
            # In a real implementation, you would run the model on the points
            
            # Find clusters of points that might be cones
            # This is a simplified approach - real implementation would use the PointNet model
            detected_cones = []
            
            # Simple clustering - find points close to ground and cluster them
            # In 3D space, cones are typically small clusters of points
            ground_height = np.min(lidar_points[:, 2]) + 0.1  # Slightly above ground
            
            # Filter points close to ground
            near_ground_mask = (lidar_points[:, 2] < ground_height + 0.5) & (lidar_points[:, 2] > ground_height)
            near_ground_points = lidar_points[near_ground_mask]
            
            if len(near_ground_points) > 5:
                # Very simple clustering - just for demonstration
                # A real implementation would use DBSCAN or another clustering algorithm
                
                # Cluster points
                clustering = DBSCAN(eps=0.5, min_samples=5).fit(near_ground_points[:, :3])
                labels = clustering.labels_
                
                # Get cluster centers
                unique_labels = set(labels)
                for label in unique_labels:
                    if label != -1:  # Ignore noise
                        cluster_points = near_ground_points[labels == label]
                        center = np.mean(cluster_points, axis=0)
                        
                        # Simple size check - cones are small
                        max_distance = np.max(np.sqrt(np.sum((cluster_points - center)**2, axis=1)))
                        if max_distance < 0.5:  # Cones are typically small
                            # This is a potential cone
                            confidence = 0.7  # Simulated confidence
                            detected_cones.append({
                                'position': center,
                                'confidence': confidence,
                                'size': [0.3, 0.3, 0.4]  # Approximate cone size
                            })
            
            self.get_logger().info(f"Detected {len(detected_cones)} cones from LiDAR using PointNet")
            return detected_cones
            
        except Exception as e:
            self.get_logger().error(f"Error in PointNet detection: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
            return []

    def visualize_3d_cones(self, detected_cones):
        """
        Visualize detected cones as 3D markers in RViz
        
        Args:
            detected_cones: List of dictionaries containing cone position and confidence
        """
        try:
            marker_array = MarkerArray()
            
            for i, cone in enumerate(detected_cones):
                # Create a cone marker
                marker = Marker()
                marker.header.frame_id = "map"
                marker.header.stamp = self.get_clock().now().to_msg()
                marker.ns = "lidar_cones"
                marker.id = i
                marker.type = Marker.CYLINDER  # Use cylinder for cone
                marker.action = Marker.ADD
                
                # Set position
                marker.pose.position.x = cone['position'][0]
                marker.pose.position.y = cone['position'][1]
                marker.pose.position.z = cone['position'][2]
                
                # Set orientation (upright)
                marker.pose.orientation.x = 0.0
                marker.pose.orientation.y = 0.0
                marker.pose.orientation.z = 0.0
                marker.pose.orientation.w = 1.0
                
                # Set scale
                marker.scale.x = cone['size'][0]  # Diameter
                marker.scale.y = cone['size'][1]  # Diameter
                marker.scale.z = cone['size'][2]  # Height
                
                # Set color based on confidence
                confidence = cone['confidence']
                marker.color.r = 1.0
                marker.color.g = confidence  # Higher confidence = more yellow
                marker.color.b = 0.0
                marker.color.a = 0.8  # Slightly transparent
                
                # Make it persistent for a while
                marker.lifetime.sec = 1
                
                marker_array.markers.append(marker)
            
            # Publish the marker array
            self.cone_marker_pub.publish(marker_array)
            
        except Exception as e:
            self.get_logger().error(f"Error visualizing cones: {str(e)}")

    def process_lidar_data(self):
        """Process LiDAR data and detect cones."""
        if self.lidar is None or not hasattr(self, 'lidar_data') or self.lidar_data is None:
            self.get_logger().warn("LiDAR data not available")
            return
        
        try:
            # Get LiDAR data
            with self.lidar_lock:
                lidar_data = self.lidar_data.copy()
            
            # Get sensor transformation
            sensor_transform = np.array(self.lidar.get_transform().get_matrix())
            
            # Transform to world coordinates
            points_world = transform_points(lidar_data, sensor_transform)
            
            # Accumulate points
            with self.lidar_history_lock:
                self.lidar_history.append(points_world)
                if len(self.lidar_history) > self.accumulate_frames:
                    self.lidar_history.pop(0)
                
                all_points = np.vstack(self.lidar_history)
            
            self.latest_lidar_points = all_points
            
            # Check if we have camera data for fusion
            if hasattr(self.zed_camera, 'rgb_image') and self.zed_camera.rgb_image is not None:
                if self.use_low_level_fusion:
                    # Use low-level fusion for detection
                    self.get_logger().info("*** PROCESSING WITH LOW-LEVEL FUSION ***")
                    
                    # Get RGB image
                    rgb_image = self.zed_camera.rgb_image.copy()
                    
                    # Get existing camera detections if available
                    existing_detections = []
                    if hasattr(self.zed_camera, 'cone_detections'):
                        existing_detections = self.zed_camera.cone_detections
                    
                    # Perform LOW-LEVEL FUSION detection
                    self.get_logger().info(f"Performing LOW-LEVEL FUSION with {len(all_points)} LiDAR points")
                    
                    fused_detections = self.low_level_detector.detect_cones_multimodal(
                        rgb_image,
                        all_points,
                        yolo_model=self.zed_camera.yolo_model if hasattr(self.zed_camera, 'yolo_model') else None,
                        cone_detections=existing_detections
                    )
                    
                    # Update camera detections with fused results
                    self.zed_camera.cone_detections = fused_detections
                    
                    self.get_logger().info(f"LOW-LEVEL FUSION detected {len(fused_detections)} cones")
                    
                    # Log detection details
                    for i, det in enumerate(fused_detections):
                        self.get_logger().info(
                            f"  Cone {i+1}: Depth={det['depth']:.2f}m, "
                            f"Visual={det['visual_conf']:.2f}, "
                            f"LiDAR={det['lidar_conf']:.2f}, "
                            f"Fused={det['confidence']:.2f}"
                        )
                    
                    # Visualize detected cones in 3D
                    detected_cones = []
                    for det in fused_detections:
                        # Estimate 3D position
                        x1, y1, x2, y2 = det['box']
                        center_x = (x1 + x2) / 2
                        center_y = (y1 + y2) / 2
                        
                        # Simple 3D position estimation
                        angle = ((center_x - 640) / 640) * (np.radians(45))
                        x_3d = det['depth'] * np.tan(angle)
                        
                        detected_cones.append({
                            'position': np.array([x_3d, det['depth'], 0]),
                            'confidence': det['confidence'],
                            'size': [0.3, 0.3, 0.4]
                        })
                    
                    if hasattr(self, 'visualize_3d_cones'):
                        self.visualize_3d_cones(detected_cones)
                    
                    # Continue with rest of processing (turn analysis, etc.)
                    self.analyze_lidar_for_turns(all_points, detected_cones)
                    
                    # Publish point cloud
                    self._publish_lidar_pointcloud(all_points)
                    
                else:
                    # Use traditional mid-level fusion
                    self.get_logger().info("Using traditional mid-level fusion")
                    detected_cones = self.detect_cones_from_lidar(all_points)
                    self.analyze_lidar_for_turns(all_points, detected_cones)
            else:
                # No camera data, use LiDAR only
                self.get_logger().warn("No camera data available, using LiDAR only")
                detected_cones = self.detect_cones_from_lidar(all_points)
                self.analyze_lidar_for_turns(all_points, detected_cones)
            
        except Exception as e:
            self.get_logger().error(f"Error processing LiDAR data: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())

    def analyze_lidar_for_turns(self, points, detected_cones):
        """Analyze LiDAR point cloud and detected cones to detect upcoming turns."""
        try:
            # Initialize turn information
            self.lidar_right_turn_detected = False
            self.lidar_left_turn_detected = False
            self.lidar_turn_distance = float('inf')
            self.lidar_turn_confidence = 0.0
            
            # Use detected cones if available, otherwise use clustering approach
            if detected_cones and len(detected_cones) >= 3:
                self.get_logger().info("Using detected cones for turn analysis")
                
                # Extract cone positions
                cone_positions = [cone['position'] for cone in detected_cones]
                
                # Simple approach: Look for significant lateral deviation in the cone pattern
                cone_positions.sort(key=lambda p: p[1])  # Sort by Y distance (forward)
                
                # Analyze lateral position trend
                x_positions = [p[0] for p in cone_positions]
                
                # If we have enough cones, try to detect a pattern
                if len(x_positions) >= 4:
                    # Simple trend analysis: are right side points moving left (right turn) or
                    # left side points moving right (left turn)?
                    
                    # Divide into near and far points
                    mid_idx = len(x_positions) // 2
                    near_avg_x = sum(x_positions[:mid_idx]) / mid_idx
                    far_avg_x = sum(x_positions[mid_idx:]) / (len(x_positions) - mid_idx)
                    
                    # Check for significant lateral shift
                    lateral_shift = far_avg_x - near_avg_x
                    
                    # DIAGNOSTIC
                    self.get_logger().info(f"Cone lateral shift analysis: near_avg_x={near_avg_x:.2f}, far_avg_x={far_avg_x:.2f}, shift={lateral_shift:.2f}")
                    
                    if lateral_shift < -0.3:  # Right turn
                        self.lidar_right_turn_detected = True
                        self.lidar_turn_distance = far_centers[0][0]  # Distance to start of far segment
                        self.lidar_turn_confidence = min(1.0, abs(lateral_shift) / 1.0)
                        self.get_logger().warn(f"LiDAR detected RIGHT TURN at {self.lidar_turn_distance:.2f}m (shift: {lateral_shift:.2f})")
                        
                    elif lateral_shift > 0.3:  # Left turn
                        self.lidar_left_turn_detected = True
                        self.lidar_turn_distance = far_centers[0][0]  # Distance to start of far segment
                        self.lidar_turn_confidence = min(1.0, abs(lateral_shift) / 1.0)
                        self.get_logger().warn(f"LiDAR detected LEFT TURN at {self.lidar_turn_distance:.2f}m (shift: {lateral_shift:.2f})")
            
            # If no cones detected or not enough, use point cloud analysis
            else:
                self.get_logger().info("Not enough cones detected, using point cloud analysis")
                
                # Filter to points likely to be cones (above ground, below certain height)
                cone_height_min = 0.05  # 5cm above ground
                cone_height_max = 0.5   # 50cm tall (typical cone height)
                potential_cone_points = [p for p in points if cone_height_min < p[2] < cone_height_max]
                
                # DIAGNOSTIC
                self.get_logger().info(f"Found {len(potential_cone_points)} potential cone points in height range")
                
                if len(potential_cone_points) < 10:
                    self.get_logger().warn("Not enough potential cone points for analysis")
                    return
                
                # Simple approach: analyze the X distribution of points at different depths
                points_by_depth = {}
                depth_interval = 2.0  # Group points in 2m intervals
                
                for point in potential_cone_points:
                    depth_bin = int(point[1] / depth_interval) * depth_interval
                    if depth_bin not in points_by_depth:
                        points_by_depth[depth_bin] = []
                    points_by_depth[depth_bin].append(point)
                
                # Sort depth bins
                sorted_depths = sorted(points_by_depth.keys())
                
                # DIAGNOSTIC
                self.get_logger().info(f"Point depth distribution: {', '.join([f'{d}m:{len(points_by_depth[d])}' for d in sorted_depths])}")
                
                # Need at least 3 depth bins for trend analysis
                if len(sorted_depths) >= 3:
                    # Calculate average X position at each depth
                    avg_x_by_depth = {d: sum(p[0] for p in points_by_depth[d]) / len(points_by_depth[d]) for d in sorted_depths}
                    
                    # Check for consistent lateral shift trend
                    x_shifts = []
                    for i in range(1, len(sorted_depths)):
                        prev_depth = sorted_depths[i-1]
                        curr_depth = sorted_depths[i]
                        x_shift = avg_x_by_depth[curr_depth] - avg_x_by_depth[prev_depth]
                        x_shifts.append(x_shift)
                    
                    # If consistent trend detected
                    if len(x_shifts) >= 2:
                        avg_shift = sum(x_shifts) / len(x_shifts)
                        
                        # DIAGNOSTIC
                        self.get_logger().info(f"Average X shift per depth interval: {avg_shift:.3f}m")
                        
                        if avg_shift < -0.2:  # Consistent shift right to left = right turn
                            self.lidar_right_turn_detected = True
                            self.lidar_turn_distance = sorted_depths[1]  # Use second depth bin as turn distance
                            self.lidar_turn_confidence = min(1.0, abs(avg_shift) / 0.5)
                            self.get_logger().warn(f"LiDAR point cloud analysis: RIGHT TURN at {self.lidar_turn_distance:.1f}m (shift: {avg_shift:.2f})")
                            
                        elif avg_shift > 0.2:  # Consistent shift left to right = left turn
                            self.lidar_left_turn_detected = True
                            self.lidar_turn_distance = sorted_depths[1]
                            self.lidar_turn_confidence = min(1.0, abs(avg_shift) / 0.5)
                            self.get_logger().warn(f"LiDAR point cloud analysis: LEFT TURN at {self.lidar_turn_distance:.1f}m (shift: {avg_shift:.2f})")
                    
            # Return results for use in control logic
            return {
                'right_turn': self.lidar_right_turn_detected,
                'left_turn': self.lidar_left_turn_detected,
                'distance': self.lidar_turn_distance,
                'confidence': self.lidar_turn_confidence
            }
            
        except Exception as e:
            self.get_logger().error(f"Error analyzing LiDAR for turns: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
            return None

    def fuse_data(self):
        """Fuse LiDAR and camera data."""
        if self.zed_camera is None or self.zed_camera.rgb_image is None or self.zed_camera.depth_image is None:
            return
            
        if self.lidar_data is None:
            return
            
        try:
            # Get depth image
            depth_array, _ = self.zed_camera.depth_image
            
            # Project LiDAR points to camera image
            lidar_transform = np.array(self.lidar.get_transform().get_matrix())
            camera_transform = np.array(self.zed_camera.rgb_sensor.get_transform().get_matrix())
            
            # Calculate relative transform from LiDAR to camera
            lidar_to_camera = np.linalg.inv(camera_transform) @ lidar_transform
            
            # Copy LiDAR data to avoid race conditions
            with self.lidar_lock:
                lidar_data = self.lidar_data.copy()
            
            # Transform LiDAR points to camera frame
            points_camera_frame = transform_points(lidar_data, lidar_to_camera)
            
            # Simple data fusion: Filter LiDAR points by camera FOV and depth
            # This is a basic fusion - more sophisticated methods can be implemented
            valid_points = []
            colors = []
            
            for i, point in enumerate(points_camera_frame):
                # Only keep points in front of camera
                if point[2] <= 0:
                    continue
                    
                # Project point to image
                x, y, z = point
                
                # Basic pinhole camera model (approximation)
                # This should be replaced with proper camera calibration parameters
                fx = 800.0  # focal length x
                fy = 800.0  # focal length y
                cx = 640.0  # optical center x
                cy = 360.0  # optical center y
                
                u = int(fx * x / z + cx)
                v = int(fy * y / z + cy)
                
                # Check if point projects into image
                if (0 <= u < 1280 and 0 <= v < 720):
                    # Get depth from depth image at projected point
                    if depth_array is not None:
                        camera_depth = depth_array[v, u] if v < depth_array.shape[0] and u < depth_array.shape[1] else 0
                        
                        # Compare LiDAR depth with camera depth
                        lidar_depth = np.abs(z)
                        
                        # If depths are similar, consider it a valid fusion point
                        if camera_depth > 0 and abs(lidar_depth - camera_depth) < 2.0:
                            valid_points.append(point)
                            
                            # Get color from RGB image
                            if self.zed_camera.rgb_image is not None:
                                r, g, b = self.zed_camera.rgb_image[v, u]
                                colors.append([r/255.0, g/255.0, b/255.0])
                            else:
                                colors.append([1.0, 1.0, 1.0])  # White if no color available
            
            # Create fused colored point cloud
            if valid_points:
                fused_points = np.array(valid_points)
                
                # Transform back to world frame
                fused_points_world = transform_points(fused_points, camera_transform)
                
                # Create PointCloud2 message for fused points
                header = Header()
                header.stamp = self.get_clock().now().to_msg()
                header.frame_id = "map"
                
                # Publisher requires a structured point cloud with fields
                # We'll create an uncolored point cloud for simplicity
                pc_msg = pc2.create_cloud_xyz32(header, fused_points_world)
                self.fused_pub.publish(pc_msg)
                
                # For colored point cloud:
                # fields = [PointField(name='x', offset=0, datatype=PointField.FLOAT32, count=1),
                #          PointField(name='y', offset=4, datatype=PointField.FLOAT32, count=1),
                #          PointField(name='z', offset=8, datatype=PointField.FLOAT32, count=1),
                #          PointField(name='r', offset=12, datatype=PointField.FLOAT32, count=1),
                #          PointField(name='g', offset=16, datatype=PointField.FLOAT32, count=1),
                #          PointField(name='b', offset=20, datatype=PointField.FLOAT32, count=1)]
                
                self.get_logger().debug(f"Published {len(valid_points)} fused points")
        except Exception as e:
            self.get_logger().error(f"Error in data fusion: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
    
    def publish_data(self):
        """Publish camera and path planning data."""
        if (self.zed_camera is None or 
            not hasattr(self.zed_camera, 'rgb_image') or 
            not hasattr(self.zed_camera, 'depth_image') or
            self.zed_camera.rgb_image is None or 
            self.zed_camera.depth_image is None):
            return
            
        try:
            # RGB image
            rgb_img = self.zed_camera.rgb_image.copy()
            rgb_msg = self.bridge.cv2_to_imgmsg(rgb_img, encoding="bgr8")
            rgb_msg.header.stamp = self.get_clock().now().to_msg()
            rgb_msg.header.frame_id = "camera_link"
            self.rgb_pub.publish(rgb_msg)
            
            # Depth image
            _, depth_img = self.zed_camera.depth_image
            if depth_img is not None:
                depth_msg = self.bridge.cv2_to_imgmsg(depth_img, encoding="bgr8")
                depth_msg.header.stamp = self.get_clock().now().to_msg()
                depth_msg.header.frame_id = "camera_link"
                self.depth_pub.publish(depth_msg)
            
            # Path visualization
            if self.path_planner and rgb_img is not None:
                path_img = self.path_planner.draw_path(rgb_img.copy())
                path_msg = self.bridge.cv2_to_imgmsg(path_img, encoding="bgr8")
                path_msg.header.stamp = self.get_clock().now().to_msg()
                path_msg.header.frame_id = "camera_link"
                self.path_pub.publish(path_msg)
                
        except Exception as e:
            self.get_logger().error(f"Error publishing data: {str(e)}")
    
    def broadcast_tf(self):
        """Broadcast coordinate transforms for the vehicle and sensors."""
        try:
            if not hasattr(self, 'vehicle') or not self.vehicle:
                return
                
            # Get vehicle transform
            vehicle_transform = self.vehicle.get_transform()
            
            # Broadcast vehicle to map transform
            t = TransformStamped()
            t.header.stamp = self.get_clock().now().to_msg()
            t.header.frame_id = "map"
            t.child_frame_id = "base_link"
            
            # Set translation
            t.transform.translation.x = vehicle_transform.location.x
            t.transform.translation.y = vehicle_transform.location.y
            t.transform.translation.z = vehicle_transform.location.z
            
            # Convert rotation to quaternion
            roll = np.radians(vehicle_transform.rotation.roll)
            pitch = np.radians(vehicle_transform.rotation.pitch)
            yaw = np.radians(vehicle_transform.rotation.yaw)
            
            cy = np.cos(yaw * 0.5)
            sy = np.sin(yaw * 0.5)
            cp = np.cos(pitch * 0.5)
            sp = np.sin(pitch * 0.5)
            cr = np.cos(roll * 0.5)
            sr = np.sin(roll * 0.5)
            
            t.transform.rotation.w = cr * cp * cy + sr * sp * sy
            t.transform.rotation.x = sr * cp * cy - cr * sp * sy
            t.transform.rotation.y = cr * sp * cy + sr * cp * sy
            t.transform.rotation.z = cr * cp * sy - sr * sp * cy
            
            # Broadcast the transform
            self.tf_broadcaster.sendTransform(t)
            
        except Exception as e:
            self.get_logger().error(f"Error broadcasting transforms: {str(e)}")
    
    def visualization_thread(self):
        """Thread for OpenCV visualization."""
        while self.show_opencv_windows:
            try:
                if (self.zed_camera is not None and 
                    hasattr(self.zed_camera, 'rgb_image') and 
                    self.zed_camera.rgb_image is not None):
                    
                    # Show RGB image with detections
                    cv2.imshow('RGB Image with Detections', self.zed_camera.rgb_image)
                    
                    # Show depth image if available
                    if (hasattr(self.zed_camera, 'depth_image') and 
                        self.zed_camera.depth_image is not None):
                        _, depth_img = self.zed_camera.depth_image
                        if depth_img is not None:
                            cv2.imshow('Depth Image', depth_img)
                    
                    # Break loop if 'q' is pressed
                    if cv2.waitKey(1) & 0xFF == ord('q'):
                        self.show_opencv_windows = False
                        break
                    
                    time.sleep(0.05)  # 20 Hz refresh rate
                else:
                    time.sleep(0.1)  # Slower refresh rate when no data
                    
            except Exception as e:
                self.get_logger().error(f"Error in visualization thread: {str(e)}")
                time.sleep(0.1)
        
        cv2.destroyAllWindows()
    
    def destroy_node(self):
        """Clean up resources on node shutdown."""
        self.get_logger().info("Shutting down fusion node...")
        
        # Disable OpenCV windows
        self.show_opencv_windows = False
        if self.vis_thread and self.vis_thread.is_alive():
            self.vis_thread.join(timeout=1.0)
        
        # Clean up Carla resources
        if self.lidar:
            self.lidar.stop()
            self.lidar.destroy()
            self.get_logger().info("LiDAR sensor destroyed")
        
        if self.zed_camera:
            self.zed_camera.shutdown()
            self.get_logger().info("ZED camera shut down")
        
        if self.vehicle:
            self.vehicle.destroy()
            self.get_logger().info("Vehicle destroyed")
        
        super().destroy_node()

    def publish_path_for_rviz(self):
        """Publish the planned path for visualization in RViz."""
        try:
            if not hasattr(self, 'path_planner') or not self.path_planner or not self.vehicle:
                return
                
            # Get the planned path
            path = self.path_planner.get_path()
            if path is None or len(path) == 0:
                return
                
            # Get vehicle transform
            vehicle_transform = self.vehicle.get_transform()
            vehicle_location = vehicle_transform.location
            vehicle_rotation = vehicle_transform.rotation
            
            # Create Path message
            path_msg = Path()
            path_msg.header.frame_id = "map"
            path_msg.header.stamp = self.get_clock().now().to_msg()
            
            # Convert vehicle's yaw to rotation matrix
            # Subtract 90 degrees (π/2) to rotate the path to the right
            yaw = np.radians(vehicle_rotation.yaw )
            rotation_matrix = np.array([
                [np.cos(yaw), -np.sin(yaw)],
                [np.sin(yaw), np.cos(yaw)]
            ])
            
            # Convert path points to PoseStamped messages
            for point in path:
                # Swap and invert coordinates to fix orientation
                # Original path point is (x forward, y left) in vehicle frame
                # We want (x right, y forward) in world frame
                local_point = np.array([point[1], point[0]])  # Swap coordinates
                world_point = rotation_matrix @ local_point
                
                pose = PoseStamped()
                pose.header = path_msg.header
                pose.pose.position.x = vehicle_location.x + world_point[0]
                pose.pose.position.y = vehicle_location.y + world_point[1]
                pose.pose.position.z = vehicle_location.z  # Keep same height as vehicle
                
                # Calculate orientation tangent to the path
                if len(path_msg.poses) > 0:
                    # Get direction to next point
                    dx = world_point[0]
                    dy = world_point[1]
                    heading = np.arctan2(dy, dx)  # Use world frame heading directly
                    
                    # Convert to quaternion
                    qw = np.cos(heading / 2)
                    qz = np.sin(heading / 2)
                    pose.pose.orientation.w = qw
                    pose.pose.orientation.z = qz
                    pose.pose.orientation.x = 0.0
                    pose.pose.orientation.y = 0.0
                else:
                    # First point uses vehicle's orientation
                    pose.pose.orientation.w = 1.0
                    pose.pose.orientation.x = 0.0
                    pose.pose.orientation.y = 0.0
                    pose.pose.orientation.z = 0.0
                
                path_msg.poses.append(pose)
            
            # Publish the path
            self.path_vis_pub.publish(path_msg)
            
        except Exception as e:
            self.get_logger().error(f"Error publishing path for RViz: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())

    def set_car_controls(self, steering, speed):
        """
        Set the car's steering and speed with improved braking for obstacles.
        
        Args:
            steering: Steering angle in range [-1, 1]
            speed: Target speed in m/s (positive for forward, negative for reverse)
        """
        if self.vehicle is None:
            self.get_logger().error("Cannot set controls: No vehicle available")
            return
        
        try:
            import carla
            
            # Get current speed for better control
            velocity = self.vehicle.get_velocity()
            current_speed = np.sqrt(velocity.x**2 + velocity.y**2 + velocity.z**2)
            
            # Create control command
            control = carla.VehicleControl()
            
            # Set steering (-1 to 1)
            control.steer = float(steering)
            
            # Determine if we need to accelerate, maintain speed, or brake
            if speed > 0:  # Forward motion
                # Check if we need emergency braking (going much faster than target)
                if speed < 0.5 and current_speed > 2.0:  # Hard stop requested while moving fast
                    # Emergency braking
                    control.throttle = 0.0
                    control.brake = 0.8  # Strong braking
                    control.reverse = False
                    self.get_logger().error(f"EMERGENCY BRAKING: Current speed {current_speed:.2f} with target {speed:.2f}")
                # Check if we need to slow down
                elif current_speed > speed + 0.5:  # If going more than 0.5 m/s too fast
                    # Apply brakes - stronger braking for higher overspeeds
                    speed_diff = current_speed - speed
                    brake_force = min(0.7, max(0.2, speed_diff * 0.3))  # Scale brake force with speed difference
                    
                    control.throttle = 0.0
                    control.brake = brake_force
                    control.reverse = False
                    
                    self.get_logger().warn(f"BRAKING: Current {current_speed:.2f} > target {speed:.2f}, brake={brake_force:.2f}")
                else:
                    # Normal forward throttle - proportional to desired speed
                    min_throttle = 0.4   # Increased from 0.3 to 0.4 - higher minimum throttle to ensure movement
                    max_throttle = 1.0   # Increased from 0.9 to 1.0 - maximum throttle for better acceleration
                    
                    # Progressive throttle control
                    if current_speed < speed - 0.5:  # Need substantial acceleration
                        # Stronger throttle when far from target speed
                        speed_diff = min(5.0, speed - current_speed)  # Cap to avoid excessive values
                        throttle = min(max_throttle, min_throttle + speed_diff * 0.2)  # Increased multiplier from 0.15 to 0.2
                    elif current_speed < speed - 0.1:  # Need minor acceleration
                        throttle = min_throttle + 0.15  # Increased from 0.1 to 0.15 - slight boost
                    else:  # At or near target speed
                        throttle = min_throttle
                    
                    control.throttle = throttle
                    control.brake = 0.0
                    control.reverse = False
                    
                    self.get_logger().info(f"Throttle: {control.throttle:.2f} for speed={speed:.2f}m/s (current: {current_speed:.2f})")
            else:  # Zero or negative speed - stop
                control.throttle = 0.0
                # Apply brakes harder if moving faster
                control.brake = min(0.9, max(0.4, current_speed * 0.2))  # Scale with current speed
                control.reverse = False
                
                self.get_logger().warn(f"Stopping vehicle with brake={control.brake:.2f}")
            
            # Apply control to vehicle
            self.vehicle.apply_control(control)
            
            # FORCE PHYSICS UPDATE FOR IMMEDIATE MOVEMENT
            self.world.tick()
            
            # Log that control was applied
            self.get_logger().info(f"Applied control: throttle={control.throttle:.2f}, " 
                                f"brake={control.brake:.2f}, " 
                                f"steer={control.steer:.2f}, " 
                                f"reverse={control.reverse}")
        except Exception as e:
            self.get_logger().error(f"Error setting car controls: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())

    def control_car(self):
        """Control the car using pure pursuit steering and adaptive speed with improved cone avoidance."""
        if not hasattr(self, 'path_planner') or self.path_planner is None:
            # Fail-safe: if no path planner, move forward with small steering
            self.get_logger().warn("No path planner available! Using fail-safe control!")
            self.set_car_controls(0.0, 3.0)  # Move forward with no steering at higher speed
            return
        
        try:
            # Get current speed
            current_speed = 0.0
            if hasattr(self, 'vehicle') and self.vehicle:
                velocity = self.vehicle.get_velocity()
                current_speed = np.sqrt(velocity.x**2 + velocity.y**2 + velocity.z**2)
                
            # HIGHER SPEED LIMIT - Increased from 8.0 to 12.0 m/s (about 27 mph)
            if current_speed > 12.0:
                # Apply brakes to slow down
                import carla
                self.get_logger().warn(f"OVER SPEED LIMIT! Current: {current_speed:.2f} m/s - applying brakes")
                
                # Create control command with braking
                control = carla.VehicleControl()
                control.throttle = 0.0
                control.brake = 0.4  # Strong braking
                control.steer = self.prev_steering if hasattr(self, 'prev_steering') else 0.0
                control.reverse = False
                
                # Apply control
                self.vehicle.apply_control(control)
                # Force physics update
                self.world.tick()
                
                return
                
            # Check if we have a valid path
            if not self.path_planner.path or len(self.path_planner.path) < 2:
                # No valid path - move forward with minimal steering
                self.get_logger().warn("No valid path! Moving forward...")
                self.set_car_controls(0.0, 3.0)  # Increased from 1.5 to 3.0
                return
                
            # Get steering angle from pure pursuit planner
            lookahead = max(3.0, min(7.0, current_speed * 0.8))  # Increased adaptive lookahead for stability at higher speeds
            steering = self.path_planner.calculate_steering(lookahead_distance=lookahead)
            
            # Limit steering angle based on speed to prevent tipping 
            max_steering = 1.0
            if current_speed > 5.0:  # Adjusted threshold
                max_steering = 0.8
            elif current_speed > 8.0:  # Adjusted threshold
                max_steering = 0.6
                
            steering = np.clip(steering, -max_steering, max_steering)
            
            # FASTER SPEED CONTROL - Increased all speeds
            base_speed = 6.0   # Increased from 3.0 to 6.0 m/s (about 13.4 mph)
            turn_speed = 3.5   # Increased from 1.5 to 3.5 m/s (about 7.8 mph)
            sharp_turn_speed = 2.0  # Increased from 0.8 to 2.0 m/s (about 4.5 mph)
            
            # Default to base speed
            target_speed = base_speed
            
            # IMPROVED TURN HANDLING: Determine target speed based on steering magnitude
            steering_magnitude = abs(steering)
            if steering_magnitude > 0.7:  # Very sharp turn
                target_speed = sharp_turn_speed
                self.get_logger().warn(f"SHARP TURN detected! Slowing to {target_speed:.2f}m/s")
            elif steering_magnitude > 0.3:  # Moderate turn
                target_speed = turn_speed
                self.get_logger().warn(f"Turn detected! Slowing to {target_speed:.2f}m/s")
            
            # ENHANCED CONE AVOIDANCE - detect cones earlier and slow down more aggressively
            cone_in_path = False
            closest_cone_dist = float('inf')
            
            if hasattr(self.zed_camera, 'cone_detections'):
                for cone in self.zed_camera.cone_detections:
                    if 'depth' not in cone:
                        continue
                        
                    depth = cone['depth']
                    # Keep track of closest cone regardless of whether it's in path
                    if depth < closest_cone_dist:
                        closest_cone_dist = depth
                    
                    # Check if cone is in path - wider detection corridor for earlier avoidance
                    if 'box' in cone:
                        x1, y1, x2, y2 = cone['box']
                        center_x = (x1 + x2) // 2
                        image_center_x = self.zed_camera.resolution[0] // 2
                        
                        # WIDER detection corridor based on distance - more conservative
                        center_threshold = 350 - (200 * min(1.0, depth / 15.0))
                        
                        # Check if cone is in path
                        if abs(center_x - image_center_x) < center_threshold:
                            cone_in_path = True
                            self.get_logger().warn(f"Cone detected in path at {depth:.2f}m (offset: {abs(center_x - image_center_x)}px)")
                
                # IMPROVED CONE AVOIDANCE BEHAVIOR
                if cone_in_path:
                    # Calculate safe speed based on distance to cone
                    # Start slowing down earlier (10m instead of 5m)
                    if closest_cone_dist < 10.0:
                        # More aggressive slowdown curve with distance
                        # At 10m -> 75% of base speed
                        # At 5m -> 40% of base speed 
                        # At 3m -> 25% of base speed
                        # At 1m -> 10% of base speed
                        cone_factor = min(1.0, max(0.1, closest_cone_dist / 10.0))
                        
                        # Exponential slowdown (more aggressive than linear)
                        cone_speed = base_speed * (cone_factor * cone_factor)
                        
                        if cone_speed < target_speed:
                            target_speed = cone_speed
                            self.get_logger().warn(f"CONE AVOIDANCE: Slowing to {target_speed:.2f}m/s at {closest_cone_dist:.2f}m distance")
                
                # Additional safety: emergency stop if very close to any cone (regardless of path)
                if closest_cone_dist < 1.0:
                    target_speed = 0.0  # Stop completely
                    self.get_logger().error(f"EMERGENCY STOP! Cone extremely close: {closest_cone_dist:.2f}m")
            
            # Apply gradual acceleration/deceleration
            if hasattr(self, 'prev_target_speed'):
                # More responsive speed adaptation
                max_accel = 0.4  # Increased from 0.2 to 0.4 m/s² - faster acceleration
                max_decel = 0.7  # Increased from 0.5 to 0.7 m/s² - stronger deceleration for better safety
                
                if target_speed > self.prev_target_speed:
                    # Accelerating
                    target_speed = min(target_speed, self.prev_target_speed + max_accel)
                else:
                    # Decelerating - respond quickly to obstacles and turns
                    target_speed = max(target_speed, self.prev_target_speed - max_decel)
            
            # Update for next iteration
            self.prev_target_speed = target_speed
            self.prev_steering = steering
            
            # Apply control to vehicle
            self.set_car_controls(steering, target_speed)
            
            # Log control decision
            self.get_logger().info(f"Pure pursuit control: steering={steering:.2f}, speed={target_speed:.2f}m/s")
            
        except Exception as e:
            self.get_logger().error(f"Error in car control: {str(e)}")
            # Safety fallback
            self.set_car_controls(0.0, 2.0)  # Increased from 1.0 to 2.0 m/s (about 4.5 mph)
            import traceback

    def update_and_publish_metrics(self, control_latency, current_speed, target_speed):
        """Update and publish performance metrics for RViz visualization."""
        try:
            # Initialize metrics if needed
            if not hasattr(self, 'control_metrics'):
                self.control_metrics = {
                    'latency': [],
                    'fps_counter': 0,
                    'fps_timer': time.time(),
                    'fps': 0,
                    'speeds': []
                }
            
            # Update metrics
            self.control_metrics['latency'].append(control_latency)
            if len(self.control_metrics['latency']) > 30:
                self.control_metrics['latency'] = self.control_metrics['latency'][-30:]
            
            self.control_metrics['speeds'].append(current_speed)
            if len(self.control_metrics['speeds']) > 100:
                self.control_metrics['speeds'] = self.control_metrics['speeds'][-100:]
            
            # Update FPS calculation
            self.control_metrics['fps_counter'] += 1
            current_time = time.time()
            if current_time - self.control_metrics['fps_timer'] >= 1.0:
                self.control_metrics['fps'] = self.control_metrics['fps_counter'] / (current_time - self.control_metrics['fps_timer'])
                self.control_metrics['fps_counter'] = 0
                self.control_metrics['fps_timer'] = current_time
            
            # Create visualization markers for RViz
            marker_array = MarkerArray()
            
            # Get current vehicle position
            if hasattr(self, 'vehicle') and self.vehicle:
                vehicle_loc = self.vehicle.get_location()
                base_x = vehicle_loc.x
                base_y = vehicle_loc.y
                base_z = vehicle_loc.z + 2.5  # Above vehicle
            else:
                base_x = 0.0
                base_y = 0.0
                base_z = 2.5
            
            # Create text display for metrics
            metrics_marker = Marker()
            metrics_marker.header.frame_id = "map"
            metrics_marker.header.stamp = self.get_clock().now().to_msg()
            metrics_marker.ns = "performance_metrics"
            metrics_marker.id = 0
            metrics_marker.type = Marker.TEXT_VIEW_FACING
            metrics_marker.action = Marker.ADD
            metrics_marker.pose.position.x = base_x
            metrics_marker.pose.position.y = base_y
            metrics_marker.pose.position.z = base_z
            metrics_marker.pose.orientation.w = 1.0
            metrics_marker.scale.z = 0.5  # Text size
            
            # Color based on performance (green = good, red = bad)
            avg_latency = sum(self.control_metrics['latency']) / len(self.control_metrics['latency']) if self.control_metrics['latency'] else 0
            if avg_latency < 100:
                metrics_marker.color.r = 0.0
                metrics_marker.color.g = 1.0
                metrics_marker.color.b = 0.0
            else:
                metrics_marker.color.r = 1.0
                metrics_marker.color.g = 0.0
                metrics_marker.color.b = 0.0
            metrics_marker.color.a = 1.0
            
            # Create formatted text
            mph = current_speed * 2.237  # Convert m/s to mph
            target_mph = target_speed * 2.237
            
            metrics_marker.text = (
                f"FPS: {self.control_metrics['fps']:.1f}\n" +
                f"Latency: {avg_latency:.1f}ms\n" +
                f"Speed: {current_speed:.1f}m/s ({mph:.1f}mph)\n" +
                f"Target: {target_speed:.1f}m/s ({target_mph:.1f}mph)"
            )
            
            marker_array.markers.append(metrics_marker)
            
            # Create and publish performance metrics
            if not hasattr(self, 'metrics_pub'):
                self.metrics_pub = self.create_publisher(MarkerArray, '/carla/performance_metrics', 10)
            
            self.metrics_pub.publish(marker_array)
            
        except Exception as e:
            self.get_logger().error(f"Error publishing metrics: {str(e)}")

    def visualize_detected_cones(self):
        """Visualize detected cones in RViz."""
        try:
            # Check if we have cone detections
            cones_to_visualize = []
            
            # Get cones from camera
            if hasattr(self, 'zed_camera') and self.zed_camera and hasattr(self.zed_camera, 'cone_detections'):
                cam_cones = self.zed_camera.cone_detections
                for cone in cam_cones:
                    if 'depth' in cone and 'box' in cone:
                        depth = cone['depth']
                        
                        if depth < closest_cone_dist:
                            closest_cone_dist = depth
                        
                        # Check if cone is in path with wider threshold
                        x1, y1, x2, y2 = cone['box']
                        center_x = (x1 + x2) // 2
                        image_center_x = self.zed_camera.resolution[0] // 2
                        
                        # Even wider detection corridor
                        center_threshold = 550 - (450 * min(1.0, depth / 15.0))
                        
                        if abs(center_x - image_center_x) < center_threshold:
                            cone_in_path = True
                            self.get_logger().warn(f"CONE IN PATH at {depth:.2f}m! Center offset: {abs(center_x - image_center_x)}px")
            
            # Rest of your existing visualization logic here...
            
        except Exception as e:
            self.get_logger().error(f"Error visualizing cones: {str(e)}")

    def visualize_pcd_data(self):
        """Visualize current PCD data in RViz."""
        try:
            if not hasattr(self, 'latest_lidar_points') or self.latest_lidar_points is None:
                return
            
            # Create PointCloud2 message
            header = Header()
            header.stamp = self.get_clock().now().to_msg()
            header.frame_id = "map"
            
            # Create fields for the point cloud
            fields = [
                pc2.PointField(name='x', offset=0, datatype=pc2.PointField.FLOAT32, count=1),
                pc2.PointField(name='y', offset=4, datatype=pc2.PointField.FLOAT32, count=1),
                pc2.PointField(name='z', offset=8, datatype=pc2.PointField.FLOAT32, count=1),
                pc2.PointField(name='intensity', offset=12, datatype=pc2.PointField.FLOAT32, count=1)
            ]
            
            # Color points based on height
            points = self.latest_lidar_points
            min_z = np.min(points[:, 2])
            max_z = np.max(points[:, 2])
            z_range = max_z - min_z if max_z > min_z else 1.0
            
            # Create structured array for colored points
            structured_points = np.zeros(len(points), 
                                        dtype=[
                                            ('x', np.float32),
                                            ('y', np.float32),
                                            ('z', np.float32),
                                            ('intensity', np.float32)
                                        ])
            
            # Fill structured array
            structured_points['x'] = points[:, 0]
            structured_points['y'] = points[:, 1]
            structured_points['z'] = points[:, 2]
            
            # Color points based on height (z value)
            intensity = (points[:, 2] - min_z) / z_range
            structured_points['intensity'] = intensity
            
            # Create and publish the point cloud
            pc_msg = pc2.create_cloud(header, fields, structured_points)
            
            if not hasattr(self, 'pcd_pub'):
                self.pcd_pub = self.create_publisher(PointCloud2, '/carla/pcd_visualization', 10)
            
            self.pcd_pub.publish(pc_msg)
            
        except Exception as e:
            self.get_logger().error(f"Error visualizing PCD data: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())

    def update_pcd_file_list(self):
        """Update the list of available PCD files."""
        try:
            if not hasattr(self, 'output_dir') or not os.path.exists(self.output_dir):
                return
                
            # Get list of PCD files
            pcd_files = [f for f in os.listdir(self.output_dir) if f.endswith('.pcd')]
            pcd_files.sort()  # Sort by name
            
            # Store the list
            self.pcd_files = pcd_files
            
            # Log the number of files found
            if not hasattr(self, 'last_pcd_log_time') or time.time() - self.last_pcd_log_time > 5.0:
                self.get_logger().info(f"Found {len(pcd_files)} PCD files in {self.output_dir}")
                self.last_pcd_log_time = time.time()
                
        except Exception as e:
            self.get_logger().error(f"Error updating PCD file list: {str(e)}")

    def handle_keyboard_input(self):
        """Handle keyboard input for controlling visualization and playback."""
        try:
            # Check if any key is pressed
            key = cv2.waitKey(1) & 0xFF
            
            if key == ord('q'):
                # Quit the program
                self.get_logger().info("Quitting...")
                rclpy.shutdown()
                return
                
            elif key == ord('p'):
                # Toggle PCD visualization
                if not hasattr(self, 'show_pcd'):
                    self.show_pcd = True
                else:
                    self.show_pcd = not self.show_pcd
                self.get_logger().info(f"PCD visualization: {'enabled' if self.show_pcd else 'disabled'}")
                
            elif key == ord('c'):
                # Toggle cone visualization
                if not hasattr(self, 'show_cones'):
                    self.show_cones = True
                else:
                    self.show_cones = not self.show_cones
                self.get_logger().info(f"Cone visualization: {'enabled' if self.show_cones else 'disabled'}")
                
            elif key == ord('n'):
                # Next PCD file
                if hasattr(self, 'pcd_files') and len(self.pcd_files) > 0:
                    if not hasattr(self, 'current_pcd_index'):
                        self.current_pcd_index = 0
                    else:
                        self.current_pcd_index = (self.current_pcd_index + 1) % len(self.pcd_files)
                    self.get_logger().info(f"Loading PCD file: {self.pcd_files[self.current_pcd_index]}")
                    
            elif key == ord('b'):
                # Previous PCD file
                if hasattr(self, 'pcd_files') and len(self.pcd_files) > 0:
                    if not hasattr(self, 'current_pcd_index'):
                        self.current_pcd_index = 0
                    else:
                        self.current_pcd_index = (self.current_pcd_index - 1) % len(self.pcd_files)
                    self.get_logger().info(f"Loading PCD file: {self.pcd_files[self.current_pcd_index]}")
                    
        except Exception as e:
            self.get_logger().error(f"Error handling keyboard input: {str(e)}")

    def _pair_cones(self, camera_cones, lidar_cones):
        """
        Pair detected cones from camera and LiDAR data using enhanced association logic.
        
        Args:
            camera_cones: List of cones detected by camera
            lidar_cones: List of cones detected by LiDAR
            
        Returns:
            List of paired cones with fused position and confidence
        """
        try:
            paired_cones = []
            unpaired_camera = camera_cones.copy()
            unpaired_lidar = lidar_cones.copy()
            
            # Parameters for association
            max_distance = 2.0  # Maximum distance for pairing (meters)
            min_confidence = 0.3  # Minimum confidence threshold
            
            # Sort cones by confidence for better matching
            unpaired_camera.sort(key=lambda x: x.get('confidence', 0.0), reverse=True)
            unpaired_lidar.sort(key=lambda x: x.get('confidence', 0.0), reverse=True)
            
            # Create distance matrix between all pairs
            if unpaired_camera and unpaired_lidar:
                distances = np.zeros((len(unpaired_camera), len(unpaired_lidar)))
                for i, cam_cone in enumerate(unpaired_camera):
                    for j, lidar_cone in enumerate(unpaired_lidar):
                        # Calculate 3D distance between cones
                        cam_pos = np.array(cam_cone['position'])
                        lidar_pos = np.array(lidar_cone['position'])
                        distances[i, j] = np.linalg.norm(cam_pos - lidar_pos)
                
                # Iteratively find best matches
                while distances.size > 0 and np.min(distances) < max_distance:
                    i, j = np.unravel_index(np.argmin(distances), distances.shape)
                    
                    cam_cone = unpaired_camera[i]
                    lidar_cone = unpaired_lidar[j]
                    
                    # Calculate weighted position based on confidence
                    cam_conf = cam_cone.get('confidence', 0.5)
                    lidar_conf = lidar_cone.get('confidence', 0.5)
                    
                    total_conf = cam_conf + lidar_conf
                    if total_conf > min_confidence:
                        # Weighted average of positions
                        fused_position = (
                            np.array(cam_cone['position']) * cam_conf +
                            np.array(lidar_cone['position']) * lidar_conf
                        ) / total_conf
                        
                        # Combine class information
                        fused_class = cam_cone.get('cls', lidar_cone.get('cls', 0))
                        
                        # Calculate fused confidence
                        fused_confidence = min(1.0, (cam_conf + lidar_conf) / 1.5)
                        
                        # Create fused cone
                        paired_cones.append({
                            'position': fused_position.tolist(),
                            'confidence': fused_confidence,
                            'cls': fused_class,
                            'sources': ['camera', 'lidar'],
                            'camera_conf': cam_conf,
                            'lidar_conf': lidar_conf
                        })
                    
                    # Remove paired cones from unpaired lists
                    unpaired_camera.pop(i)
                    unpaired_lidar.pop(j)
                    
                    # Update distance matrix
                    distances = np.delete(distances, i, axis=0)
                    distances = np.delete(distances, j, axis=1)
            
            # Handle remaining unpaired cones
            for cone in unpaired_camera:
                if cone.get('confidence', 0.0) > min_confidence:
                    cone['sources'] = ['camera']
                    paired_cones.append(cone)
            
            for cone in unpaired_lidar:
                if cone.get('confidence', 0.0) > min_confidence:
                    cone['sources'] = ['lidar']
                    paired_cones.append(cone)
            
            # Sort final cones by distance from vehicle
            paired_cones.sort(key=lambda x: np.linalg.norm(np.array(x['position'])[:2]))
            
            # Log pairing results
            self.get_logger().info(f"Paired {len(paired_cones)} cones: "
                                f"{len(paired_cones) - len(unpaired_camera) - len(unpaired_lidar)} fused, "
                                f"{len(unpaired_camera)} camera-only, "
                                f"{len(unpaired_lidar)} lidar-only")
            
            return paired_cones
            
        except Exception as e:
            self.get_logger().error(f"Error in cone pairing: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
            return []

    def _smooth_path(self, path_points, smoothing_factor=0.8):
        """
        Smooth the path using enhanced Bezier curves and adaptive smoothing.
        
        Args:
            path_points: List of (x, y) path points
            smoothing_factor: Factor controlling smoothness (0-1)
            
        Returns:
            Smoothed path points
        """
        try:
            if len(path_points) < 3:
                return path_points
                
            # Convert to numpy array for easier manipulation
            points = np.array(path_points)
            
            # Detect sharp turns and U-turns for adaptive smoothing
            angles = []
            for i in range(1, len(points) - 1):
                v1 = points[i] - points[i-1]
                v2 = points[i+1] - points[i]
                angle = np.arctan2(np.cross(v1, v2), np.dot(v1, v2))
                angles.append(abs(angle))
            
            # Identify turn regions
            turn_regions = []
            current_turn = []
            in_turn = False
            turn_threshold = np.pi / 6  # 30 degrees
            
            for i, angle in enumerate(angles):
                if angle > turn_threshold and not in_turn:
                    in_turn = True
                    current_turn = [i]
                elif angle <= turn_threshold and in_turn:
                    in_turn = False
                    current_turn.append(i + 1)
                    turn_regions.append(current_turn)
                elif in_turn:
                    current_turn.append(i + 1)
            
            if in_turn:
                current_turn.append(len(angles))
                turn_regions.append(current_turn)
            
            # Apply adaptive smoothing
            smoothed_points = points.copy()
            window_size = 5
            
            for i in range(window_size, len(points) - window_size):
                # Check if point is in turn region
                in_turn_region = False
                for region in turn_regions:
                    if region[0] <= i <= region[-1]:
                        in_turn_region = True
                        break
                
                # Adjust smoothing based on region
                local_smoothing = smoothing_factor
                if in_turn_region:
                    # Reduce smoothing in turns for better accuracy
                    local_smoothing *= 0.7
                    
                    # Add more points in sharp turns
                    if i > 0 and i < len(points) - 1:
                        v1 = points[i] - points[i-1]
                        v2 = points[i+1] - points[i]
                        angle = abs(np.arctan2(np.cross(v1, v2), np.dot(v1, v2)))
                        
                        if angle > np.pi / 3:  # 60 degrees
                            # Insert intermediate points
                            num_points = 3
                            for j in range(1, num_points):
                                t = j / num_points
                                # Bezier interpolation
                                p0 = points[i-1]
                                p1 = points[i]
                                p2 = points[i+1]
                                new_point = (1-t)**2 * p0 + 2*(1-t)*t * p1 + t**2 * p2
                                smoothed_points = np.insert(smoothed_points, i+j, new_point, axis=0)
                
                # Apply smoothing with adaptive window
                window = points[max(0, i-window_size):min(len(points), i+window_size+1)]
                weights = np.exp(-0.5 * np.arange(-window_size, window_size+1)**2 / window_size)
                weights = weights[:len(window)]
                weights /= np.sum(weights)
                
                smoothed_points[i] = np.sum(window * weights[:, np.newaxis], axis=0)
            
            # Preserve endpoints
            smoothed_points[0] = points[0]
            smoothed_points[-1] = points[-1]
            
            # Apply curvature-based refinement
            refined_points = []
            for i in range(len(smoothed_points) - 1):
                refined_points.append(smoothed_points[i])
                
                # Add intermediate points in high-curvature regions
                if i > 0 and i < len(smoothed_points) - 1:
                    v1 = smoothed_points[i] - smoothed_points[i-1]
                    v2 = smoothed_points[i+1] - smoothed_points[i]
                    angle = abs(np.arctan2(np.cross(v1, v2), np.dot(v1, v2)))
                    
                    if angle > np.pi / 4:  # 45 degrees
                        # Add intermediate point using Bezier curve
                        t = 0.5
                        p0 = smoothed_points[i-1]
                        p1 = smoothed_points[i]
                        p2 = smoothed_points[i+1]
                        intermediate = (1-t)**2 * p0 + 2*(1-t)*t * p1 + t**2 * p2
                        refined_points.append(intermediate)
            
            refined_points.append(smoothed_points[-1])
            
            # Final smoothing pass for consistency
            final_points = np.array(refined_points)
            for i in range(1, len(final_points) - 1):
                final_points[i] = (final_points[i-1] + final_points[i] * 2 + final_points[i+1]) / 4
            
            # Log smoothing results
            self.get_logger().info(f"Smoothed path: {len(path_points)} points -> {len(final_points)} points "
                                f"with {len(turn_regions)} turn regions")
            
            return final_points.tolist()
            
        except Exception as e:
            self.get_logger().error(f"Error smoothing path: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
            return path_points

    def calculate_steering(self, path_points, current_speed):
        """
        Calculate steering angle with enhanced control for turns and U-turns.
        
        Args:
            path_points: List of (x, y) path points
            current_speed: Current vehicle speed in m/s
            
        Returns:
            Steering angle in range [-1, 1]
        """
        try:
            if not path_points or len(path_points) < 2:
                return 0.0
                
            # Get vehicle state
            if not hasattr(self, 'vehicle') or not self.vehicle:
                return 0.0
                
            vehicle_transform = self.vehicle.get_transform()
            vehicle_location = vehicle_transform.location
            vehicle_rotation = vehicle_transform.rotation
            
            # Convert vehicle rotation to radians
            yaw = np.radians(vehicle_rotation.yaw)
            
            # Create rotation matrix
            cos_yaw = np.cos(yaw)
            sin_yaw = np.sin(yaw)
            rotation_matrix = np.array([
                [cos_yaw, -sin_yaw],
                [sin_yaw, cos_yaw]
            ])
            
            # Transform path points to vehicle's local frame
            local_points = []
            for point in path_points:
                # Convert to vehicle's local frame
                dx = point[0] - vehicle_location.x
                dy = point[1] - vehicle_location.y
                local_point = np.linalg.inv(rotation_matrix) @ np.array([dx, dy])
                local_points.append(local_point)
            
            # Find closest point and look-ahead point
            closest_idx = 0
            min_dist = float('inf')
            for i, point in enumerate(local_points):
                dist = np.hypot(point[0], point[1])
                if dist < min_dist:
                    min_dist = dist
                    closest_idx = i
            
            # Dynamic look-ahead distance based on speed and curvature
            base_lookahead = max(2.0, min(5.0, current_speed * 1.0))
            
            # Calculate path curvature at closest point
            if closest_idx > 0 and closest_idx < len(local_points) - 1:
                prev_point = local_points[closest_idx - 1]
                curr_point = local_points[closest_idx]
                next_point = local_points[closest_idx + 1]
                
                # Calculate angles
                v1 = curr_point - prev_point
                v2 = next_point - curr_point
                angle = abs(np.arctan2(np.cross(v1, v2), np.dot(v1, v2)))
                
                # Adjust look-ahead based on curvature
                curvature_factor = 1.0 - min(1.0, angle / np.pi)
                base_lookahead *= curvature_factor
            
            # Find look-ahead point
            lookahead_idx = closest_idx
            accumulated_dist = 0.0
            
            for i in range(closest_idx, len(local_points) - 1):
                point_dist = np.hypot(local_points[i+1][0] - local_points[i][0],
                                    local_points[i+1][1] - local_points[i][1])
                accumulated_dist += point_dist
                
                if accumulated_dist >= base_lookahead:
                    lookahead_idx = i + 1
                    break
            
            # Get look-ahead point
            target_point = local_points[lookahead_idx]
            
            # Calculate steering angle using pure pursuit
            target_dist = np.hypot(target_point[0], target_point[1])
            if target_dist < 0.1:  # Avoid division by zero
                return 0.0
                
            # Calculate steering angle
            chord_length = target_dist
            steering_angle = 2.0 * target_point[0] / (chord_length * chord_length)
            
            # Check for U-turn condition
            if hasattr(self, 'uturn_state') and self.uturn_state.get('detected', False):
                uturn_distance = self.uturn_state.get('distance', float('inf'))
                uturn_direction = self.uturn_state.get('direction', 'right')
                
                if uturn_distance < 10.0:  # Close to U-turn point
                    # Amplify steering for U-turn
                    steering_factor = 1.5 * (1.0 - uturn_distance / 10.0)
                    if uturn_direction == 'left':
                        steering_angle = min(-0.7, steering_angle * (1.0 + steering_factor))
                    else:  # right
                        steering_angle = max(0.7, steering_angle * (1.0 + steering_factor))
            
            # Apply speed-based steering limits
            max_steering = 1.0
            if current_speed > 5.0:  # Reduce max steering at higher speeds
                max_steering = max(0.3, 1.0 - (current_speed - 5.0) * 0.1)
            
            # Smooth steering changes
            if hasattr(self, 'prev_steering'):
                max_change = 0.1 * (1.0 + current_speed * 0.05)  # More aggressive at higher speeds
                steering_angle = np.clip(steering_angle,
                                       self.prev_steering - max_change,
                                       self.prev_steering + max_change)
            
            # Store for next iteration
            self.prev_steering = steering_angle
            
            # Final steering limits
            steering_angle = np.clip(steering_angle, -max_steering, max_steering)
            
            # Log steering calculation
            self.get_logger().debug(f"Steering: angle={steering_angle:.2f}, "
                                 f"lookahead={base_lookahead:.1f}m, "
                                 f"target=({target_point[0]:.1f}, {target_point[1]:.1f})")
            
            return float(steering_angle)
            
        except Exception as e:
            self.get_logger().error(f"Error calculating steering: {str(e)}")
            import traceback
            self.get_logger().error(traceback.format_exc())
            return 0.0

    def visualize_cone_map(self):
        """
        Visualize the cone map in RViz.
        
        This method creates markers for all the cones in the map and publishes them to RViz.
        """
        try:
            from visualization_msgs.msg import MarkerArray, Marker
            from std_msgs.msg import ColorRGBA
            from geometry_msgs.msg import Point
            
            # Create marker array for cones
            marker_array = MarkerArray()
            
            # Group cones by class
            cones_by_class = {}
            for i, cone in enumerate(self.cone_map):
                x, y, conf, cls = cone
                cls = int(cls)
                if cls not in cones_by_class:
                    cones_by_class[cls] = []
                cones_by_class[cls].append((x, y, conf, i))
            
            # Add markers for each class
            marker_id = 0
            
            # Class colors: yellow, blue, white (unknown)
            class_colors = {
                0: ColorRGBA(r=1.0, g=1.0, b=0.0, a=1.0),  # Yellow
                1: ColorRGBA(r=0.0, g=0.0, b=1.0, a=1.0),  # Blue
                2: ColorRGBA(r=1.0, g=1.0, b=1.0, a=1.0)   # White (unknown)
            }
            
            for cls, cones in cones_by_class.items():
                # Create a marker for this class
                marker = Marker()
                marker.header.frame_id = "map"
                marker.header.stamp = self.get_clock().now().to_msg()
                marker.ns = f"cones_class_{cls}"
                marker.id = cls
                marker.type = Marker.SPHERE_LIST
                marker.action = Marker.ADD
                
                # Set marker properties
                marker.pose.orientation.w = 1.0
                marker.scale.x = 0.5  # Cone diameter
                marker.scale.y = 0.5
                marker.scale.z = 0.5
                
                # Set color based on class
                marker.color = class_colors.get(cls, ColorRGBA(r=1.0, g=1.0, b=1.0, a=1.0))
                
                # Add points for each cone
                for x, y, conf, _ in cones:
                    point = Point()
                    point.x = x
                    point.y = y
                    point.z = 0.25  # Slightly above ground
                    marker.points.append(point)
                    
                    # Make color opacity depend on confidence
                    color = ColorRGBA()
                    color.r = marker.color.r
                    color.g = marker.color.g
                    color.b = marker.color.b
                    color.a = min(1.0, 0.5 + conf * 0.5)  # Scale opacity with confidence
                    marker.colors.append(color)
                
                # Add marker to array
                marker_array.markers.append(marker)
                marker_id += 1
            
            # Create a marker for the vehicle trajectory
            if self.vehicle_poses:
                trajectory_marker = Marker()
                trajectory_marker.header.frame_id = "map"
                trajectory_marker.header.stamp = self.get_clock().now().to_msg()
                trajectory_marker.ns = "vehicle_trajectory"
                trajectory_marker.id = marker_id
                trajectory_marker.type = Marker.LINE_STRIP
                trajectory_marker.action = Marker.ADD
                
                # Set marker properties
                trajectory_marker.pose.orientation.w = 1.0
                trajectory_marker.scale.x = 0.1  # Line width
                trajectory_marker.color.r = 0.0
                trajectory_marker.color.g = 1.0
                trajectory_marker.color.b = 0.0
                trajectory_marker.color.a = 0.7
                
                # Add points for each pose
                for x, y, _ in self.vehicle_poses:
                    point = Point()
                    point.x = x
                    point.y = y
                    point.z = 0.1  # Slightly above ground
                    trajectory_marker.points.append(point)
                
                # Add marker to array
                marker_array.markers.append(trajectory_marker)
                marker_id += 1
                
                # Add current vehicle position marker
                current_pos_marker = Marker()
                current_pos_marker.header.frame_id = "map"
                current_pos_marker.header.stamp = self.get_clock().now().to_msg()
                current_pos_marker.ns = "vehicle_current_position"
                current_pos_marker.id = marker_id
                current_pos_marker.type = Marker.CUBE  # Using a cube to represent the vehicle
                current_pos_marker.action = Marker.ADD
                
                # Set marker properties
                current_pos_marker.pose.orientation.w = 1.0
                current_pos_marker.scale.x = 0.8  # Vehicle width
                current_pos_marker.scale.y = 1.6  # Vehicle length
                current_pos_marker.scale.z = 0.4  # Vehicle height
                
                # Set position to the latest vehicle pose
                latest_x, latest_y, _ = self.vehicle_poses[-1]
                current_pos_marker.pose.position = Point(x=latest_x, y=latest_y, z=0.2)  # Slightly above ground
                
                # Set color (e.g., red for visibility)
                current_pos_marker.color = ColorRGBA(r=1.0, g=0.0, b=0.0, a=1.0)
                
                # Add marker to array
                marker_array.markers.append(current_pos_marker)
            
            # Publish the marker array
            if not hasattr(self, 'cone_map_pub'):
                self.cone_map_pub = self.create_publisher(MarkerArray, '/cone_map', 10)
            self.cone_map_pub.publish(marker_array)
            
        except Exception as e:
            self.get_logger().error(f"Error visualizing cone map: {str(e)}")

    def publish_cone_map(self, cone_mapper):
        """Publish the global cone map as a MarkerArray for RViz."""
        marker_array = MarkerArray()
        cones_by_class = cone_mapper.get_cones_by_class()
        
        for cls, cones in cones_by_class.items():
            for i, (x, y) in enumerate(cones):
                marker = Marker()
                marker.header.frame_id = "map"
                marker.header.stamp = self.get_clock().now().to_msg()
                marker.ns = f"cone_{cls}"
                marker.id = i
                marker.type = Marker.CYLINDER
                marker.action = Marker.ADD
                marker.pose.position.x = x
                marker.pose.position.y = y
                marker.pose.position.z = 0.25  # Half cone height
                marker.scale.x = 0.3  # Cone diameter
                marker.scale.y = 0.3
                marker.scale.z = 0.5  # Cone height
                # Color based on class (yellow, blue, unknown)
                if cls == 0:
                    marker.color.r, marker.color.g, marker.color.b = 1.0, 1.0, 0.0  # Yellow
                elif cls == 1:
                    marker.color.r, marker.color.g, marker.color.b = 0.0, 0.0, 1.0  # Blue
                else:
                    marker.color.r, marker.color.g, marker.color.b = 0.5, 0.5, 0.5  # Gray
                marker.color.a = 1.0
                marker_array.markers.append(marker)
        
        self.cone_map_pub.publish(marker_array)

    def publish_path(self, path_planner):
        """Publish the planned path as a Marker for RViz."""
        if not path_planner.path:
            return
        
        marker = Marker()
        marker.header.frame_id = "vehicle"
        marker.header.stamp = self.get_clock().now().to_msg()
        marker.ns = "path"
        marker.id = 0
        marker.type = Marker.LINE_STRIP
        marker.action = Marker.ADD
        marker.scale.x = 0.1  # Line width
        marker.color.r, marker.color.g, marker.color.b = 0.0, 1.0, 0.0  # Green
        marker.color.a = 1.0
        
        for x, y in path_planner.path:
            point = Point()
            point.x = float(y)  # Depth (forward) as x in vehicle frame
            point.y = float(x)  # Lateral as y in vehicle frame
            point.z = 0.0
            marker.points.append(point)
        
        self.path_pub.publish(marker)

    def publish_lidar_points(self, point_cloud):
        """Publish raw LiDAR points for RViz."""
        header = Header()
        header.frame_id = "lidar"
        header.stamp = self.get_clock().now().to_msg()
        fields = [pc2.PointField(name='x', offset=0, datatype=pc2.PointField.FLOAT32, count=1),
                  pc2.PointField(name='y', offset=4, datatype=pc2.PointField.FLOAT32, count=1),
                  pc2.PointField(name='z', offset=8, datatype=pc2.PointField.FLOAT32, count=1)]
        points = [(p[1], p[0], p[2]) for p in point_cloud]  # Swap x/y to match vehicle frame
        cloud_msg = pc2.create_cloud(header, fields, points)
        self.lidar_pub.publish(cloud_msg)

    def save_map_and_path(self, filename="thesis_map.txt"):
        """Save the cone map and path to a file."""
        with open(filename, 'w') as f:
            f.write("Cone Map (x, y, class):\n")
            for cone in self.cone_mapper.cone_map:
                f.write(f"{cone[0]}, {cone[1]}, {int(cone[3])}\n")
            f.write("\nPath (x, y):\n")
            if self.path_planner.path:
                for x, y in self.path_planner.path:
                    f.write(f"{x}, {y}\n")
        self.get_logger().info(f"Map and path saved to {filename}")

    def _publish_lidar_pointcloud(self, points):
        """Helper to publish LiDAR point cloud."""
        try:
            header = Header()
            header.stamp = self.get_clock().now().to_msg()
            header.frame_id = "map"
            
            fields = [
                pc2.PointField(name='x', offset=0, datatype=pc2.PointField.FLOAT32, count=1),
                pc2.PointField(name='y', offset=4, datatype=pc2.PointField.FLOAT32, count=1),
                pc2.PointField(name='z', offset=8, datatype=pc2.PointField.FLOAT32, count=1),
                pc2.PointField(name='intensity', offset=12, datatype=pc2.PointField.FLOAT32, count=1)
            ]
            
            # Create structured array
            structured_points = np.zeros(len(points), 
                                        dtype=[
                                            ('x', np.float32),
                                            ('y', np.float32),
                                            ('z', np.float32),
                                            ('intensity', np.float32)
                                        ])
            
            structured_points['x'] = points[:, 0]
            structured_points['y'] = points[:, 1]
            structured_points['z'] = points[:, 2]
            
            # Simple intensity based on height
            min_z = np.min(points[:, 2])
            max_z = np.max(points[:, 2])
            z_range = max_z - min_z if max_z > min_z else 1.0
            intensity = (points[:, 2] - min_z) / z_range
            structured_points['intensity'] = intensity
            
            pc_msg = pc2.create_cloud(header, fields, structured_points)
            self.lidar_pub.publish(pc_msg)
            
        except Exception as e:
            self.get_logger().error(f"Error publishing point cloud: {str(e)}")


def main(args=None):
    rclpy.init(args=args)
    
    try:
        node = LidarCameraFusionNode()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(f"Error in main: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # Clean up
        if 'node' in locals():
            node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()