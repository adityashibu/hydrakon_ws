import numpy as np
import cv2
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Dict, Tuple, Optional
import math
import types
from std_msgs.msg import Header
import sensor_msgs_py.point_cloud2 as pc2

class LowLevelFusionDetector:
    def __init__(self, camera_resolution=(1280, 720), fov_horizontal=90.0):
        """Initialize the low-level fusion detector."""
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.feature_maps = None
        self.last_detections = []
        self.camera_resolution = camera_resolution
        self.fov_horizontal = fov_horizontal
        
        # Default camera matrix based on resolution and FOV
        self.camera_matrix = self._compute_camera_matrix()
        
    def _compute_camera_matrix(self):
        """Compute camera matrix from resolution and FOV."""
        width, height = self.camera_resolution
        # Compute focal length from FOV
        fx = width / (2 * np.tan(np.radians(self.fov_horizontal / 2)))
        fy = fx  # Assume square pixels
        cx = width / 2
        cy = height / 2
        
        return np.array([
            [fx, 0, cx],
            [0, fy, cy],
            [0, 0, 1]
        ])
        
    def create_feature_maps(self, rgb_image: np.ndarray, lidar_points: np.ndarray, 
                          lidar_to_camera_transform: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Create fused feature maps from RGB image and LiDAR points.
        
        Args:
            rgb_image: RGB image from camera (H, W, 3)
            lidar_points: LiDAR points (N, 3) in world/lidar frame
            lidar_to_camera_transform: Optional 4x4 transformation matrix
            
        Returns:
            Fused feature maps (H, W, 6) containing RGB + LiDAR features
        """
        height, width = rgb_image.shape[:2]
        
        # Initialize feature maps
        depth_map = np.zeros((height, width), dtype=np.float32)
        point_count_map = np.zeros((height, width), dtype=np.int32)
        height_map = np.zeros((height, width), dtype=np.float32)
        
        # Transform LiDAR points to camera frame if needed
        if lidar_to_camera_transform is not None:
            # Add homogeneous coordinate
            points_hom = np.hstack([lidar_points, np.ones((len(lidar_points), 1))])
            # Transform to camera frame
            points_cam = (lidar_to_camera_transform @ points_hom.T).T[:, :3]
        else:
            points_cam = lidar_points
            
        # Filter points in front of camera
        valid_mask = points_cam[:, 2] > 0.1
        points_cam = points_cam[valid_mask]
        
        if len(points_cam) > 0:
            # Project points to image plane
            points_2d = self._project_points(points_cam)
            
            # Create maps
            for i, (x, y) in enumerate(points_2d):
                if 0 <= x < width and 0 <= y < height:
                    depth = points_cam[i, 2]
                    # Use closest point if multiple points project to same pixel
                    if depth_map[int(y), int(x)] == 0 or depth < depth_map[int(y), int(x)]:
                        depth_map[int(y), int(x)] = depth
                        height_map[int(y), int(x)] = points_cam[i, 1]  # Y is height in camera frame
                    point_count_map[int(y), int(x)] += 1
        
        # Dilate sparse maps for better coverage
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        depth_map_dilated = cv2.dilate(depth_map, kernel, iterations=1)
        
        # Compute intensity from point density
        intensity_map = np.clip(point_count_map / 5.0, 0, 1).astype(np.float32)
        
        # Compute gradient map for edge detection
        gradient_map = self._compute_gradient_map(depth_map_dilated)
        
        # Normalize maps
        depth_feature = np.clip(depth_map_dilated / 20.0, 0, 1)  # Normalize to 20m range
        height_feature = np.clip((height_map + 2.0) / 4.0, 0, 1)  # Normalize height
        
        # Stack LiDAR features
        lidar_features = np.stack([depth_feature, intensity_map, gradient_map], axis=-1)
        
        # Normalize RGB to [0, 1]
        rgb_normalized = rgb_image.astype(np.float32) / 255.0
        
        # Combine features
        fused_features = np.concatenate([rgb_normalized, lidar_features], axis=-1)
        
        return fused_features
    
    def _project_points(self, points_cam: np.ndarray) -> np.ndarray:
        """Project 3D points to 2D image plane."""
        # Project using camera matrix
        points_2d = self.camera_matrix @ points_cam.T
        points_2d = points_2d[:2] / points_2d[2]
        return points_2d.T.astype(int)
    
    def _compute_gradient_map(self, depth_map: np.ndarray) -> np.ndarray:
        """Compute gradient magnitude for edge detection."""
        # Compute gradients
        sobelx = cv2.Sobel(depth_map, cv2.CV_32F, 1, 0, ksize=3)
        sobely = cv2.Sobel(depth_map, cv2.CV_32F, 0, 1, ksize=3)
        
        # Compute magnitude
        gradient_mag = np.sqrt(sobelx**2 + sobely**2)
        
        # Normalize
        return np.clip(gradient_mag / 5.0, 0, 1)
    
    def detect_cones_multimodal(self, rgb_image: np.ndarray, lidar_points: np.ndarray,
                               yolo_model=None, cone_detections=None) -> List[Dict]:
        """
        Detect cones using low-level fusion of camera and LiDAR data.
        
        Args:
            rgb_image: RGB image
            lidar_points: LiDAR point cloud
            yolo_model: YOLO model (optional)
            cone_detections: Existing cone detections to refine (optional)
            
        Returns:
            List of detected cones with enhanced attributes
        """
        # Create fused features
        fused_features = self.create_feature_maps(rgb_image, lidar_points)
        self.feature_maps = fused_features
        
        # Get initial detections
        if cone_detections is not None:
            # Use provided detections
            initial_detections = cone_detections
        elif yolo_model is not None:
            # Run YOLO on RGB image
            results = yolo_model(rgb_image, conf=0.15)
            initial_detections = self._extract_yolo_detections(results)
            
            # If no YOLO detections, generate from fusion features
            if not initial_detections:
                self.get_logger().warn("No YOLO detections, generating from fusion features")
                initial_detections = self._generate_detections_from_fusion(fused_features)
        else:
            # Generate detections from fused features
            initial_detections = self._generate_detections_from_fusion(fused_features)
        
        # Refine detections using fused features
        refined_detections = []
        
        for det in initial_detections:
            # Extract ROI from fused features
            x1, y1, x2, y2 = map(int, det['box'])
            
            # Ensure ROI is within bounds
            x1 = max(0, x1)
            y1 = max(0, y1)
            x2 = min(fused_features.shape[1], x2)
            y2 = min(fused_features.shape[0], y2)
            
            if x2 <= x1 or y2 <= y1:
                continue
                
            roi = fused_features[y1:y2, x1:x2]
            
            # Validate using multimodal features
            if self._validate_cone_multimodal(roi):
                # Compute enhanced attributes
                depth = self._estimate_depth_from_roi(roi, det)
                confidence = self._compute_multimodal_confidence(roi, det)
                
                # Create refined detection
                refined_det = {
                    'box': (x1, y1, x2, y2),
                    'cls': det.get('cls', 0),
                    'depth': depth,
                    'confidence': confidence,
                    'multimodal_score': confidence,
                    'visual_conf': det.get('confidence', 0.5),
                    'lidar_conf': self._compute_lidar_confidence(roi)
                }
                
                refined_detections.append(refined_det)
        
        self.last_detections = refined_detections
        return refined_detections
    
    def _extract_yolo_detections(self, results):
        """Extract cone detections from YOLO results."""
        detections = []
        for result in results:
            if result.boxes is not None:
                for box in result.boxes:
                    cls = int(box.cls.item())
                    if cls in [0, 1]:  # Cone classes
                        x1, y1, x2, y2 = map(int, box.xyxy[0])
                        detections.append({
                            'box': (x1, y1, x2, y2),
                            'cls': cls,
                            'confidence': box.conf.item()
                        })
        return detections
    
    def _generate_detections_from_fusion(self, fused_features):
        """Generate cone proposals from fused features."""
        # Extract depth channel
        depth_channel = fused_features[:, :, 3]
        
        # Find regions with valid depth
        depth_mask = (depth_channel > 0.1) & (depth_channel < 0.5)  # 2-10m range
        
        # Find regions with high gradient (edges)
        gradient_channel = fused_features[:, :, 5]
        edge_mask = gradient_channel > 0.3
        
        # Combine masks
        combined_mask = depth_mask & edge_mask
        
        # Find connected components
        num_labels, labels = cv2.connectedComponents(combined_mask.astype(np.uint8))
        
        detections = []
        for label in range(1, num_labels):
            mask = (labels == label).astype(np.uint8)
            
            # Find bounding box
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            if contours:
                x, y, w, h = cv2.boundingRect(contours[0])
                
                # Filter by size
                if 10 < w < 100 and 10 < h < 150:
                    detections.append({
                        'box': (x, y, x + w, y + h),
                        'cls': 0,  # Default class
                        'confidence': 0.5  # Default confidence
                    })
        
        return detections
    
    def _validate_cone_multimodal(self, roi):
        """Validate if ROI contains a cone using multimodal features - LESS STRICT VERSION."""
        if roi.size == 0:
            return False
            
        # Check depth consistency
        depth_channel = roi[:, :, 3]
        valid_depth = depth_channel[depth_channel > 0]
        
        # CHANGED: Reduced minimum valid points requirement
        if len(valid_depth) < 3:  # Was 10, now 3
            # If we don't have enough LiDAR points, still accept based on vision
            return True  # Trust the vision detection
            
        # CHANGED: Increased acceptable variance
        if np.std(valid_depth) > 0.5:  # Was 0.3, now 0.5
            # Still might be a cone, just with more depth variation
            pass
            
        # Check for edge presence
        gradient_channel = roi[:, :, 5]
        if np.mean(gradient_channel) < 0.05:  # Reduced from 0.1
            # Low gradient doesn't necessarily mean no cone
            pass
            
        return True  # Default to accepting the detection
    
    def _estimate_depth_from_roi(self, roi, detection):
        """Estimate depth from ROI using multimodal cues."""
        # Extract depth channel
        depth_channel = roi[:, :, 3] * 20.0  # Denormalize
        valid_depths = depth_channel[depth_channel > 0]
        
        if len(valid_depths) > 0:
            # Use median for robustness
            lidar_depth = np.median(valid_depths)
            
            # If we have the original depth from detection, blend it
            if 'depth' in detection:
                return 0.7 * lidar_depth + 0.3 * detection['depth']
            else:
                return lidar_depth
        else:
            # Fallback to detection depth or estimate
            return detection.get('depth', 5.0)
    
    def _compute_multimodal_confidence(self, roi, detection):
        """Compute confidence combining visual and LiDAR cues."""
        visual_conf = detection.get('confidence', 0.5)
        lidar_conf = self._compute_lidar_confidence(roi)
        
        # Weighted combination
        return 0.6 * visual_conf + 0.4 * lidar_conf
    
    def _compute_lidar_confidence(self, roi):
        """Compute confidence from LiDAR features."""
        if roi.size == 0:
            return 0.0
            
        # Depth consistency
        depth_channel = roi[:, :, 3]
        valid_depth_ratio = np.sum(depth_channel > 0) / depth_channel.size
        
        # Point density
        intensity_channel = roi[:, :, 4]
        density_score = np.mean(intensity_channel)
        
        # Edge strength
        gradient_channel = roi[:, :, 5]
        edge_score = np.mean(gradient_channel)
        
        # Combine scores
        lidar_conf = (valid_depth_ratio + density_score + edge_score) / 3.0
        
        return np.clip(lidar_conf, 0, 1)

def integrate_low_level_fusion(node):
    """
    Integrate low-level fusion into the existing node.
    """
    try:
        node.get_logger().info("Starting low-level fusion integration...")
        
        # Store original methods
        node._original_process_lidar_data = node.process_lidar_data
        node._original_process_frame = node.zed_camera.process_frame
        
        # Apply the validation fix to the detector
        if hasattr(node, 'low_level_detector'):
            node.low_level_detector = patch_fusion_validation(node.low_level_detector)
            node.get_logger().info("Applied fusion validation fix")
        
        def process_frame_with_fusion(self):
            """Modified process_frame that works with fusion."""
            try:
                rgb_available = False
                depth_available = False
                
                if not self.rgb_queue.empty():
                    with self.lock:
                        self.rgb_image = self.rgb_queue.get()
                    rgb_available = True
                
                if not self.depth_queue.empty():
                    with self.lock:
                        self.depth_image = self.depth_queue.get()
                    depth_available = True
                
                # IMPORTANT: Still run YOLO detection here!
                if rgb_available and depth_available and self.yolo_model:
                    # Run YOLO but DON'T draw detections yet
                    results = self.yolo_model(self.rgb_image, conf=0.2)
                    
                    # Store raw YOLO results for fusion
                    self._yolo_results = results
                    
                    # Extract detections for fusion
                    self.cone_detections = []
                    for result in results:
                        if result.boxes is not None:
                            for box in result.boxes:
                                x1, y1, x2, y2 = map(int, box.xyxy[0])
                                conf = box.conf.item()
                                cls = int(box.cls.item())
                                
                                if cls in [0, 1] and conf > 0.2:  # Cone classes
                                    # Get depth from depth map
                                    depth_array, _ = self.depth_image
                                    center_x = (x1 + x2) // 2
                                    center_y = (y1 + y2) // 2
                                    
                                    if 0 <= center_y < depth_array.shape[0] and 0 <= center_x < depth_array.shape[1]:
                                        depth = float(depth_array[center_y, center_x])
                                    else:
                                        depth = 5.0  # Default
                                    
                                    self.cone_detections.append({
                                        'box': (x1, y1, x2, y2),
                                        'cls': cls,
                                        'confidence': conf,
                                        'depth': depth
                                    })
                    
                    # DON'T draw detections here - let fusion handle it
                    node.get_logger().info(f"YOLO detected {len(self.cone_detections)} cones for fusion")
                    
            except Exception as e:
                print(f"Error in process frame with fusion: {e}")
        
        def process_lidar_data_with_fusion(self):
            """Enhanced process_lidar_data using low-level fusion."""
            if self.lidar is None or not hasattr(self, 'lidar_data') or self.lidar_data is None:
                self.get_logger().warn("LiDAR data not available")
                return
            
            # Check for camera data
            if not hasattr(self.zed_camera, 'rgb_image') or self.zed_camera.rgb_image is None:
                self.get_logger().warn("No camera data for fusion, using LiDAR only")
                return self._original_process_lidar_data()
            
            try:
                self.get_logger().info("*** PROCESSING WITH LOW-LEVEL FUSION ***")
                
                # Get sensor transformation
                sensor_transform = np.array(self.lidar.get_transform().get_matrix())
                
                # Get LiDAR data
                with self.lidar_lock:
                    lidar_data = self.lidar_data.copy()
                
                # Transform to world coordinates
                from .lidar_camera_fusion import transform_points
                points_world = transform_points(lidar_data, sensor_transform)
                
                # Accumulate points
                with self.lidar_history_lock:
                    self.lidar_history.append(points_world)
                    if len(self.lidar_history) > self.accumulate_frames:
                        self.lidar_history.pop(0)
                    
                    all_points = np.vstack(self.lidar_history)
                
                self.latest_lidar_points = all_points
                
                # Get RGB image
                rgb_image = self.zed_camera.rgb_image.copy()
                
                # Get existing camera detections
                existing_detections = []
                if hasattr(self.zed_camera, 'cone_detections') and self.zed_camera.cone_detections:
                    existing_detections = self.zed_camera.cone_detections
                    self.get_logger().info(f"Using {len(existing_detections)} camera detections for fusion")
                
                # Perform LOW-LEVEL FUSION detection
                self.get_logger().info(f"Performing LOW-LEVEL FUSION with {len(all_points)} LiDAR points and {len(existing_detections)} camera detections")
                
                # Use the existing detections as input
                fused_detections = self.low_level_detector.detect_cones_multimodal(
                    rgb_image,
                    all_points,
                    yolo_model=None,  # Don't run YOLO again
                    cone_detections=existing_detections  # Use existing detections
                )
                
                # Update camera detections with fused results
                if fused_detections:
                    self.zed_camera.cone_detections = fused_detections
                    
                    # Now draw the fused detections on the image
                    for det in fused_detections:
                        x1, y1, x2, y2 = det['box']
                        cls = det['cls']
                        depth = det['depth']
                        conf = det['confidence']
                        
                        # Draw on image
                        color = (0, 255, 0) if cls == 0 else (255, 0, 0)  # Green for yellow, Blue for blue
                        cv2.rectangle(self.zed_camera.rgb_image, (x1, y1), (x2, y2), color, 2)
                        label = f"Cone: {depth:.2f}m ({conf:.2f})"
                        cv2.putText(self.zed_camera.rgb_image, label, (x1, y1-10), 
                                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
                
                self.get_logger().info(f"LOW-LEVEL FUSION detected {len(fused_detections)} cones")
                
                # Log detection details
                for i, det in enumerate(fused_detections):
                    self.get_logger().info(
                        f"  Cone {i+1}: Depth={det['depth']:.2f}m, "
                        f"Visual={det.get('visual_conf', det['confidence']):.2f}, "
                        f"Fused={det['confidence']:.2f}"
                    )
                
                # Visualize detected cones in 3D
                detected_cones = []
                for det in fused_detections:
                    # Estimate 3D position
                    x1, y1, x2, y2 = det['box']
                    center_x = (x1 + x2) / 2
                    center_y = (y1 + y2) / 2
                    
                    # Simple 3D position estimation
                    angle = ((center_x - 640) / 640) * (np.radians(45))
                    x_3d = det['depth'] * np.tan(angle)
                    
                    detected_cones.append({
                        'position': np.array([x_3d, det['depth'], 0]),
                        'confidence': det['confidence'],
                        'size': [0.3, 0.3, 0.4]
                    })
                
                if hasattr(self, 'visualize_3d_cones'):
                    self.visualize_3d_cones(detected_cones)
                
                # Continue with rest of processing
                self.analyze_lidar_for_turns(all_points, detected_cones)
                
                # Publish point cloud
                self._publish_lidar_pointcloud(all_points)
                
            except Exception as e:
                self.get_logger().error(f"Error in low-level fusion: {str(e)}")
                import traceback
                self.get_logger().error(traceback.format_exc())
                # Fallback to original method
                return self._original_process_lidar_data()
        
        def _publish_lidar_pointcloud(self, points):
            """Helper to publish LiDAR point cloud."""
            try:
                header = Header()
                header.stamp = self.get_clock().now().to_msg()
                header.frame_id = "map"
                
                fields = [
                    pc2.PointField(name='x', offset=0, datatype=pc2.PointField.FLOAT32, count=1),
                    pc2.PointField(name='y', offset=4, datatype=pc2.PointField.FLOAT32, count=1),
                    pc2.PointField(name='z', offset=8, datatype=pc2.PointField.FLOAT32, count=1),
                    pc2.PointField(name='intensity', offset=12, datatype=pc2.PointField.FLOAT32, count=1)
                ]
                
                # Create structured array
                structured_points = np.zeros(len(points), 
                                            dtype=[
                                                ('x', np.float32),
                                                ('y', np.float32),
                                                ('z', np.float32),
                                                ('intensity', np.float32)
                                            ])
                
                structured_points['x'] = points[:, 0]
                structured_points['y'] = points[:, 1]
                structured_points['z'] = points[:, 2]
                
                # Simple intensity based on height
                min_z = np.min(points[:, 2])
                max_z = np.max(points[:, 2])
                z_range = max_z - min_z if max_z > min_z else 1.0
                intensity = (points[:, 2] - min_z) / z_range
                structured_points['intensity'] = intensity
                
                pc_msg = pc2.create_cloud(header, fields, structured_points)
                self.lidar_pub.publish(pc_msg)
                
            except Exception as e:
                self.get_logger().error(f"Error publishing point cloud: {str(e)}")
        
        # Bind new methods
        node.zed_camera.process_frame = types.MethodType(process_frame_with_fusion, node.zed_camera)
        node.process_lidar_data = types.MethodType(process_lidar_data_with_fusion, node)
        node._publish_lidar_pointcloud = types.MethodType(_publish_lidar_pointcloud, node)
        
        # Add missing imports
        import cv2
        import numpy as np
        from std_msgs.msg import Header
        import sensor_msgs_py.point_cloud2 as pc2
        
        node.get_logger().info("Low-level fusion integration complete!")
        
    except Exception as e:
        node.get_logger().error(f"Error integrating low-level fusion: {str(e)}")
        import traceback
        node.get_logger().error(traceback.format_exc())
        
        # Restore original methods on failure
        if hasattr(node, '_original_process_lidar_data'):
            node.process_lidar_data = node._original_process_lidar_data
        if hasattr(node, '_original_process_frame'):
            node.zed_camera.process_frame = node._original_process_frame 