#!/usr/bin/env python3
"""
LiDAR-Camera Calibration Tools for Formula Student

This module provides tools to calibrate the transformation between LiDAR and camera
to ensure accurate sensor fusion.
"""

import numpy as np
import cv2
from scipy.optimize import minimize
import matplotlib.pyplot as plt
from typing import List, Tuple, Optional
import yaml
import os

class LidarCameraCalibrator:
    """
    Tool for calibrating LiDAR-Camera transformation matrix.
    """
    
    def __init__(self, camera_matrix: np.ndarray):
        self.camera_matrix = camera_matrix
        self.calibration_points_2d = []  # Camera points
        self.calibration_points_3d = []  # LiDAR points
        self.transform = np.eye(4)
        
    def add_correspondence(self, camera_point: Tuple[int, int], 
                          lidar_point: Tuple[float, float, float]):
        """
        Add a corresponding point pair for calibration.
        
        Args:
            camera_point: (x, y) pixel coordinates in camera image
            lidar_point: (x, y, z) 3D coordinates in LiDAR frame
        """
        self.calibration_points_2d.append(camera_point)
        self.calibration_points_3d.append(lidar_point)
        print(f"Added correspondence: Camera {camera_point} <-> LiDAR {lidar_point}")
        
    def calibrate(self, method='pnp') -> np.ndarray:
        """
        Perform calibration using collected correspondences.
        
        Args:
            method: 'pnp' for PnP solver or 'optimization' for full optimization
            
        Returns:
            4x4 transformation matrix from LiDAR to camera frame
        """
        if len(self.calibration_points_2d) < 6:
            raise ValueError("Need at least 6 point correspondences for calibration")
        
        points_2d = np.array(self.calibration_points_2d, dtype=np.float32)
        points_3d = np.array(self.calibration_points_3d, dtype=np.float32)
        
        if method == 'pnp':
            # Use OpenCV PnP solver
            _, rvec, tvec = cv2.solvePnP(
                points_3d, points_2d, self.camera_matrix, None,
                flags=cv2.SOLVEPNP_ITERATIVE
            )
            
            # Convert to transformation matrix
            R, _ = cv2.Rodrigues(rvec)
            self.transform[:3, :3] = R
            self.transform[:3, 3] = tvec.flatten()
            
        else:  # Full optimization
            # Initial guess from PnP
            self.calibrate(method='pnp')
            initial_params = self._matrix_to_params(self.transform)
            
            # Optimize
            result = minimize(
                self._calibration_error,
                initial_params,
                args=(points_3d, points_2d),
                method='Powell'
            )
            
            self.transform = self._params_to_matrix(result.x)
        
        # Compute and print calibration error
        error = self._compute_reprojection_error()
        print(f"Calibration complete. Reprojection error: {error:.2f} pixels")
        
        return self.transform
    
    def _calibration_error(self, params, points_3d, points_2d):
        """Objective function for calibration optimization."""
        transform = self._params_to_matrix(params)
        
        # Transform LiDAR points to camera frame
        points_3d_hom = np.hstack([points_3d, np.ones((len(points_3d), 1))])
        points_cam = (transform @ points_3d_hom.T).T[:, :3]
        
        # Project to image
        projected = []
        for p in points_cam:
            if p[2] > 0:  # In front of camera
                uv = self.camera_matrix @ p
                uv = uv[:2] / uv[2]
                projected.append(uv)
            else:
                projected.append([0, 0])  # Invalid
                
        projected = np.array(projected)
        
        # Compute error
        error = np.mean(np.linalg.norm(projected - points_2d, axis=1))
        return error
    
    def _matrix_to_params(self, matrix):
        """Convert transformation matrix to optimization parameters."""
        # Extract rotation as Rodrigues vector
        rvec, _ = cv2.Rodrigues(matrix[:3, :3])
        tvec = matrix[:3, 3]
        return np.concatenate([rvec.flatten(), tvec])
    
    def _params_to_matrix(self, params):
        """Convert optimization parameters to transformation matrix."""
        rvec = params[:3]
        tvec = params[3:6]
        
        R, _ = cv2.Rodrigues(rvec)
        transform = np.eye(4)
        transform[:3, :3] = R
        transform[:3, 3] = tvec
        
        return transform
    
    def _compute_reprojection_error(self):
        """Compute average reprojection error in pixels."""
        points_3d = np.array(self.calibration_points_3d)
        points_2d = np.array(self.calibration_points_2d)
        
        return self._calibration_error(
            self._matrix_to_params(self.transform),
            points_3d, points_2d
        )
    
    def visualize_calibration(self, image: np.ndarray, lidar_points: np.ndarray):
        """
        Visualize calibration result by projecting LiDAR points onto image.
        
        Args:
            image: Camera image
            lidar_points: LiDAR point cloud (N x 3)
        """
        # Transform points
        points_hom = np.hstack([lidar_points, np.ones((len(lidar_points), 1))])
        points_cam = (self.transform @ points_hom.T).T[:, :3]
        
        # Project to image
        viz_image = image.copy()
        
        for p in points_cam:
            if p[2] > 0.1:  # In front of camera
                uv = self.camera_matrix @ p
                u, v = int(uv[0] / uv[2]), int(uv[1] / uv[2])
                
                if 0 <= u < image.shape[1] and 0 <= v < image.shape[0]:
                    # Color by depth
                    depth_normalized = min(1.0, p[2] / 20.0)
                    color = plt.cm.jet(depth_normalized)[:3]
                    color = tuple([int(c * 255) for c in color])
                    cv2.circle(viz_image, (u, v), 2, color, -1)
        
        return viz_image
    
    def save_calibration(self, filename: str):
        """Save calibration to YAML file."""
        calibration_data = {
            'transform_matrix': self.transform.tolist(),
            'camera_matrix': self.camera_matrix.tolist(),
            'num_correspondences': len(self.calibration_points_2d),
            'reprojection_error': float(self._compute_reprojection_error())
        }
        
        with open(filename, 'w') as f:
            yaml.dump(calibration_data, f, default_flow_style=False)
        
        print(f"Calibration saved to {filename}")
    
    def load_calibration(self, filename: str):
        """Load calibration from YAML file."""
        with open(filename, 'r') as f:
            data = yaml.load(f, Loader=yaml.FullLoader)
        
        self.transform = np.array(data['transform_matrix'])
        print(f"Calibration loaded. Error: {data['reprojection_error']:.2f} pixels")
        
        return self.transform


class InteractiveCalibrationTool:
    """
    Interactive tool for selecting corresponding points in camera and LiDAR data.
    """
    
    def __init__(self, calibrator: LidarCameraCalibrator):
        self.calibrator = calibrator
        self.current_image = None
        self.current_lidar = None
        self.selected_points_2d = []
        self.selected_points_3d = []
        
    def calibrate_interactive(self, image: np.ndarray, lidar_points: np.ndarray):
        """
        Run interactive calibration process.
        
        Args:
            image: Camera image showing cones
            lidar_points: LiDAR point cloud
        """
        self.current_image = image.copy()
        self.current_lidar = lidar_points
        
        print("\n=== Interactive Calibration Tool ===")
        print("1. Click on cone centers in the camera image")
        print("2. The tool will find the corresponding LiDAR points")
        print("3. Press 'c' to calibrate, 'q' to quit")
        print("4. Press 'r' to reset selections")
        
        # Setup mouse callback
        cv2.namedWindow('Camera View')
        cv2.setMouseCallback('Camera View', self._mouse_callback)
        
        # Create LiDAR bird's eye view
        self._create_lidar_bev()
        
        while True:
            # Display images
            display_img = self._draw_selections()
            cv2.imshow('Camera View', display_img)
            cv2.imshow('LiDAR BEV', self.lidar_bev)
            
            key = cv2.waitKey(1) & 0xFF
            
            if key == ord('q'):
                break
            elif key == ord('c'):
                if len(self.selected_points_2d) >= 6:
                    self._perform_calibration()
                else:
                    print("Need at least 6 point pairs for calibration")
            elif key == ord('r'):
                self._reset_selections()
        
        cv2.destroyAllWindows()
    
    def _mouse_callback(self, event, x, y, flags, param):
        """Handle mouse clicks on camera image."""
        if event == cv2.EVENT_LBUTTONDOWN:
            # Add camera point
            self.selected_points_2d.append((x, y))
            
            # Find corresponding LiDAR point (simplified - in practice use more sophisticated matching)
            lidar_point = self._find_lidar_correspondence(x, y)
            if lidar_point is not None:
                self.selected_points_3d.append(lidar_point)
                self.calibrator.add_correspondence((x, y), lidar_point)
                print(f"Added point pair #{len(self.selected_points_2d)}")
            else:
                self.selected_points_2d.pop()  # Remove if no correspondence found
                print("No LiDAR correspondence found at this location")
    
    def _find_lidar_correspondence(self, x, y):
        """
        Find LiDAR point corresponding to clicked image location.
        This is a simplified version - real implementation would use cone detection.
        """
        # For actual implementation:
        # 1. Use cone detection on LiDAR to find cone positions
        # 2. Match based on expected projection area
        # 3. Use initial rough calibration to guide search
        
        # Simplified: return a dummy point for demonstration
        # In practice, this would involve cone detection in both modalities
        print("Please manually select corresponding LiDAR point in the BEV window")
        return None
    
    def _create_lidar_bev(self):
        """Create bird's eye view of LiDAR points."""
        # Parameters
        x_range = (-10, 10)  # meters
        y_range = (0, 30)    # meters
        resolution = 0.05    # meters per pixel
        
        # Image dimensions
        width = int((x_range[1] - x_range[0]) / resolution)
        height = int((y_range[1] - y_range[0]) / resolution)
        
        # Create BEV image
        self.lidar_bev = np.zeros((height, width, 3), dtype=np.uint8)
        
        # Project points
        for point in self.current_lidar:
            x, y, z = point
            
            # Check if in range
            if x_range[0] <= x <= x_range[1] and y_range[0] <= y <= y_range[1]:
                # Convert to pixel coordinates
                px = int((x - x_range[0]) / resolution)
                py = height - int((y - y_range[0]) / resolution)
                
                # Color by height
                if 0.1 < z < 0.6:  # Cone height range
                    self.lidar_bev[py, px] = [0, 255, 255]  # Yellow for cones
                else:
                    self.lidar_bev[py, px] = [100, 100, 100]  # Gray for other
    
    def _draw_selections(self):
        """Draw selected points on camera image."""
        display = self.current_image.copy()
        
        for i, (x, y) in enumerate(self.selected_points_2d):
            cv2.circle(display, (x, y), 5, (0, 255, 0), -1)
            cv2.putText(display, str(i+1), (x+10, y), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
        
        return display
    
    def _perform_calibration(self):
        """Run calibration with selected points."""
        try:
            transform = self.calibrator.calibrate(method='optimization')
            print("\nCalibration successful!")
            print("Transformation matrix:")
            print(transform)
            
            # Visualize result
            viz = self.calibrator.visualize_calibration(
                self.current_image, self.current_lidar
            )
            cv2.imshow('Calibration Result', viz)
            
            # Save calibration
            self.calibrator.save_calibration('lidar_camera_calibration.yaml')
            
        except Exception as e:
            print(f"Calibration failed: {e}")
    
    def _reset_selections(self):
        """Reset all selections."""
        self.selected_points_2d = []
        self.selected_points_3d = []
        self.calibrator.calibration_points_2d = []
        self.calibrator.calibration_points_3d = []
        print("Selections reset")


# Example usage function
def run_calibration(camera_matrix, camera_image, lidar_points):
    """
    Run the calibration process.
    
    Args:
        camera_matrix: 3x3 camera intrinsic matrix
        camera_image: Image from camera showing cones
        lidar_points: Nx3 array of LiDAR points
    """
    # Create calibrator
    calibrator = LidarCameraCalibrator(camera_matrix)
    
    # Option 1: Manual correspondence (for testing)
    # Add some manual correspondences - replace with actual detected cones
    # calibrator.add_correspondence((640, 400), (2.0, 5.0, 0.3))
    # calibrator.add_correspondence((480, 380), (-1.0, 6.0, 0.3))
    # ... add more correspondences
    
    # Option 2: Interactive calibration
    tool = InteractiveCalibrationTool(calibrator)
    tool.calibrate_interactive(camera_image, lidar_points)
    
    # Option 3: Load existing calibration
    # calibrator.load_calibration('lidar_camera_calibration.yaml')
    
    return calibrator.transform


# Quick calibration for CARLA (since sensors are at known positions)
def get_carla_calibration():
    """
    Get approximate calibration for CARLA sensors.
    This assumes standard sensor mounting positions.
    """
    # LiDAR is typically mounted above the vehicle
    # Camera is mounted at front
    transform = np.eye(4)
    
    # Translation (LiDAR to Camera)
    transform[0, 3] = 0.0   # x: aligned
    transform[1, 3] = -0.4  # y: LiDAR is 0.4m above camera
    transform[2, 3] = -0.3  # z: LiDAR is 0.3m behind camera
    
    # Rotation to align coordinate systems
    # LiDAR: X-forward, Y-left, Z-up
    # Camera: X-right, Y-down, Z-forward
    R = np.array([
        [0, -1, 0],   # Camera X = -LiDAR Y
        [0, 0, -1],   # Camera Y = -LiDAR Z  
        [1, 0, 0]     # Camera Z = LiDAR X
    ])
    transform[:3, :3] = R
    
    return transform 