import numpy as np
import cv2
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Dict, Tuple, Optional
import time
from numba import jit, prange
import threading
from collections import deque

class OptimizedLowLevelFusionDetector:
    def __init__(self, camera_resolution=(1280, 720), fov_horizontal=90.0):
        """Initialize the optimized low-level fusion detector."""
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.camera_resolution = camera_resolution
        self.fov_horizontal = fov_horizontal
        
        # Camera intrinsics
        self.camera_matrix = self._compute_camera_matrix()
        
        # Calibration parameters (CRITICAL - these need to be calibrated!)
        self.lidar_to_camera_transform = np.eye(4)
        self._initialize_calibration()
        
        # Performance optimization
        self.use_gpu = torch.cuda.is_available()
        self.feature_cache = {}
        self.last_lidar_timestamp = 0
        
        # Detection parameters
        self.cone_height_range = (0.1, 0.6)  # meters
        self.cone_radius = 0.15  # meters
        self.min_points_per_cone = 5
        
        # Temporal filtering
        self.detection_history = deque(maxlen=5)
        
    def _initialize_calibration(self):
        """Initialize LiDAR-Camera calibration transform."""
        # These values need to be calibrated for your specific setup!
        # This is a typical transform for a forward-facing camera with LiDAR above
        
        # Translation: LiDAR is typically above and behind the camera
        self.lidar_to_camera_transform[0, 3] = 0.0   # x offset
        self.lidar_to_camera_transform[1, 3] = -0.4  # y offset (LiDAR above camera)
        self.lidar_to_camera_transform[2, 3] = -0.3  # z offset (LiDAR behind camera)
        
        # Rotation: Align LiDAR frame with camera frame
        # This assumes LiDAR Z-up, Camera Z-forward convention
        rotation = np.array([
            [0, -1, 0],
            [0, 0, -1],
            [1, 0, 0]
        ])
        self.lidar_to_camera_transform[:3, :3] = rotation
        
    def _compute_camera_matrix(self):
        """Compute camera matrix from resolution and FOV."""
        width, height = self.camera_resolution
        fx = width / (2 * np.tan(np.radians(self.fov_horizontal / 2)))
        fy = fx  # Assume square pixels
        cx = width / 2
        cy = height / 2
        
        return np.array([
            [fx, 0, cx],
            [0, fy, cy],
            [0, 0, 1]
        ])
    
    @jit(nopython=True)
    def _fast_project_points(points_cam, fx, fy, cx, cy, width, height):
        """Fast point projection using Numba."""
        n_points = points_cam.shape[0]
        projected = np.zeros((n_points, 2), dtype=np.int32)
        valid_mask = np.zeros(n_points, dtype=np.bool_)
        
        for i in prange(n_points):
            if points_cam[i, 2] > 0.1:  # In front of camera
                u = int(fx * points_cam[i, 0] / points_cam[i, 2] + cx)
                v = int(fy * points_cam[i, 1] / points_cam[i, 2] + cy)
                
                if 0 <= u < width and 0 <= v < height:
                    projected[i, 0] = u
                    projected[i, 1] = v
                    valid_mask[i] = True
        
        return projected, valid_mask
    
    def create_feature_maps_fast(self, rgb_image: np.ndarray, lidar_points: np.ndarray) -> Dict:
        """
        Create fused feature maps with optimized processing.
        
        Returns dict with separate feature channels for efficient processing.
        """
        height, width = rgb_image.shape[:2]
        
        # Transform LiDAR points to camera frame
        points_hom = np.hstack([lidar_points, np.ones((len(lidar_points), 1))])
        points_cam = (self.lidar_to_camera_transform @ points_hom.T).T[:, :3]
        
        # Fast projection
        fx, fy = self.camera_matrix[0, 0], self.camera_matrix[1, 1]
        cx, cy = self.camera_matrix[0, 2], self.camera_matrix[1, 2]
        
        projected, valid_mask = self._fast_project_points(
            points_cam, fx, fy, cx, cy, width, height
        )
        
        # Create sparse maps
        depth_map = np.zeros((height, width), dtype=np.float32)
        height_map = np.zeros((height, width), dtype=np.float32)
        intensity_map = np.zeros((height, width), dtype=np.uint8)
        
        # Fill maps with valid projections
        valid_points = points_cam[valid_mask]
        valid_proj = projected[valid_mask]
        
        for i, (u, v) in enumerate(valid_proj):
            depth = valid_points[i, 2]
            height_val = valid_points[i, 1]  # Y is height in camera frame
            
            # Use closest point if multiple project to same pixel
            if depth_map[v, u] == 0 or depth < depth_map[v, u]:
                depth_map[v, u] = depth
                height_map[v, u] = height_val
            intensity_map[v, u] = min(255, intensity_map[v, u] + 10)
        
        # Efficient dilation using separable filter
        kernel_1d = cv2.getGaussianKernel(5, 1.5)
        depth_map = cv2.sepFilter2D(depth_map, -1, kernel_1d, kernel_1d)
        
        return {
            'rgb': rgb_image,
            'depth': depth_map,
            'height': height_map,
            'intensity': intensity_map,
            'points_cam': points_cam,
            'valid_mask': valid_mask
        }
    
    def detect_cones_multimodal_fast(self, rgb_image: np.ndarray, lidar_points: np.ndarray,
                                    yolo_detections: List[Dict]) -> List[Dict]:
        """
        Fast cone detection using low-level fusion.
        """
        start_time = time.time()
        
        # Create feature maps
        features = self.create_feature_maps_fast(rgb_image, lidar_points)
        
        # Process YOLO detections with LiDAR validation
        refined_detections = []
        
        for det in yolo_detections:
            x1, y1, x2, y2 = map(int, det['box'])
            
            # Extract ROI features
            roi_depth = features['depth'][y1:y2, x1:x2]
            roi_height = features['height'][y1:y2, x1:x2]
            roi_intensity = features['intensity'][y1:y2, x1:x2]
            
            # Fast validation
            if self._validate_cone_fast(roi_depth, roi_height, roi_intensity):
                # Compute refined depth
                depth = self._compute_cone_depth_fast(roi_depth, x1, x2, y1, y2)
                
                # Calculate confidence from multimodal cues
                lidar_conf = self._compute_lidar_confidence_fast(
                    roi_depth, roi_height, roi_intensity
                )
                
                visual_conf = det.get('confidence', 0.5)
                fused_conf = 0.6 * visual_conf + 0.4 * lidar_conf
                
                refined_det = {
                    'box': (x1, y1, x2, y2),
                    'cls': det.get('cls', 0),
                    'depth': depth,
                    'confidence': fused_conf,
                    'visual_conf': visual_conf,
                    'lidar_conf': lidar_conf,
                    'has_lidar': np.sum(roi_depth > 0) > self.min_points_per_cone
                }
                
                refined_detections.append(refined_det)
        
        # Apply temporal filtering
        refined_detections = self._temporal_filter(refined_detections)
        
        elapsed = (time.time() - start_time) * 1000
        if elapsed > 50:  # Log if taking too long
            print(f"Fusion processing time: {elapsed:.1f}ms")
        
        return refined_detections
    
    def _validate_cone_fast(self, roi_depth, roi_height, roi_intensity):
        """Fast cone validation."""
        valid_depth = roi_depth[roi_depth > 0]
        
        if len(valid_depth) < self.min_points_per_cone:
            return True  # Trust vision if not enough LiDAR points
        
        # Check height consistency (cones have specific height range)
        valid_height = roi_height[roi_depth > 0]
        if len(valid_height) > 0:
            height_range = np.max(valid_height) - np.min(valid_height)
            if height_range > 1.0:  # Too much height variation
                return False
        
        # Check depth consistency
        if np.std(valid_depth) > 0.5:
            return False
            
        return True
    
    def _compute_cone_depth_fast(self, roi_depth, x1, x2, y1, y2):
        """Fast depth computation with outlier rejection."""
        valid_depths = roi_depth[roi_depth > 0]
        
        if len(valid_depths) == 0:
            # Estimate from bounding box position if no LiDAR
            y_center = (y1 + y2) / 2
            return self._estimate_depth_from_position(y_center)
        
        # Use robust estimator (median) for depth
        return np.median(valid_depths)
    
    def _compute_lidar_confidence_fast(self, roi_depth, roi_height, roi_intensity):
        """Fast LiDAR confidence computation."""
        if roi_depth.size == 0:
            return 0.0
        
        # Point density score
        coverage = np.sum(roi_depth > 0) / roi_depth.size
        
        # Depth consistency score
        valid_depths = roi_depth[roi_depth > 0]
        consistency = 1.0 - min(1.0, np.std(valid_depths) / 2.0) if len(valid_depths) > 1 else 0.5
        
        # Intensity score (indicates good reflection)
        intensity_score = np.mean(roi_intensity) / 255.0
        
        return 0.4 * coverage + 0.4 * consistency + 0.2 * intensity_score
    
    def _estimate_depth_from_position(self, y_center):
        """Estimate depth from image position when LiDAR unavailable."""
        # Simple perspective model
        image_height = self.camera_resolution[1]
        normalized_y = y_center / image_height
        
        # Exponential depth model
        min_depth = 2.0
        max_depth = 15.0
        depth = min_depth + (max_depth - min_depth) * (normalized_y ** 2)
        
        return depth
    
    def _temporal_filter(self, detections):
        """Apply temporal filtering to reduce noise."""
        self.detection_history.append(detections)
        
        if len(self.detection_history) < 3:
            return detections
        
        # Simple temporal consistency check
        filtered = []
        for det in detections:
            x_center = (det['box'][0] + det['box'][2]) / 2
            
            # Check if similar detection existed in previous frames
            consistent_count = 0
            for hist_dets in self.detection_history:
                for hist_det in hist_dets:
                    hist_x = (hist_det['box'][0] + hist_det['box'][2]) / 2
                    if abs(x_center - hist_x) < 50 and abs(det['depth'] - hist_det['depth']) < 2.0:
                        consistent_count += 1
                        break
            
            # Keep detection if seen in multiple frames
            if consistent_count >= 2 or det['confidence'] > 0.8:
                filtered.append(det)
        
        return filtered


def integrate_optimized_fusion(node):
    """
    Integrate the optimized low-level fusion into the existing node.
    """
    try:
        node.get_logger().info("Integrating optimized low-level fusion...")
        
        # Replace the detector with optimized version
        node.low_level_detector = OptimizedLowLevelFusionDetector(
            camera_resolution=(1280, 720),
            fov_horizontal=90.0
        )
        
        # Store original method
        node._original_process_lidar_data = node.process_lidar_data
        
        def process_lidar_data_optimized(self):
            """Optimized process_lidar_data with better fusion."""
            if self.lidar is None or not hasattr(self, 'lidar_data') or self.lidar_data is None:
                return
            
            # Check for camera data
            if not hasattr(self.zed_camera, 'rgb_image') or self.zed_camera.rgb_image is None:
                return self._original_process_lidar_data()
            
            try:
                # Get sensor data
                with self.lidar_lock:
                    lidar_data = self.lidar_data.copy()
                
                # Transform to world coordinates (simplified)
                sensor_transform = np.array(self.lidar.get_transform().get_matrix())
                
                # Use only recent points for performance
                with self.lidar_history_lock:
                    # Keep only last 2 frames for speed
                    self.lidar_history.append(lidar_data)
                    if len(self.lidar_history) > 2:
                        self.lidar_history.pop(0)
                    
                    all_points = np.vstack(self.lidar_history)
                
                # Get camera data
                rgb_image = self.zed_camera.rgb_image.copy()
                existing_detections = getattr(self.zed_camera, 'cone_detections', [])
                
                # Perform optimized fusion
                fused_detections = self.low_level_detector.detect_cones_multimodal_fast(
                    rgb_image,
                    all_points,
                    existing_detections
                )
                
                # Update detections
                self.zed_camera.cone_detections = fused_detections
                
                # Draw on image
                for det in fused_detections:
                    x1, y1, x2, y2 = det['box']
                    cls = det['cls']
                    depth = det['depth']
                    conf = det['confidence']
                    has_lidar = det.get('has_lidar', False)
                    
                    # Color based on fusion status
                    if has_lidar:
                        color = (0, 255, 0) if cls == 0 else (0, 0, 255)  # Green/Blue for fused
                    else:
                        color = (255, 255, 0) if cls == 0 else (255, 0, 255)  # Yellow/Magenta for vision-only
                    
                    cv2.rectangle(self.zed_camera.rgb_image, (x1, y1), (x2, y2), color, 2)
                    label = f"{depth:.1f}m ({conf:.2f})"
                    cv2.putText(self.zed_camera.rgb_image, label, (x1, y1-10), 
                               cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
                
                # Continue with turn analysis
                detected_cones = []
                for det in fused_detections:
                    x1, y1, x2, y2 = det['box']
                    center_x = (x1 + x2) / 2
                    
                    # Better 3D position estimation
                    angle = ((center_x - 640) / 640) * np.radians(45)
                    x_3d = det['depth'] * np.tan(angle)
                    
                    detected_cones.append({
                        'position': np.array([x_3d, det['depth'], 0]),
                        'confidence': det['confidence'],
                        'size': [0.3, 0.3, 0.4]
                    })
                
                self.analyze_lidar_for_turns(all_points, detected_cones)
                self._publish_lidar_pointcloud(all_points)
                
            except Exception as e:
                self.get_logger().error(f"Error in optimized fusion: {str(e)}")
                return self._original_process_lidar_data()
        
        # Bind optimized method
        import types
        node.process_lidar_data = types.MethodType(process_lidar_data_optimized, node)
        
        # Add calibration method
        def calibrate_lidar_camera(self, manual_transform=None):
            """Calibrate LiDAR-Camera transform."""
            if manual_transform is not None:
                self.low_level_detector.lidar_to_camera_transform = manual_transform
            else:
                # Auto-calibration using cone detections
                # This is a simplified version - real calibration is more complex
                self.get_logger().info("Running auto-calibration...")
                # Collect corresponding points from both sensors
                # Apply optimization to find best transform
                pass
        
        node.calibrate_lidar_camera = types.MethodType(calibrate_lidar_camera, node)
        
        node.get_logger().info("Optimized fusion integration complete!")
        
    except Exception as e:
        node.get_logger().error(f"Error integrating optimized fusion: {str(e)}")
        import traceback
        traceback.print_exc() 