import numpy as np
import cv2
import torch
from typing import List, Dict, Tuple, Optional
import time
from collections import deque
import threading
from dataclasses import dataclass
from queue import Queue
import types

@dataclass
class SensorData:
    """Container for synchronized sensor data"""
    timestamp: float
    rgb_image: np.ndarray
    depth_array: np.ndarray
    lidar_points: np.ndarray
    frame_id: int

class SynchronizedLowLevelFusion:
    """
    Fixed low-level fusion with proper calibration and synchronization
    """
    def __init__(self, camera_resolution=(1280, 720), fov_horizontal=90.0):
        self.camera_resolution = camera_resolution
        self.fov_horizontal = fov_horizontal
        
        # Camera intrinsics
        self.camera_matrix = self._compute_camera_matrix()
        
        # FIXED: Proper CARLA LiDAR to Camera transform
        # In CARLA:
        # - Camera: Z-forward, Y-down, X-right
        # - LiDAR: X-forward, Y-left, Z-up
        self.lidar_to_camera_transform = self._get_carla_lidar_to_camera_transform()
        
        # Synchronization
        self.sync_queue = Queue(maxsize=10)
        self.sync_tolerance = 0.05  # 50ms tolerance
        self.last_rgb_data = None
        self.last_lidar_data = None
        
        # Performance optimization
        self.feature_cache = {}
        self.processing_thread = None
        self.running = False
        
        # Detection parameters
        self.cone_height_range = (0.1, 0.6)
        self.min_lidar_points = 3  # Reduced for better detection
        
    def _get_carla_lidar_to_camera_transform(self):
        """
        Get the correct transformation from LiDAR to Camera for CARLA
        Based on the sensor mounting positions in your lidar_camera_fusion.py
        """
        # From your code:
        # Camera transform: x=1.5, z=1.8 (relative to vehicle)
        # LiDAR transform: x=1.5, z=2.2 (relative to vehicle)
        
        # Translation: LiDAR is 0.4m above camera (same x position)
        translation = np.array([0.0, 0.4, 0.0])  # LiDAR is above camera
        
        # Rotation to align coordinate systems
        # LiDAR: X-forward, Y-left, Z-up
        # Camera: Z-forward, Y-down, X-right
        rotation = np.array([
            [0, 0, 1],     # Camera X = LiDAR Z
            [0, -1, 0],    # Camera Y = -LiDAR Y (flip Y)
            [1, 0, 0]      # Camera Z = LiDAR X
        ])
        
        # Build 4x4 transformation matrix
        transform = np.eye(4)
        transform[:3, :3] = rotation
        transform[:3, 3] = translation
        
        return transform
    
    def _compute_camera_matrix(self):
        """Compute camera intrinsic matrix"""
        width, height = self.camera_resolution
        fx = width / (2 * np.tan(np.radians(self.fov_horizontal / 2)))
        fy = fx  # Square pixels
        cx = width / 2
        cy = height / 2
        
        return np.array([
            [fx, 0, cx],
            [0, fy, cy],
            [0, 0, 1]
        ])
    
    def start_processing(self):
        """Start the processing thread"""
        self.running = True
        self.processing_thread = threading.Thread(target=self._processing_loop)
        self.processing_thread.daemon = True
        self.processing_thread.start()
    
    def stop_processing(self):
        """Stop the processing thread"""
        self.running = False
        if self.processing_thread:
            self.processing_thread.join(timeout=1.0)
    
    def _processing_loop(self):
        """Background processing loop for fusion"""
        while self.running:
            try:
                # Get synchronized data
                if not self.sync_queue.empty():
                    sensor_data = self.sync_queue.get(timeout=0.1)
                    # Process fusion in background
                    self._process_fusion(sensor_data)
                else:
                    time.sleep(0.01)
            except Exception as e:
                print(f"Error in processing loop: {e}")
    
    def add_rgb_frame(self, rgb_image, depth_array, timestamp, frame_id):
        """Add RGB+Depth frame for synchronization"""
        self.last_rgb_data = {
            'rgb': rgb_image,
            'depth': depth_array,
            'timestamp': timestamp,
            'frame_id': frame_id
        }
        self._try_sync()
    
    def add_lidar_frame(self, lidar_points, timestamp, frame_id):
        """Add LiDAR frame for synchronization"""
        self.last_lidar_data = {
            'points': lidar_points,
            'timestamp': timestamp,
            'frame_id': frame_id
        }
        self._try_sync()
    
    def _try_sync(self):
        """Try to synchronize camera and LiDAR data"""
        if self.last_rgb_data is None or self.last_lidar_data is None:
            return
        
        # Check timestamp difference
        time_diff = abs(self.last_rgb_data['timestamp'] - self.last_lidar_data['timestamp'])
        
        if time_diff < self.sync_tolerance:
            # Create synchronized data
            sensor_data = SensorData(
                timestamp=self.last_rgb_data['timestamp'],
                rgb_image=self.last_rgb_data['rgb'],
                depth_array=self.last_rgb_data['depth'],
                lidar_points=self.last_lidar_data['points'],
                frame_id=self.last_rgb_data['frame_id']
            )
            
            # Add to processing queue
            try:
                self.sync_queue.put_nowait(sensor_data)
            except:
                pass  # Queue full, skip
            
            # Clear old data
            self.last_rgb_data = None
            self.last_lidar_data = None
    
    def create_feature_maps_optimized(self, sensor_data: SensorData) -> Dict:
        """Create optimized fused feature maps"""
        height, width = sensor_data.rgb_image.shape[:2]
        
        # Initialize feature maps
        depth_map = np.zeros((height, width), dtype=np.float32)
        intensity_map = np.zeros((height, width), dtype=np.uint8)
        height_map = np.zeros((height, width), dtype=np.float32)
        
        # Transform LiDAR points to camera frame
        points_hom = np.hstack([sensor_data.lidar_points, np.ones((len(sensor_data.lidar_points), 1))])
        points_cam = (self.lidar_to_camera_transform @ points_hom.T).T[:, :3]
        
        # Filter points in front of camera
        valid_mask = points_cam[:, 2] > 0.1
        points_cam = points_cam[valid_mask]
        
        if len(points_cam) > 0:
            # Project to image plane
            points_2d = (self.camera_matrix @ points_cam.T).T
            points_2d = points_2d[:, :2] / points_2d[:, 2:]
            
            # Filter points within image bounds
            valid_x = (points_2d[:, 0] >= 0) & (points_2d[:, 0] < width)
            valid_y = (points_2d[:, 1] >= 0) & (points_2d[:, 1] < height)
            valid_points = valid_x & valid_y
            
            if np.any(valid_points):
                points_2d = points_2d[valid_points].astype(np.int32)
                points_cam = points_cam[valid_points]
                
                # Efficient map update using vectorized operations
                for i, (x, y) in enumerate(points_2d):
                    depth = points_cam[i, 2]
                    height_val = points_cam[i, 1]
                    
                    # Update with closest point
                    if depth_map[y, x] == 0 or depth < depth_map[y, x]:
                        depth_map[y, x] = depth
                        height_map[y, x] = height_val
                    
                    intensity_map[y, x] = min(255, intensity_map[y, x] + 20)
        
        # Light gaussian blur for smoother features
        depth_map = cv2.GaussianBlur(depth_map, (3, 3), 1.0)
        
        return {
            'rgb': sensor_data.rgb_image,
            'depth_camera': sensor_data.depth_array,
            'depth_lidar': depth_map,
            'height': height_map,
            'intensity': intensity_map,
            'timestamp': sensor_data.timestamp
        }
    
    def detect_cones_fused(self, features: Dict, yolo_detections: List[Dict]) -> List[Dict]:
        """Detect cones using fused features"""
        fused_detections = []
        
        for det in yolo_detections:
            x1, y1, x2, y2 = map(int, det['box'])
            
            # Extract ROI features
            roi_depth_lidar = features['depth_lidar'][y1:y2, x1:x2]
            roi_depth_camera = features['depth_camera'][y1:y2, x1:x2]
            roi_intensity = features['intensity'][y1:y2, x1:x2]
            roi_height = features['height'][y1:y2, x1:x2]
            
            # Calculate confidence scores
            lidar_coverage = np.sum(roi_depth_lidar > 0) / roi_depth_lidar.size if roi_depth_lidar.size > 0 else 0
            
            # Compute fused depth
            if lidar_coverage > 0.1:  # Enough LiDAR points
                # Use both LiDAR and camera depth
                valid_lidar = roi_depth_lidar[roi_depth_lidar > 0]
                valid_camera = roi_depth_camera[roi_depth_camera > 0]
                
                if len(valid_lidar) > 0 and len(valid_camera) > 0:
                    lidar_depth = np.median(valid_lidar)
                    camera_depth = np.median(valid_camera)
                    
                    # Weighted average based on reliability
                    fused_depth = 0.7 * lidar_depth + 0.3 * camera_depth
                    lidar_conf = min(1.0, lidar_coverage * 2)
                else:
                    fused_depth = det.get('depth', 5.0)
                    lidar_conf = 0.0
            else:
                # Use camera depth only
                fused_depth = det.get('depth', 5.0)
                lidar_conf = 0.0
            
            # Create fused detection
            fused_det = {
                'box': (x1, y1, x2, y2),
                'cls': det.get('cls', 0),
                'depth': fused_depth,
                'confidence': det.get('confidence', 0.5),
                'visual_conf': det.get('confidence', 0.5),
                'lidar_conf': lidar_conf,
                'fused_conf': 0.6 * det.get('confidence', 0.5) + 0.4 * lidar_conf,
                'has_lidar': lidar_coverage > 0.1
            }
            
            fused_detections.append(fused_det)
        
        return fused_detections
    
    def _process_fusion(self, sensor_data: SensorData):
        """Process fusion in background thread"""
        # This runs in background thread
        features = self.create_feature_maps_optimized(sensor_data)
        # Store in cache for main thread to retrieve
        self.feature_cache[sensor_data.frame_id] = features


def integrate_synchronized_fusion(node):
    """
    Integrate the fixed synchronized fusion into the existing node
    """
    try:
        node.get_logger().info("Integrating synchronized low-level fusion...")
        
        # Create new fusion detector
        node.fusion_detector = SynchronizedLowLevelFusion(
            camera_resolution=(1280, 720),
            fov_horizontal=90.0
        )
        
        # Start processing thread
        node.fusion_detector.start_processing()
        
        # Store original methods
        node._original_process_lidar_data = node.process_lidar_data
        node._original_timer_callback = node.timer_callback
        
        # Add synchronization support
        def timer_callback_with_sync(self):
            """Modified timer callback with synchronization"""
            if not self.use_carla or not self.vehicle or not self.zed_camera:
                return
            
            try:
                # Process camera frame
                self.zed_camera.process_frame()
                
                # Add camera data to fusion if available
                if hasattr(self.zed_camera, 'rgb_image') and self.zed_camera.rgb_image is not None:
                    if hasattr(self.zed_camera, 'depth_image') and self.zed_camera.depth_image is not None:
                        depth_array, _ = self.zed_camera.depth_image
                        timestamp = time.time()
                        frame_id = getattr(self, 'frame_counter', 0)
                        self.frame_counter = frame_id + 1
                        
                        self.fusion_detector.add_rgb_frame(
                            self.zed_camera.rgb_image.copy(),
                            depth_array,
                            timestamp,
                            frame_id
                        )
                
                # Process LiDAR data
                self.process_lidar_data()
                
                # Rest of original timer callback
                self.visualize_pcd_data()
                self.update_pcd_file_list()
                self.handle_keyboard_input()
                self.path_planner.plan_path()
                
                start_time = time.time()
                self.control_car()
                control_latency = (time.time() - start_time) * 1000
                
                current_speed = 0
                if hasattr(self, 'vehicle') and self.vehicle:
                    velocity = self.vehicle.get_velocity()
                    current_speed = np.sqrt(velocity.x**2 + velocity.y**2 + velocity.z**2)
                
                self.update_and_publish_metrics(control_latency, current_speed, self.prev_target_speed)
                self.visualize_detected_cones()
                self.publish_data()
                self.publish_path_for_rviz()
                self.broadcast_tf()
                
                if self.cone_mapper is not None:
                    self.publish_cone_map(self.cone_mapper)
                if hasattr(self, 'latest_point_cloud'):
                    self.publish_lidar_points(self.latest_point_cloud)
                
                if hasattr(self, 'cone_mapper') and self.cone_mapper is not None and self.cone_mapper.total_updates % 100 == 0:
                    self.save_map_and_path()
                    
            except Exception as e:
                self.get_logger().error(f"Error in timer callback: {str(e)}")
                import traceback
                self.get_logger().error(traceback.format_exc())
        
        def process_lidar_data_with_sync(self):
            """Process LiDAR data with synchronization"""
            if self.lidar is None or not hasattr(self, 'lidar_data') or self.lidar_data is None:
                return
            
            try:
                # Get LiDAR data
                with self.lidar_lock:
                    lidar_data = self.lidar_data.copy()
                    timestamp = getattr(self, 'lidar_timestamp', time.time())
                    frame_id = getattr(self, 'lidar_frame', 0)
                
                # Transform to world coordinates
                sensor_transform = np.array(self.lidar.get_transform().get_matrix())
                from .lidar_camera_fusion import transform_points
                points_world = transform_points(lidar_data, sensor_transform)
                
                # Add to fusion detector
                self.fusion_detector.add_lidar_frame(points_world, timestamp, frame_id)
                
                # Accumulate points
                with self.lidar_history_lock:
                    self.lidar_history.append(points_world)
                    if len(self.lidar_history) > self.accumulate_frames:
                        self.lidar_history.pop(0)
                    all_points = np.vstack(self.lidar_history)
                
                self.latest_lidar_points = all_points
                
                # Check if we have fused features ready
                if hasattr(self, 'frame_counter'):
                    recent_frame = self.frame_counter - 1
                    if recent_frame in self.fusion_detector.feature_cache:
                        features = self.fusion_detector.feature_cache[recent_frame]
                        
                        # Use fused features for detection
                        if hasattr(self.zed_camera, 'cone_detections') and self.zed_camera.cone_detections:
                            fused_detections = self.fusion_detector.detect_cones_fused(
                                features,
                                self.zed_camera.cone_detections
                            )
                            
                            # Update detections
                            self.zed_camera.cone_detections = fused_detections
                            
                            # Draw on image
                            for det in fused_detections:
                                x1, y1, x2, y2 = det['box']
                                cls = det['cls']
                                depth = det['depth']
                                has_lidar = det.get('has_lidar', False)
                                
                                # Color based on fusion status
                                if has_lidar:
                                    color = (0, 255, 0) if cls == 0 else (0, 0, 255)
                                else:
                                    color = (255, 255, 0) if cls == 0 else (255, 0, 255)
                                
                                cv2.rectangle(self.zed_camera.rgb_image, (x1, y1), (x2, y2), color, 2)
                                
                                # Add fusion indicator
                                fusion_text = "F" if has_lidar else "V"
                                label = f"{fusion_text}: {depth:.1f}m"
                                cv2.putText(self.zed_camera.rgb_image, label, (x1, y1-10), 
                                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
                            
                            self.get_logger().info(f"Synchronized fusion: {len(fused_detections)} detections, "
                                                 f"{sum(1 for d in fused_detections if d.get('has_lidar'))} with LiDAR")
                
                # Continue with turn analysis
                detected_cones = []
                if hasattr(self.zed_camera, 'cone_detections'):
                    for det in self.zed_camera.cone_detections:
                        x1, y1, x2, y2 = det['box']
                        center_x = (x1 + x2) / 2
                        angle = ((center_x - 640) / 640) * np.radians(45)
                        x_3d = det['depth'] * np.tan(angle)
                        
                        detected_cones.append({
                            'position': np.array([x_3d, det['depth'], 0]),
                            'confidence': det.get('fused_conf', det['confidence']),
                            'size': [0.3, 0.3, 0.4]
                        })
                
                self.analyze_lidar_for_turns(all_points, detected_cones)
                self._publish_lidar_pointcloud(all_points)
                
            except Exception as e:
                self.get_logger().error(f"Error in synchronized LiDAR processing: {str(e)}")
                import traceback
                self.get_logger().error(traceback.format_exc())
        
        # Bind new methods
        node.timer_callback = types.MethodType(timer_callback_with_sync, node)
        node.process_lidar_data = types.MethodType(process_lidar_data_with_sync, node)
        
        # Initialize frame counter
        node.frame_counter = 0
        
        node.get_logger().info("Synchronized fusion integration complete!")
        
        # Cleanup function
        def cleanup_fusion(self):
            if hasattr(self, 'fusion_detector'):
                self.fusion_detector.stop_processing()
        
        node.cleanup_fusion = types.MethodType(cleanup_fusion, node)
        
    except Exception as e:
        node.get_logger().error(f"Error integrating synchronized fusion: {str(e)}")
        import traceback
        traceback.print_exc() 