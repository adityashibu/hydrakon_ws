from launch import LaunchDescription
from launch_ros.actions import Node
import os

def generate_launch_description():
    # Create output directory
    mapping_output_dir = os.path.expanduser('~/lio_sam_output')
    os.makedirs(mapping_output_dir, exist_ok=True)
    
    return LaunchDescription([
        # LIO-SAM Integration Node
        Node(
            package='my_carla_driver',
            executable='lio_sam_integration',
            name='lio_sam_integration_node',
            output='screen',
            parameters=[{
                'map_resolution': 0.1,
                'map_width': 1000,
                'map_height': 1000,
                'output_dir': mapping_output_dir
            }]
        ),
        
        # Launch RViz with minimalist configuration
        Node(
            package='rviz2',
            executable='rviz2',
            name='lio_sam_rviz',
            output='screen'
        ),
        
        # Static TF for map to base_link
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='map_tf_publisher',
            arguments=['0', '0', '0', '0', '0', '0', 'map', 'base_link'],
            output='screen'
        )
    ])
