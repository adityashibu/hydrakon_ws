from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='my_carla_driver',
            executable='lio_sam_integration',
            name='lio_sam_integration_node',
            output='screen'
        )
    ]) 